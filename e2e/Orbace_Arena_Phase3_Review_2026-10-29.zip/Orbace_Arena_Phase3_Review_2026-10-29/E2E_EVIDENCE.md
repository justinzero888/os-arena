# PostgreSQL and browser E2E evidence

The test `backend/org-api/src/routes/__tests__/arena.review.postgres.integration.test.ts` launches the actual Fastify routes and the mounted Orbace Arena page in isolated Puppeteer browser contexts against a fresh local PostgreSQL database. The host uses a synthetic Orbace cookie session; three guests have isolated anonymous cookies; the overlay has a separate read-only context. Cross-origin requests are blocked by test interception.

The passing multi-context flow performs:

1. Arena disabled by default check (`ARENA_ENABLED=false` yields disabled page and disables create).
2. Host login/session restoration, create session, and share link.
3. Three anonymous audience preset votes and authoritative READY/start transition.
4. Private Arena supply starts; public payload has no solution, puzzle ID, or host controls; audience board inputs are disabled.
5. Host edits a cell, server persists board revision, then page reload restores server state.
6. A strike ballot opens; host pauses; deadline and strike remain frozen; host resumes; both deadlines shift; editable board cells are re-enabled.
7. Audience votes two penalty / one spare; server resolves the TIME_PENALTY fallback with 10 seconds removed and host/overlay display it.
8. Host completes and submits; server validates and host/guest/overlay show the authoritative result. Solution is absent from solve response and host/guest/overlay JSON.
9. Host rematches; session ID, ballot/votes, round and puzzle state reset; second valid but different Arena supply is selected.

The companion `arena.routes.postgres.integration.test.ts` covers the persisted route flow and private fields. Both files passed, 11/11 tests, against disposable local PostgreSQL. Exact output and migration logs are attached in `test-logs/arena-postgres-browser.log` and `test-logs/postgres-migrate.log`.

Limitations: this is a local synthetic-auth E2E. It does not validate public hosting, real host allowlist configuration, a production proxy, Twitch, deployment, or shared DB access.
