import { FastifyRequest, FastifyReply } from 'fastify';

// ADR-008: bearer tokens are structurally immune to CSRF (no ambient
// credential a malicious page can attach to a cross-site request) — this
// check only applies to requests carrying our own session cookie, the
// mechanism CSRF actually threatens. A pure-bearer request (or any request
// while USE_COOKIE_SESSIONS is off, since no cookie would ever be present)
// passes through untouched.
const ALLOWED_ORIGINS = new Set([
  'https://orbacesudoku.com',
  'https://www.orbacesudoku.com',
]);
const MUTATING_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);
const SESSION_COOKIE_NAME = 'orbace_session';
const CSRF_COOKIE_NAME = 'orbace_csrf';

function isAllowedOrigin(req: FastifyRequest, origin: string): boolean {
  if (ALLOWED_ORIGINS.has(origin) || /^http:\/\/localhost(:\d+)?$/.test(origin)) return true;
  // Arena guest/host pages are same-origin with this API. Compare the full
  // scheme + authority so HTTPS cannot be treated as equivalent to local HTTP.
  return req.url.startsWith('/api/arena/') && origin === `${req.protocol}://${req.headers.host}`;
}

// Registered as a global preHandler hook (src/index.ts) rather than called
// per-route — CSRF must cover every mutating endpoint uniformly, and
// requiring each of the 16+ route files to remember to call this
// individually is exactly the kind of thing that quietly misses one.
export async function csrfGuard(req: FastifyRequest, reply: FastifyReply): Promise<void> {
  if (!MUTATING_METHODS.has(req.method)) return;

  const sessionCookie = req.cookies?.[SESSION_COOKIE_NAME];
  if (!sessionCookie) return; // bearer-only request — immune, nothing to check

  const origin = req.headers.origin;
  if (origin) {
    if (!isAllowedOrigin(req, origin)) {
      reply.status(403).send({ error: 'CSRF check failed: origin not allowed' });
    }
    return;
  }

  // No Origin header — some legacy/native clients omit it even for
  // same-site requests. Double-submit fallback: a non-HttpOnly CSRF cookie
  // (readable by first-party JS, set alongside the session cookie — see
  // session.routes.ts) must be echoed back as a header. A cross-site
  // attacker can ride the session cookie automatically but cannot read it
  // to also send a matching header.
  const csrfCookie = req.cookies?.[CSRF_COOKIE_NAME];
  const csrfHeader = req.headers['x-csrf-token'];
  if (csrfCookie && csrfHeader && csrfCookie === csrfHeader) return;

  reply.status(403).send({ error: 'CSRF check failed: missing Origin and no valid double-submit token' });
}

export { CSRF_COOKIE_NAME, SESSION_COOKIE_NAME, MUTATING_METHODS };
