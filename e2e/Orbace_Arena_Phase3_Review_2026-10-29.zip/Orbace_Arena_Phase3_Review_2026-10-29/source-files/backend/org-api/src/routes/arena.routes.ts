import { createHash, randomBytes } from 'node:crypto';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { Prisma } from '@prisma/client';
import { prisma } from '../lib/prisma.js';
import { arenaHostAllowlist, isArenaEnabled } from '../lib/feature-flags.js';
import { authenticate } from '../middleware/auth.middleware.js';

const GUEST_COOKIE = 'arena_guest';
const GUEST_COOKIE_TTL_SECONDS = 60 * 60 * 24;
const SESSION_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const SOLVE_BODY_TIMEOUT_MS = 15_000;
// Includes the entire ingress/body budget, pool wait, bounded adjudication,
// and a margin. A process crash cannot strand deadline resolution forever.
const TRANSACTION_OPTIONS = { maxWait: 5_000, timeout: 10_000 };
const SOLVE_TICKET_LEASE_MS = SOLVE_BODY_TIMEOUT_MS + TRANSACTION_OPTIONS.maxWait + TRANSACTION_OPTIONS.timeout + 5_000;
const DEADLINE_ADJUDICATION_GRACE_MS = SOLVE_BODY_TIMEOUT_MS;
const PRESET_IDS = ['easy', 'medium', 'hard'] as const;
const PRESET_TIE_PRIORITY = ['easy', 'medium', 'hard'] as const;
const PRESET_CONFIG = {
  easy: { tier: 'Easy', seconds: 180 },
  medium: { tier: 'Medium', seconds: 300 },
  hard: { tier: 'Hard', seconds: 480 },
} as const;

type PresetId = (typeof PRESET_IDS)[number];
type VoteKind = 'PRESET' | 'STRIKE';
type ArenaTransaction = Prisma.TransactionClient;
type SessionRow = Prisma.ArenaSessionGetPayload<{ include: { rounds: true; votes: true } }>;

type ActiveSolveTicket = {
  id: string;
  ingressAt: Date;
  timeout: NodeJS.Timeout;
  hostUserId: string;
  adjudicating: boolean;
};
const solveTickets = new WeakMap<FastifyRequest, ActiveSolveTicket>();

async function releaseSolveTicket(request: FastifyRequest, finished = false): Promise<void> {
  const ticket = solveTickets.get(request);
  if (!ticket) return;
  // A disconnected browser does not cancel a complete, eligible solve.
  // Only handler completion (or an actual response) releases adjudication.
  if (ticket.adjudicating && !finished) return;
  // Delete from the registry before awaiting Prisma so finally/onResponse
  // races become an exactly-once cleanup operation.
  solveTickets.delete(request);
  clearTimeout(ticket.timeout);
  await prisma.arenaSolveIngress.deleteMany({ where: { id: ticket.id } }).catch(() => undefined);
}

function sendDisabled(reply: FastifyReply): void {
  reply.code(404).send({ error: 'Not found' });
}

async function requireHost(request: FastifyRequest, reply: FastifyReply): Promise<string | null> {
  const user = await authenticate(request, reply);
  if (!user) return null;
  if (!arenaHostAllowlist().has(user.sub)) {
    reply.code(403).send({ error: 'Arena host access is not enabled for this account' });
    return null;
  }
  return user.sub;
}

function sameAllowedOrigin(request: FastifyRequest): boolean {
  const origin = request.headers.origin;
  if (!origin) return false;
  const expected = `${request.protocol}://${request.headers.host}`;
  return origin === expected;
}

function validPreset(value: unknown): value is PresetId {
  return typeof value === 'string' && PRESET_IDS.includes(value as PresetId);
}

async function lockSession(tx: ArenaTransaction, id: string): Promise<SessionRow | null> {
  await tx.$queryRaw`SELECT set_config('lock_timeout', '5s', true), set_config('statement_timeout', '5s', true)`;
  await tx.$queryRaw`SELECT id FROM arena_sessions WHERE id = ${id}::uuid FOR UPDATE`;
  return tx.arenaSession.findUnique({
    where: { id },
    include: { rounds: { orderBy: { number: 'desc' } }, votes: true },
  });
}

function projection(session: SessionRow, now: Date) {
  const round = session.rounds[0];
  const ballotClosed = session.status !== 'BALLOT_OPEN' || now >= session.ballotClosesAt;
  const presetVotes = session.votes.filter((vote) => vote.kind === 'PRESET');
  const strikeVotes = session.votes.filter((vote) => vote.kind === 'STRIKE');
  const voteTotals = ballotClosed
    ? Object.fromEntries(PRESET_IDS.map((preset) => [preset, presetVotes.filter((vote) => vote.choice === preset).length]))
    : null;
  const strikeClosed = round?.strikeStatus === 'RESOLVED' || round?.strikeStatus === 'VOID';
  return {
    id: session.id,
    status: session.status,
    version: session.version,
    paused: Boolean(session.pausedAt),
    pausedAt: session.pausedAt?.toISOString() ?? null,
    ballot: {
      closesAt: session.ballotClosesAt.toISOString(),
      closed: ballotClosed,
      voteCount: presetVotes.length,
      totals: voteTotals,
    },
    round: round ? {
      number: round.number,
      phase: round.phase,
      preset: round.preset,
      givens: round.givens,
      // A winning board is the stored solution. Keep it private even in the
      // terminal projection returned to the host, guests, and overlay.
      board: round.result === 'HOST' ? null : round.boardState,
      boardRevision: round.boardRevision,
      startedAt: round.startedAt?.toISOString() ?? null,
      deadlineAt: round.deadlineAt?.toISOString() ?? null,
      result: round.result,
      strike: {
        status: round.strikeStatus,
        opensAt: round.strikeOpenedAt?.toISOString() ?? null,
        closesAt: round.strikeClosesAt?.toISOString() ?? null,
        choice: round.strikeChoice,
        counts: round.strikeStatus === 'OPEN' || strikeClosed
          ? { penalty: strikeVotes.filter((vote) => vote.choice === 'PENALTY').length, spare: strikeVotes.filter((vote) => vote.choice === 'SPARE').length }
          : null,
      },
      modifier: round.modifier,
      modifierAppliedSeconds: round.modifierAppliedSeconds,
    } : null,
    priorSessionId: session.priorSessionId,
  };
}

async function appendEvent(
  tx: ArenaTransaction,
  sessionId: string,
  version: number,
  type: string,
  payload: Prisma.InputJsonValue,
  commandKey?: string,
): Promise<void> {
  await tx.arenaEvent.create({ data: { sessionId, version, type, payload, commandKey } });
}

async function advanceLockedSession(tx: ArenaTransaction, id: string, now: Date): Promise<SessionRow | null> {
  let session = await lockSession(tx, id);
  if (!session || session.pausedAt || ['RESULT', 'CANCELLED'].includes(session.status)) return session;
  if (['BALLOT_OPEN', 'READY'].includes(session.status) && now.getTime() >= session.updatedAt.getTime() + 30 * 60_000) {
    const version = session.version + 1;
    const round = session.rounds[0];
    if (round) await tx.arenaRound.update({ where: { id: round.id }, data: { phase: 'RESULT', result: 'CANCELLED', endedAt: now, strikeStatus: 'VOID' } });
    await tx.arenaSession.update({ where: { id }, data: { status: 'CANCELLED', version } });
    await appendEvent(tx, id, version, 'SESSION_IDLE_CANCELLED', { reason: 'IDLE_TTL' });
    return lockSession(tx, id);
  }
  if (session.status === 'BALLOT_OPEN' && now >= session.ballotClosesAt) {
    const version = session.version + 1;
    await tx.arenaSession.update({ where: { id }, data: { status: 'READY', version } });
    await appendEvent(tx, id, version, 'BALLOT_CLOSED', { voteCount: session.votes.filter((vote) => vote.kind === 'PRESET').length });
    session = (await lockSession(tx, id))!;
  }
  if (session.status === 'PLAYING') {
    let round = session.rounds[0];
    if (round?.startedAt && round.preset && round.strikeStatus === 'NOT_OPEN') {
      const triggerMs = PRESET_CONFIG[round.preset as PresetId].seconds * 1000 * 0.3;
      const opensAt = new Date(round.startedAt.getTime() + triggerMs + round.pausedDurationMs);
      if (now >= opensAt) {
        const closesAt = new Date(opensAt.getTime() + 15_000);
        await tx.arenaRound.update({ where: { id: round.id }, data: { strikeStatus: 'OPEN', strikeOpenedAt: opensAt, strikeClosesAt: closesAt } });
        const version = session.version + 1;
        await tx.arenaSession.update({ where: { id }, data: { version } });
        await appendEvent(tx, id, version, 'STRIKE_BALLOT_OPENED', { closesAt: closesAt.toISOString(), variant: 'TIME_PENALTY' });
        session = (await lockSession(tx, id))!;
        round = session.rounds[0];
      }
    }
    if (round?.strikeStatus === 'OPEN' && round.strikeClosesAt && now >= round.strikeClosesAt) {
      const strikeVotes = session.votes.filter((vote) => vote.kind === 'STRIKE');
      const penaltyVotes = strikeVotes.filter((vote) => vote.choice === 'PENALTY').length;
      const spareVotes = strikeVotes.filter((vote) => vote.choice === 'SPARE').length;
      const penaltyWon = penaltyVotes > spareVotes;
      const remainingSeconds = Math.ceil(((round.deadlineAt?.getTime() ?? now.getTime()) - now.getTime()) / 1000);
      const penaltySeconds = penaltyWon ? Math.min(10, Math.max(0, remainingSeconds - 30)) : 0;
      const nextDeadline = round.deadlineAt && penaltySeconds > 0
        ? new Date(round.deadlineAt.getTime() - penaltySeconds * 1000)
        : round.deadlineAt;
      await tx.arenaRound.update({ where: { id: round.id }, data: {
        strikeStatus: 'RESOLVED', strikeResolvedAt: now,
        strikeChoice: penaltyWon ? 'TIME_PENALTY' : 'SPARED',
        modifier: penaltySeconds > 0 ? 'TIME_PENALTY' : 'NONE',
        modifierAppliedSeconds: penaltySeconds,
        ...(nextDeadline ? { deadlineAt: nextDeadline } : {}),
      } });
      const version = session.version + 1;
      await tx.arenaSession.update({ where: { id }, data: { version } });
      await appendEvent(tx, id, version, penaltySeconds > 0 ? 'TIME_PENALTY_APPLIED' : 'STRIKE_RESOLVED', {
        choice: penaltyWon ? 'TIME_PENALTY' : 'SPARED', penaltySeconds,
      });
      session = (await lockSession(tx, id))!;
      round = session.rounds[0];
    }
    if (round?.deadlineAt && now.getTime() >= round.deadlineAt.getTime() + DEADLINE_ADJUDICATION_GRACE_MS) {
      const pending = await tx.arenaSolveIngress.count({
        where: { sessionId: id, ingressAt: { lt: round.deadlineAt }, leaseExpiresAt: { gt: now } },
      });
      if (pending === 0) {
        const version = session.version + 1;
        await tx.arenaRound.update({ where: { id: round.id }, data: { phase: 'RESULT', result: 'AUDIENCE', endedAt: now, strikeStatus: ['OPEN', 'NOT_OPEN'].includes(round.strikeStatus) ? 'VOID' : round.strikeStatus } });
        await tx.arenaSession.update({ where: { id }, data: { status: 'RESULT', version } });
        await appendEvent(tx, id, version, 'ROUND_TIMEOUT', { result: 'AUDIENCE' });
        session = (await lockSession(tx, id))!;
      }
    }
  }
  return session;
}

async function advanceSessionState(id: string, now: Date): Promise<SessionRow | null> {
  return prisma.$transaction((tx) => advanceLockedSession(tx, id, now), TRANSACTION_OPTIONS);
}

async function currentSession(id: string): Promise<SessionRow | null> {
  return advanceSessionState(id, new Date());
}

function validPartialBoard(board: unknown, givens: string): board is string {
  if (typeof board !== 'string' || !/^[0-9]{81}$/.test(board)) return false;
  for (let i = 0; i < 81; i += 1) if (givens[i] !== '0' && board[i] !== givens[i]) return false;
  for (let i = 0; i < 81; i += 1) {
    const digit = board[i];
    if (digit === '0') continue;
    const row = Math.floor(i / 9), col = i % 9, boxRow = Math.floor(row / 3) * 3, boxCol = Math.floor(col / 3) * 3;
    for (let j = 0; j < 81; j += 1) {
      if (j === i || board[j] !== digit) continue;
      const otherRow = Math.floor(j / 9), otherCol = j % 9;
      if (otherRow === row || otherCol === col || (Math.floor(otherRow / 3) * 3 === boxRow && Math.floor(otherCol / 3) * 3 === boxCol)) return false;
    }
  }
  return true;
}

function parseIdempotencyKey(request: FastifyRequest): string | null {
  const value = request.headers['idempotency-key'];
  if (typeof value !== 'string' || !/^[A-Za-z0-9._:-]{8,128}$/.test(value)) return null;
  return value;
}

function isBoardSolution(board: unknown, givens: string, solution: string): boolean {
  if (typeof board !== 'string' || !/^[1-9]{81}$/.test(board)) return false;
  for (let index = 0; index < 81; index += 1) {
    if (givens[index] !== '0' && board[index] !== givens[index]) return false;
  }
  return board === solution;
}

export async function arenaRoutes(app: FastifyInstance): Promise<void> {
  const solveLimiter = app.rateLimit({ max: 8, timeWindow: '1 minute' });
  const hostCommandLimiter = app.rateLimit({ max: 30, timeWindow: '1 minute' });
  // Scoped to Arena: ORM errors can include private row values. Never let
  // Fastify's default error serialization echo those values to a client.
  app.setErrorHandler((error, _request, reply) => {
    const code = typeof error === 'object' && error !== null && 'statusCode' in error ? error.statusCode : undefined;
    const status = typeof code === 'number' && Number.isInteger(code) && code >= 400 && code < 500 ? code : 503;
    const message = status === 503 ? 'Arena is temporarily unavailable'
      : status === 413 ? 'Request body too large'
        : status === 429 ? 'Too many requests' : 'Invalid Arena request';
    reply.code(status).send({ error: message });
  });
  app.addHook('onSend', async (_request, reply) => { reply.header('cache-control', 'no-store'); });
  app.get('/api/arena/health', async (_request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    return { enabled: true };
  });

  app.post('/api/arena/sessions', { bodyLimit: 1024 }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const hostUserId = await requireHost(request, reply);
    if (!hostUserId) return;
    if (request.headers.origin && !sameAllowedOrigin(request)) return reply.code(403).send({ error: 'Origin not allowed' });
    const body = request.body as { defaultPreset?: unknown } | undefined;
    const defaultPreset = body?.defaultPreset ?? 'easy';
    if (!validPreset(defaultPreset)) return reply.code(400).send({ error: 'Invalid default preset' });

    const now = new Date();
    const ballotClosesAt = new Date(now.getTime() + 20_000);
    const expiresAt = new Date(now.getTime() + 2 * 60 * 60_000);
    const session = await prisma.$transaction(async (tx) => {
      const created = await tx.arenaSession.create({
        data: { hostUserId, hostDefaultPreset: defaultPreset, ballotClosesAt, expiresAt },
      });
      await tx.arenaRound.create({ data: { sessionId: created.id, number: 1 } });
      await appendEvent(tx, created.id, created.version, 'SESSION_CREATED', { status: created.status });
      return tx.arenaSession.findUnique({ where: { id: created.id }, include: { rounds: true, votes: true } });
    });
    if (!session) return reply.code(500).send({ error: 'Could not create Arena session' });
    return reply.code(201).send(projection(session, now));
  });

  app.get<{ Params: { id: string } }>('/api/arena/sessions/:id', async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const session = await currentSession(request.params.id);
    if (!session) return reply.code(404).send({ error: 'Session not found' });
    reply.header('cache-control', 'no-store');
    return projection(session, new Date());
  });

  app.get<{ Params: { id: string } }>('/api/arena/sessions/:id/overlay', async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const session = await currentSession(request.params.id);
    if (!session) return reply.code(404).send({ error: 'Session not found' });
    reply.header('cache-control', 'no-store');
    return projection(session, new Date());
  });

  app.get<{ Params: { id: string } }>('/api/arena/sessions/:id/host', async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const hostUserId = await requireHost(request, reply);
    if (!hostUserId) return;
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const session = await currentSession(request.params.id);
    if (!session || session.hostUserId !== hostUserId) return reply.code(404).send({ error: 'Session not found' });
    reply.header('cache-control', 'no-store');
    return {
      ...projection(session, new Date()),
      hostControls: {
        canStart: session.status === 'READY' && !session.pausedAt,
        canSolve: session.status === 'PLAYING' && !session.pausedAt,
        canPause: ['BALLOT_OPEN', 'PLAYING'].includes(session.status) && !session.pausedAt,
        canResume: Boolean(session.pausedAt),
        canCancel: !['RESULT', 'CANCELLED'].includes(session.status),
      },
    };
  });

  app.post<{ Params: { id: string } }>('/api/arena/sessions/:id/votes', { bodyLimit: 1024 }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    if (!sameAllowedOrigin(request)) return reply.code(403).send({ error: 'Origin not allowed' });
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const ingressAt = new Date();
    const body = request.body as { kind?: unknown; choice?: unknown } | undefined;
    const kind: VoteKind = body?.kind === undefined ? 'PRESET' : body.kind as VoteKind;
    const choice = body?.choice;
    if (!['PRESET', 'STRIKE'].includes(kind) || (kind === 'PRESET' ? !validPreset(choice) : !['PENALTY', 'SPARE'].includes(String(choice)))) {
      return reply.code(400).send({ error: 'Invalid Arena vote' });
    }

    const token = request.cookies?.[GUEST_COOKIE] ?? randomBytes(32).toString('base64url');
    const guestKeyHash = createHash('sha256').update(token).digest('hex');
    const now = new Date();
    const result = await prisma.$transaction(async (tx) => {
      let session = await lockSession(tx, request.params.id);
      if (!session) return { status: 404 as const, session: null };
      if (session.pausedAt || ['RESULT', 'CANCELLED'].includes(session.status)) return { status: 409 as const, session };
      if (kind === 'PRESET') {
        if (session.status !== 'BALLOT_OPEN' || ingressAt >= session.ballotClosesAt) {
          session = (await advanceLockedSession(tx, session.id, now)) ?? session;
          return { status: 409 as const, session };
        }
      } else {
        session = (await advanceLockedSession(tx, session.id, now)) ?? session;
        const activeRound = session.rounds[0];
        if (session.status !== 'PLAYING' || activeRound?.strikeStatus !== 'OPEN' || !activeRound.strikeOpenedAt || !activeRound.strikeClosesAt
          || ingressAt < activeRound.strikeOpenedAt || ingressAt >= activeRound.strikeClosesAt) return { status: 409 as const, session };
      }
      await tx.arenaVote.upsert({
        where: { sessionId_kind_guestKeyHash: { sessionId: session.id, kind, guestKeyHash } },
        create: { sessionId: session.id, kind, guestKeyHash, choice: String(choice) },
        update: { choice: String(choice) },
      });
      const version = session.version + 1;
      await tx.arenaSession.update({ where: { id: session.id }, data: { version } });
      await appendEvent(tx, session.id, version, kind === 'PRESET' ? 'PRESET_VOTE_CHANGED' : 'STRIKE_VOTE_CHANGED', { kind, choice: String(choice) });
      session = (await lockSession(tx, session.id))!;
      if (kind === 'PRESET') session = (await advanceLockedSession(tx, session.id, now)) ?? session;
      return { status: 200 as const, session };
    });
    reply.setCookie(GUEST_COOKIE, token, {
      httpOnly: true, sameSite: 'lax', secure: request.protocol === 'https',
      path: '/api/arena', maxAge: GUEST_COOKIE_TTL_SECONDS,
    });
    if (!result.session) return reply.code(result.status).send({ error: 'Session not found' });
    if (result.status !== 200) return reply.code(409).send({ error: kind === 'PRESET' ? 'Preset ballot is closed' : 'Strike ballot is closed' });
    return projection(result.session, now);
  });

  app.post<{ Params: { id: string } }>('/api/arena/sessions/:id/start', { bodyLimit: 1024 }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const hostUserId = await requireHost(request, reply);
    if (!hostUserId) return;
    if (request.headers.origin && !sameAllowedOrigin(request)) return reply.code(403).send({ error: 'Origin not allowed' });
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const commandKey = parseIdempotencyKey(request);
    if (!commandKey) return reply.code(400).send({ error: 'Valid Idempotency-Key required' });
    const body = request.body as { expectedVersion?: unknown } | undefined;
    const expectedVersion = body?.expectedVersion;
    if (typeof expectedVersion !== 'number' || !Number.isSafeInteger(expectedVersion)) return reply.code(400).send({ error: 'expectedVersion required' });
    const now = new Date();
    const session = await prisma.$transaction(async (tx) => {
      const locked = await advanceLockedSession(tx, request.params.id, now);
      if (!locked || locked.hostUserId !== hostUserId) return null;
      const existing = await tx.arenaEvent.findFirst({ where: { sessionId: request.params.id, commandKey } });
      if (existing) return existing.type === 'ROUND_STARTED' ? locked : null;
      if (locked.version !== expectedVersion || locked.status !== 'READY' || now < locked.ballotClosesAt) return null;
      const counts = Object.fromEntries(PRESET_IDS.map((preset) => [preset, locked.votes.filter((vote) => vote.kind === 'PRESET' && vote.choice === preset).length])) as Record<PresetId, number>;
      const maximum = Math.max(...Object.values(counts));
      const preset = maximum === 0 ? locked.hostDefaultPreset as PresetId : PRESET_TIE_PRIORITY.find((item) => counts[item] === maximum)!;
      // Only explicitly eligible backend-private supply may be used. Public
      // catalogs and canonical grids cannot be trusted as Arena supply.
      const candidates = await tx.arenaPuzzleSupply.findMany({
        where: {
          tier: PRESET_CONFIG[preset].tier,
          eligible: true,
          id: { notIn: (await tx.arenaRound.findMany({
            where: { session: { seriesId: locked.seriesId }, puzzleId: { not: null } },
            select: { puzzleId: true },
          })).map((item) => item.puzzleId!).filter(Boolean) },
        },
        orderBy: { createdAt: 'asc' },
      });
      let puzzle: (typeof candidates)[number] | undefined;
      for (const candidate of candidates) {
        const duplicate = { OR: [{ givens: candidate.givens }, { solution: candidate.solution }] };
        // These are the three stores exposed by the registered public puzzle
        // route. Internal canonical records are not an answer-lookup path.
        const [daily, pool, pack] = await Promise.all([
          tx.puzzleDaily.findFirst({ where: duplicate, select: { id: true } }),
          tx.puzzlePool.findFirst({ where: duplicate, select: { id: true } }),
          tx.packPuzzle.findFirst({ where: duplicate, select: { id: true } }),
        ]);
        if (!daily && !pool && !pack) { puzzle = candidate; break; }
      }
      if (!puzzle) return null;
      const round = locked.rounds[0];
      if (!round) return null;
      const deadlineAt = new Date(now.getTime() + PRESET_CONFIG[preset].seconds * 1000);
      const version = locked.version + 1;
      await tx.arenaRound.update({ where: { id: round.id }, data: {
        phase: 'PLAYING', preset, puzzleId: puzzle.id, givens: puzzle.givens,
        solution: puzzle.solution, boardState: puzzle.givens, boardRevision: 0, startedAt: now, deadlineAt,
        strikeStatus: 'NOT_OPEN', pausedDurationMs: 0, modifier: null, modifierAppliedSeconds: 0,
      } });
      await tx.arenaSession.update({ where: { id: locked.id }, data: { status: 'PLAYING', version } });
      await appendEvent(tx, locked.id, version, 'ROUND_STARTED', { preset }, commandKey);
      return lockSession(tx, locked.id);
    });
    if (!session) return reply.code(409).send({ error: 'Session is not READY, version is stale, or no eligible puzzle is available' });
    return projection(session, now);
  });

  app.post<{ Params: { id: string } }>('/api/arena/sessions/:id/board', {
    bodyLimit: 2048,
    config: { rateLimit: false },
    onRequest: async (request, reply) => { await hostCommandLimiter.call(app, request, reply); },
  }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const hostUserId = await requireHost(request, reply);
    if (!hostUserId) return;
    if (request.headers.origin && !sameAllowedOrigin(request)) return reply.code(403).send({ error: 'Origin not allowed' });
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const commandKey = parseIdempotencyKey(request);
    if (!commandKey) return reply.code(400).send({ error: 'Valid Idempotency-Key required' });
    const body = request.body as { expectedRevision?: unknown; board?: unknown } | undefined;
    if (typeof body?.expectedRevision !== 'number' || !Number.isSafeInteger(body.expectedRevision)) return reply.code(400).send({ error: 'expectedRevision required' });
    const receivedAt = new Date();
    const session = await prisma.$transaction(async (tx) => {
      const locked = await lockSession(tx, request.params.id);
      if (!locked || locked.hostUserId !== hostUserId) return null;
      const replay = await tx.arenaEvent.findFirst({ where: { sessionId: locked.id, commandKey } });
      if (replay) return replay.type === 'BOARD_UPDATED' ? locked : null;
      const round = locked.rounds[0];
      if (locked.pausedAt) return null;
      if (locked.status !== 'PLAYING' || !round?.deadlineAt || !round.givens || round.deadlineAt <= receivedAt) return null;
      if (round.boardRevision !== body.expectedRevision || !validPartialBoard(body.board, round.givens) || body.board === round.solution) return null;
      const version = locked.version + 1;
      await tx.arenaRound.update({ where: { id: round.id }, data: { boardState: body.board, boardRevision: round.boardRevision + 1 } });
      await tx.arenaSession.update({ where: { id: locked.id }, data: { version } });
      await appendEvent(tx, locked.id, version, 'BOARD_UPDATED', { revision: round.boardRevision + 1 }, commandKey);
      return lockSession(tx, locked.id);
    }, TRANSACTION_OPTIONS);
    if (!session) return reply.code(409).send({ error: 'Board update rejected; refresh the current Arena state' });
    return projection(session, receivedAt);
  });

  app.post<{ Params: { id: string } }>('/api/arena/sessions/:id/pause', {
    bodyLimit: 1024, config: { rateLimit: false },
    onRequest: async (request, reply) => { await hostCommandLimiter.call(app, request, reply); },
  }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const hostUserId = await requireHost(request, reply);
    if (!hostUserId) return;
    if (request.headers.origin && !sameAllowedOrigin(request)) return reply.code(403).send({ error: 'Origin not allowed' });
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const commandKey = parseIdempotencyKey(request);
    const body = request.body as { expectedVersion?: unknown; confirmed?: unknown } | undefined;
    if (!commandKey || typeof body?.expectedVersion !== 'number' || !Number.isSafeInteger(body.expectedVersion)) return reply.code(400).send({ error: 'Version and Idempotency-Key required' });
    if (body.confirmed !== true) return reply.code(400).send({ error: 'Technical pause confirmation required' });
    const now = new Date();
    const session = await prisma.$transaction(async (tx) => {
      const locked = await advanceLockedSession(tx, request.params.id, now);
      if (!locked || locked.hostUserId !== hostUserId) return null;
      const existing = await tx.arenaEvent.findFirst({ where: { sessionId: locked.id, commandKey } });
      if (existing) return existing.type === 'TECHNICAL_PAUSE' ? locked : null;
      if (locked.version !== body.expectedVersion || locked.pausedAt || !['BALLOT_OPEN', 'PLAYING'].includes(locked.status)) return null;
      const version = locked.version + 1;
      await tx.arenaSession.update({ where: { id: locked.id }, data: { pausedAt: now, pausedPhase: locked.status, version } });
      await appendEvent(tx, locked.id, version, 'TECHNICAL_PAUSE', { phase: locked.status }, commandKey);
      return lockSession(tx, locked.id);
    }, TRANSACTION_OPTIONS);
    if (!session) return reply.code(409).send({ error: 'Arena cannot be paused in its current state' });
    return projection(session, now);
  });

  app.post<{ Params: { id: string } }>('/api/arena/sessions/:id/resume', {
    bodyLimit: 1024, config: { rateLimit: false },
    onRequest: async (request, reply) => { await hostCommandLimiter.call(app, request, reply); },
  }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const hostUserId = await requireHost(request, reply);
    if (!hostUserId) return;
    if (request.headers.origin && !sameAllowedOrigin(request)) return reply.code(403).send({ error: 'Origin not allowed' });
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const commandKey = parseIdempotencyKey(request);
    const body = request.body as { expectedVersion?: unknown; confirmed?: unknown } | undefined;
    if (!commandKey || typeof body?.expectedVersion !== 'number' || !Number.isSafeInteger(body.expectedVersion)) return reply.code(400).send({ error: 'Version and Idempotency-Key required' });
    if (body.confirmed !== true) return reply.code(400).send({ error: 'Resume confirmation required' });
    const now = new Date();
    const session = await prisma.$transaction(async (tx) => {
      const locked = await lockSession(tx, request.params.id);
      if (!locked || locked.hostUserId !== hostUserId) return null;
      const existing = await tx.arenaEvent.findFirst({ where: { sessionId: locked.id, commandKey } });
      if (existing) return existing.type === 'TECHNICAL_RESUME' ? locked : null;
      if (locked.version !== body.expectedVersion || !locked.pausedAt || !locked.pausedPhase) return null;
      const pauseMs = Math.max(0, now.getTime() - locked.pausedAt.getTime());
      const data: Prisma.ArenaSessionUpdateInput = { pausedAt: null, pausedPhase: null, version: locked.version + 1 };
      if (locked.pausedPhase === 'BALLOT_OPEN') data.ballotClosesAt = new Date(locked.ballotClosesAt.getTime() + pauseMs);
      const round = locked.rounds[0];
      await tx.arenaSession.update({ where: { id: locked.id }, data });
      if (locked.pausedPhase === 'PLAYING' && round) {
        await tx.arenaRound.update({ where: { id: round.id }, data: {
          pausedDurationMs: round.pausedDurationMs + pauseMs,
          ...(round.deadlineAt ? { deadlineAt: new Date(round.deadlineAt.getTime() + pauseMs) } : {}),
          ...(round.strikeStatus === 'OPEN' && round.strikeClosesAt ? { strikeClosesAt: new Date(round.strikeClosesAt.getTime() + pauseMs) } : {}),
        } });
      }
      await appendEvent(tx, locked.id, locked.version + 1, 'TECHNICAL_RESUME', { phase: locked.pausedPhase, durationMs: pauseMs }, commandKey);
      return lockSession(tx, locked.id);
    }, TRANSACTION_OPTIONS);
    if (!session) return reply.code(409).send({ error: 'Arena is not paused or version is stale' });
    return projection(session, now);
  });

  app.post<{ Params: { id: string } }>('/api/arena/sessions/:id/cancel', {
    bodyLimit: 1024, config: { rateLimit: false },
    onRequest: async (request, reply) => { await hostCommandLimiter.call(app, request, reply); },
  }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const hostUserId = await requireHost(request, reply);
    if (!hostUserId) return;
    if (request.headers.origin && !sameAllowedOrigin(request)) return reply.code(403).send({ error: 'Origin not allowed' });
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const commandKey = parseIdempotencyKey(request);
    const body = request.body as { expectedVersion?: unknown; confirmed?: unknown } | undefined;
    if (!commandKey || typeof body?.expectedVersion !== 'number' || !Number.isSafeInteger(body.expectedVersion)) return reply.code(400).send({ error: 'Version and Idempotency-Key required' });
    if (body.confirmed !== true) return reply.code(400).send({ error: 'Cancellation confirmation required' });
    const now = new Date();
    const session = await prisma.$transaction(async (tx) => {
      const locked = await lockSession(tx, request.params.id);
      if (!locked || locked.hostUserId !== hostUserId) return null;
      const existing = await tx.arenaEvent.findFirst({ where: { sessionId: locked.id, commandKey } });
      if (existing) return existing.type === 'HOST_CANCELLED' ? locked : null;
      if (locked.version !== body.expectedVersion || ['RESULT', 'CANCELLED'].includes(locked.status)) return null;
      const round = locked.rounds[0];
      const version = locked.version + 1;
      if (round) await tx.arenaRound.update({ where: { id: round.id }, data: { phase: 'RESULT', result: 'CANCELLED', endedAt: now, strikeStatus: 'VOID' } });
      await tx.arenaSession.update({ where: { id: locked.id }, data: { status: 'CANCELLED', pausedAt: null, pausedPhase: null, version } });
      await appendEvent(tx, locked.id, version, 'HOST_CANCELLED', { result: 'CANCELLED' }, commandKey);
      return lockSession(tx, locked.id);
    }, TRANSACTION_OPTIONS);
    if (!session) return reply.code(409).send({ error: 'Arena cannot be cancelled in its current state' });
    return projection(session, now);
  });

  app.post<{ Params: { id: string } }>('/api/arena/sessions/:id/rematch', {
    bodyLimit: 1024, config: { rateLimit: false },
    onRequest: async (request, reply) => { await hostCommandLimiter.call(app, request, reply); },
  }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const hostUserId = await requireHost(request, reply);
    if (!hostUserId) return;
    if (request.headers.origin && !sameAllowedOrigin(request)) return reply.code(403).send({ error: 'Origin not allowed' });
    if (!SESSION_ID.test(request.params.id)) return reply.code(404).send({ error: 'Session not found' });
    const commandKey = parseIdempotencyKey(request);
    const body = request.body as { expectedVersion?: unknown } | undefined;
    if (!commandKey || typeof body?.expectedVersion !== 'number' || !Number.isSafeInteger(body.expectedVersion)) return reply.code(400).send({ error: 'Version and Idempotency-Key required' });
    const now = new Date();
    const rematch = await prisma.$transaction(async (tx) => {
      const original = await lockSession(tx, request.params.id);
      if (!original || original.hostUserId !== hostUserId) return null;
      const existing = await tx.arenaEvent.findFirst({ where: { sessionId: original.id, commandKey } });
      if (existing && existing.type === 'REMATCH_CREATED' && typeof (existing.payload as { sessionId?: unknown }).sessionId === 'string') {
        return tx.arenaSession.findUnique({ where: { id: (existing.payload as { sessionId: string }).sessionId }, include: { rounds: true, votes: true } });
      }
      const previousRematch = await tx.arenaSession.findFirst({ where: { priorSessionId: original.id }, select: { id: true } });
      if (original.version !== body.expectedVersion || original.status !== 'RESULT' || previousRematch) return null;
      const created = await tx.arenaSession.create({ data: {
        seriesId: original.seriesId, priorSessionId: original.id, hostUserId,
        hostDefaultPreset: original.hostDefaultPreset,
        ballotClosesAt: new Date(now.getTime() + 20_000), expiresAt: new Date(now.getTime() + 2 * 60 * 60_000),
      } });
      await tx.arenaRound.create({ data: { sessionId: created.id, number: 1 } });
      const version = original.version + 1;
      await tx.arenaSession.update({ where: { id: original.id }, data: { version } });
      await appendEvent(tx, original.id, version, 'REMATCH_CREATED', { sessionId: created.id }, commandKey);
      return tx.arenaSession.findUnique({ where: { id: created.id }, include: { rounds: true, votes: true } });
    }, TRANSACTION_OPTIONS);
    if (!rematch) return reply.code(409).send({ error: 'Rematch is unavailable or version is stale' });
    return reply.code(201).send(projection(rematch, now));
  });

  app.post<{ Params: { id: string } }>('/api/arena/sessions/:id/solve', {
    bodyLimit: 4096,
    // The plugin appends configured route hooks after custom onRequest.
    // Invoke its limiter explicitly first so rejected requests are counted
    // before authentication or durable ingress registration.
    config: { rateLimit: false },
    onRequest: async (request, reply) => {
      if (!isArenaEnabled()) return;
      // Capture before asynchronous authentication; client timestamps never
      // participate. The body/auth/registration budget starts at this point.
      const ingressAt = new Date();
      await solveLimiter.call(app, request, reply);
      if (reply.sent) return;
      const remainingBodyBudget = SOLVE_BODY_TIMEOUT_MS - (Date.now() - ingressAt.getTime());
      if (remainingBodyBudget <= 0) return reply.code(408).send({ error: 'Solve was not accepted' });
      let timedOut = false;
      const timeout = setTimeout(() => {
        timedOut = true;
        request.raw.destroy(new Error('Arena solve body timed out'));
        void releaseSolveTicket(request);
      }, remainingBodyBudget);
      try {
        const hostUserId = await requireHost(request, reply);
        if (!hostUserId || timedOut || request.raw.destroyed) return;
        if (request.headers.origin && !sameAllowedOrigin(request)) {
          return reply.code(403).send({ error: 'Origin not allowed' });
        }
        if (!parseIdempotencyKey(request)) {
          return reply.code(400).send({ error: 'Valid Idempotency-Key required' });
        }
        const sessionId = request.params.id;
        if (!SESSION_ID.test(sessionId)) {
          return reply.code(404).send({ error: 'Session not found' });
        }
        const registered = await prisma.$transaction(async (tx) => {
          const session = await lockSession(tx, sessionId);
          if (!session || session.hostUserId !== hostUserId) return { code: 404, row: null };
          const existing = await tx.arenaEvent.findFirst({ where: { sessionId, commandKey: parseIdempotencyKey(request)! } });
          if (existing) return existing.type === 'ROUND_SOLVED'
            ? { code: 200, row: null, replay: session }
            : { code: 409, row: null };
          const round = session.rounds[0];
          if (session.status !== 'PLAYING' || session.pausedAt || !round?.deadlineAt || ingressAt >= round.deadlineAt) {
            return { code: 409, row: null };
          }
          if (timedOut || Date.now() - ingressAt.getTime() >= SOLVE_BODY_TIMEOUT_MS) return { code: 408, row: null };
          const row = await tx.arenaSolveIngress.create({
            data: { sessionId, ingressAt, leaseExpiresAt: new Date(ingressAt.getTime() + SOLVE_TICKET_LEASE_MS) },
          });
          return { code: 200, row };
        }, TRANSACTION_OPTIONS);
        if ('replay' in registered && registered.replay) return reply.send(projection(registered.replay, new Date()));
        const row = registered.row;
        if (!row) return reply.code(registered.code).send({ error: 'Solve was not accepted' });
        if (timedOut || request.raw.destroyed) {
          await prisma.arenaSolveIngress.deleteMany({ where: { id: row.id } });
          return;
        }
        solveTickets.set(request, { id: row.id, ingressAt, hostUserId, timeout, adjudicating: false });
        request.raw.once('close', () => {
          if (!request.raw.complete) void releaseSolveTicket(request);
        });
      } catch {
        if (!request.raw.destroyed) reply.code(503).send({ error: 'Could not register solve request' });
      } finally {
        if (!solveTickets.has(request)) clearTimeout(timeout);
      }
    },
    preValidation: async (request) => {
      const ticket = solveTickets.get(request);
      if (ticket) {
        // Fastify has finished reading/parsing the entire body. A body-read
        // timeout must never release this ticket while adjudication waits.
        clearTimeout(ticket.timeout);
        ticket.adjudicating = true;
      }
    },
    onRequestAbort: async (request) => { await releaseSolveTicket(request); },
    onResponse: async (request) => {
      await releaseSolveTicket(request, true);
    },
  }, async (request, reply) => {
    if (!isArenaEnabled()) return sendDisabled(reply);
    const ticket = solveTickets.get(request);
    if (!ticket) return reply.code(404).send({ error: 'Session not found' });
    const hostUserId = ticket.hostUserId;
    const commandKey = parseIdempotencyKey(request)!;
    const body = request.body as { expectedVersion?: unknown; board?: unknown } | undefined;
    const expectedVersion = body?.expectedVersion;
    if (typeof expectedVersion !== 'number' || !Number.isSafeInteger(expectedVersion)) return reply.code(400).send({ error: 'expectedVersion required' });
    const ingressAt = ticket.ingressAt;
    try {
      const result = await prisma.$transaction(async (tx) => {
        const session = await lockSession(tx, request.params.id);
        if (!session || session.hostUserId !== hostUserId) return { code: 404 as const, session: null };
        const existing = await tx.arenaEvent.findFirst({ where: { sessionId: request.params.id, commandKey } });
        if (existing) return { code: existing.type === 'ROUND_SOLVED' ? 200 as const : 409 as const, session };
        const round = session.rounds[0];
        if (session.status !== 'PLAYING' || session.pausedAt || !round?.deadlineAt || !round.givens || !round.solution) return { code: 409 as const, session };
        if (session.version !== expectedVersion) return { code: 409 as const, session };
        if (ingressAt.getTime() >= round.deadlineAt.getTime()) return { code: 409 as const, session };
        if (!isBoardSolution(body?.board, round.givens, round.solution)) {
          if (validPartialBoard(body?.board, round.givens)) {
            const version = session.version + 1;
            await tx.arenaRound.update({ where: { id: round.id }, data: { boardState: body!.board as string, boardRevision: round.boardRevision + 1 } });
            await tx.arenaSession.update({ where: { id: session.id }, data: { version } });
            await appendEvent(tx, session.id, version, 'BOARD_UPDATED', { revision: round.boardRevision + 1 });
            return { code: 422 as const, session: await lockSession(tx, session.id) };
          }
          return { code: 422 as const, session };
        }
        const version = session.version + 1;
        await tx.arenaRound.update({ where: { id: round.id }, data: {
          phase: 'RESULT', result: 'HOST', endedAt: new Date(), boardState: body!.board as string,
          boardRevision: round.boardRevision + 1, strikeStatus: 'VOID',
        } });
        await tx.arenaSession.update({ where: { id: session.id }, data: { status: 'RESULT', version } });
        await appendEvent(tx, session.id, version, 'ROUND_SOLVED', { result: 'HOST' }, commandKey);
        return { code: 200 as const, session: await lockSession(tx, session.id) };
      }, TRANSACTION_OPTIONS);
      if (!result.session) return reply.code(result.code).send({ error: 'Session not found' });
      if (result.code !== 200) return reply.code(result.code).send({ error: result.code === 422 ? 'Board is not the solution' : 'Solve was not accepted', ...(result.session ? { version: result.session.version } : {}) });
      return projection(result.session, new Date());
    } finally {
      await releaseSolveTicket(request, true);
    }
  });
}
