import { describe, it, expect, afterEach } from 'vitest';
import {
  isPuzzleIdentityFlagEnabled,
  snapshotPuzzleIdentityFlags,
  PUZZLE_IDENTITY_FLAGS,
  parseCatalogDualWriteFlowAllowlist,
  isCatalogDualWriteFlowAllowed,
  isArenaEnabled,
  arenaHostAllowlist,
} from '../feature-flags.js';

const ENV_VARS = PUZZLE_IDENTITY_FLAGS.map((f) => `FLAG_${f.toUpperCase()}`);

afterEach(() => {
  for (const key of ENV_VARS) delete process.env[key];
  delete process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS;
  delete process.env.ARENA_ENABLED;
  delete process.env.ARENA_ALLOWED_HOST_IDS;
});

describe('Arena feature gate and host allowlist', () => {
  it('keeps Arena disabled unless ARENA_ENABLED is exactly true', () => {
    expect(isArenaEnabled()).toBe(false);
    for (const value of ['1', 'TRUE', 'yes', 'false', '']) {
      process.env.ARENA_ENABLED = value;
      expect(isArenaEnabled()).toBe(false);
    }
    process.env.ARENA_ENABLED = 'true';
    expect(isArenaEnabled()).toBe(true);
  });

  it('denies hosts when unconfigured and parses only verified identity values', () => {
    expect(arenaHostAllowlist().size).toBe(0);
    process.env.ARENA_ALLOWED_HOST_IDS = ' user-a, user-b ,, ';
    expect([...arenaHostAllowlist()]).toEqual(['user-a', 'user-b']);
  });
});

describe('isPuzzleIdentityFlagEnabled', () => {
  it('defaults every flag to disabled when unset', () => {
    for (const flag of PUZZLE_IDENTITY_FLAGS) expect(isPuzzleIdentityFlagEnabled(flag)).toBe(false);
  });

  it('enables a flag only on the exact string "true"', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG = 'true';
    expect(isPuzzleIdentityFlagEnabled('puzzle_key_dual_write_catalog')).toBe(true);
  });

  it.each(['1', 'TRUE', 'True', 'yes', 'on', 'false', ''])('treats %j as disabled', (value) => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG = value;
    expect(isPuzzleIdentityFlagEnabled('puzzle_key_dual_write_catalog')).toBe(false);
  });

  it('flags are independently controlled — enabling one does not enable another', () => {
    process.env.FLAG_SUPU_DUAL_WRITE = 'true';
    expect(isPuzzleIdentityFlagEnabled('supu_dual_write')).toBe(true);
    for (const flag of PUZZLE_IDENTITY_FLAGS) {
      if (flag === 'supu_dual_write') continue;
      expect(isPuzzleIdentityFlagEnabled(flag)).toBe(false);
    }
  });

  it('catalog and attempts dual-write are independently controlled (2026-09-03 flag split)', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG = 'true';
    expect(isPuzzleIdentityFlagEnabled('puzzle_key_dual_write_catalog')).toBe(true);
    expect(isPuzzleIdentityFlagEnabled('puzzle_key_dual_write_attempts')).toBe(false);
  });

  it('tea_manifest_publish is independent of tea_manifest_shadow (Phase 3 WS1)', () => {
    process.env.FLAG_TEA_MANIFEST_SHADOW = 'true';
    expect(isPuzzleIdentityFlagEnabled('tea_manifest_publish')).toBe(false);
    delete process.env.FLAG_TEA_MANIFEST_SHADOW;
    process.env.FLAG_TEA_MANIFEST_PUBLISH = 'true';
    expect(isPuzzleIdentityFlagEnabled('tea_manifest_shadow')).toBe(false);
    expect(isPuzzleIdentityFlagEnabled('tea_manifest_publish')).toBe(true);
  });

  it('canonical_supu_write is independent of supu_dual_write (Phase 3 WS3)', () => {
    process.env.FLAG_SUPU_DUAL_WRITE = 'true';
    expect(isPuzzleIdentityFlagEnabled('canonical_supu_write')).toBe(false);
    delete process.env.FLAG_SUPU_DUAL_WRITE;
    process.env.FLAG_CANONICAL_SUPU_WRITE = 'true';
    expect(isPuzzleIdentityFlagEnabled('supu_dual_write')).toBe(false);
    expect(isPuzzleIdentityFlagEnabled('canonical_supu_write')).toBe(true);
  });

  it('canonical_supu_read is independent of canonical_supu_write (Phase 3 WS4)', () => {
    process.env.FLAG_CANONICAL_SUPU_WRITE = 'true';
    expect(isPuzzleIdentityFlagEnabled('canonical_supu_read')).toBe(false);
    delete process.env.FLAG_CANONICAL_SUPU_WRITE;
    process.env.FLAG_CANONICAL_SUPU_READ = 'true';
    expect(isPuzzleIdentityFlagEnabled('canonical_supu_write')).toBe(false);
    expect(isPuzzleIdentityFlagEnabled('canonical_supu_read')).toBe(true);
  });

  it('canonical_solve_history_read is independent of canonical_supu_read (Phase 3 WS6)', () => {
    process.env.FLAG_CANONICAL_SUPU_READ = 'true';
    expect(isPuzzleIdentityFlagEnabled('canonical_solve_history_read')).toBe(false);
    delete process.env.FLAG_CANONICAL_SUPU_READ;
    process.env.FLAG_CANONICAL_SOLVE_HISTORY_READ = 'true';
    expect(isPuzzleIdentityFlagEnabled('canonical_supu_read')).toBe(false);
    expect(isPuzzleIdentityFlagEnabled('canonical_solve_history_read')).toBe(true);
  });

  it('never throws even if process.env access misbehaves', () => {
    const original = process.env;
    try {
      process.env = new Proxy({}, { get() { throw new Error('boom'); } }) as NodeJS.ProcessEnv;
      expect(() => isPuzzleIdentityFlagEnabled('tea_manifest_shadow')).not.toThrow();
      expect(isPuzzleIdentityFlagEnabled('tea_manifest_shadow')).toBe(false);
    } finally {
      process.env = original;
    }
  });
});

describe('snapshotPuzzleIdentityFlags', () => {
  it('reports every flag disabled by default', () => {
    const snapshot = snapshotPuzzleIdentityFlags();
    expect(Object.keys(snapshot).sort()).toEqual([...PUZZLE_IDENTITY_FLAGS].sort());
    expect(Object.values(snapshot).every((v) => v === false)).toBe(true);
  });
});

describe('parseCatalogDualWriteFlowAllowlist', () => {
  it('is empty when the env var is unset', () => {
    expect(parseCatalogDualWriteFlowAllowlist().size).toBe(0);
  });

  it.each(['', '   ', ',', ' , '])('is empty for %j (missing/whitespace/empty tokens)', (value) => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS = value;
    expect(parseCatalogDualWriteFlowAllowlist().size).toBe(0);
  });

  it('parses a clean comma-separated list of known identifiers', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS = 'PACK_LOAD,ADMIN_DAILY_IMPORT';
    const allowlist = parseCatalogDualWriteFlowAllowlist();
    expect(allowlist.has('PACK_LOAD')).toBe(true);
    expect(allowlist.has('ADMIN_DAILY_IMPORT')).toBe(true);
    expect(allowlist.has('CHALLENGE_THE_HOUSE')).toBe(false);
  });

  it('tolerates surrounding whitespace around tokens', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS = ' PACK_LOAD , ADMIN_DAILY_IMPORT ';
    const allowlist = parseCatalogDualWriteFlowAllowlist();
    expect(allowlist.size).toBe(2);
  });

  it('fails closed (empty set) when any token is unrecognized, even alongside valid ones', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS = 'PACK_LOAD,BULK_IMPORT';
    expect(parseCatalogDualWriteFlowAllowlist().size).toBe(0);
  });

  it('fails closed on lowercase or mistyped tokens (no case-folding)', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS = 'pack_load';
    expect(parseCatalogDualWriteFlowAllowlist().size).toBe(0);
  });

  it('never throws even if process.env access misbehaves', () => {
    const original = process.env;
    try {
      process.env = new Proxy({}, { get() { throw new Error('boom'); } }) as NodeJS.ProcessEnv;
      expect(() => parseCatalogDualWriteFlowAllowlist()).not.toThrow();
      expect(parseCatalogDualWriteFlowAllowlist().size).toBe(0);
    } finally {
      process.env = original;
    }
  });
});

describe('isCatalogDualWriteFlowAllowed', () => {
  it('is false for every flow when the master flag is off, regardless of allowlist', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS = 'PACK_LOAD,ADMIN_DAILY_IMPORT,CHALLENGE_THE_HOUSE';
    expect(isCatalogDualWriteFlowAllowed('PACK_LOAD')).toBe(false);
    expect(isCatalogDualWriteFlowAllowed('ADMIN_DAILY_IMPORT')).toBe(false);
    expect(isCatalogDualWriteFlowAllowed('CHALLENGE_THE_HOUSE')).toBe(false);
  });

  it('is false for every flow when the master flag is on but the allowlist is empty', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG = 'true';
    expect(isCatalogDualWriteFlowAllowed('PACK_LOAD')).toBe(false);
    expect(isCatalogDualWriteFlowAllowed('ADMIN_DAILY_IMPORT')).toBe(false);
    expect(isCatalogDualWriteFlowAllowed('CHALLENGE_THE_HOUSE')).toBe(false);
  });

  it('matches the Phase 2 closeout §4 approved production configuration exactly', () => {
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG = 'true';
    process.env.FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS = 'PACK_LOAD,ADMIN_DAILY_IMPORT';
    expect(isCatalogDualWriteFlowAllowed('PACK_LOAD')).toBe(true);
    expect(isCatalogDualWriteFlowAllowed('ADMIN_DAILY_IMPORT')).toBe(true);
    expect(isCatalogDualWriteFlowAllowed('CHALLENGE_THE_HOUSE')).toBe(false);
  });
});
