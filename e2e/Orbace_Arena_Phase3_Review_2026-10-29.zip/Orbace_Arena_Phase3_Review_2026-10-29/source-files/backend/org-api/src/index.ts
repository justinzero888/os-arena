import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import multipart from '@fastify/multipart';
import cookie from '@fastify/cookie';
import { csrfGuard } from './middleware/csrf.middleware.js';
import { healthRoutes } from './routes/health.routes.js';
import { authRoutes } from './routes/auth.routes.js';
import { sessionRoutes } from './routes/session.routes.js';
import { orgRoutes } from './routes/org.routes.js';
import { playerRoutes } from './routes/player.routes.js';
import { supuRoutes } from './routes/supu.routes.js';
import { supuLabRoutes } from './routes/supu-lab.routes.js';
import { supuAnnotationRoutes } from './routes/supu-annotation.routes.js';
import { supuStoryRoutes } from './routes/supu-story.routes.js';
import { v1CanonicalRoutes } from './routes/v1-canonical.routes.js';
import { puzzleRoutes } from './routes/puzzle.routes.js';
import { featuredRoutes } from './routes/featured.routes.js';
import { packsRoutes } from './routes/packs.routes.js';
import { blogRoutes } from './routes/blog.routes.js';
import { attemptsRoutes } from './routes/attempts.routes.js';
import { replaysRoutes } from './routes/replays.routes.js';
import { scholarPathRoutes } from './routes/scholar-path.routes.js';
import { bulkImportRoutes } from './routes/bulk-import.routes.js';
import { teaMomentRoutes } from './routes/tea-moment.routes.js';
import { rankingRoutes } from './routes/ranking.routes.js';
import { dailyRoutes } from './routes/daily.routes.js';
import { grandRoutes } from './routes/grand.routes.js';
import { competitionRoutes } from './routes/competition.routes.js';
import { rankingHistoryRoutes } from './routes/ranking-history.routes.js';
import { appealRoutes } from './routes/appeal.routes.js';
import { premiumRoutes } from './routes/premium.routes.js';
import { webhookRoutes } from './routes/webhook.routes.js';
import { adminRoutes } from './routes/admin.routes.js';
import { solveRoutes } from './routes/solve.routes.js';
import { studyblogRoutes } from './routes/studyblog.routes.js';
import { studiesRoutes } from './routes/studies.routes.js';
import { promotionRoutes } from './routes/promotion.routes.js';
import { challengeRoutes } from './routes/challenge.routes.js';
import { arenaRoutes } from './routes/arena.routes.js';

// trustProxy: the app runs behind Fly.io's proxy, which terminates the TCP
// connection and forwards the real client address in `Fly-Client-IP` /
// `X-Forwarded-For`. Without this, Fastify's `req.ip` is the *proxy's*
// address, so every caller shares one identity — which made the global
// rate limiter below a single shared 100/min bucket (any burst 429'd every
// user; first noticed as prod-smoke 429s on 2026-09-11) and made the two
// `req.ip`-derived abuse hashes proxy-wide rather than per-client.
const server = Fastify({ logger: true, trustProxy: true });

// Explicit CORS allow-list instead of reflecting every origin. Requests with no
// Origin header (same-origin, curl, mobile apps) and localhost dev are allowed;
// browser requests from any other site are rejected.
const ALLOWED_ORIGINS = [
  'https://orbacesudoku.com',
  'https://www.orbacesudoku.com',
  // apps/web (Flutter), deployed separately from orbace-v4-frontend per the
  // housecleaning plan's D1 decision — stable production domain of the
  // `orbace-sudoku-web` Vercel project, not yet aliased to a custom domain.
  'https://orbace-sudoku-web.vercel.app',
];

async function main() {
  await server.register(cors, {
    origin(origin, cb) {
      // 127.0.0.1 alongside localhost: same loopback machine, and local UAT
      // docs steer devs to 127.0.0.1 specifically (Chrome/Safari sometimes
      // auto-upgrade plain-HTTP `localhost` to HTTPS, which a local static
      // server can't serve) — found 2026-09-16 when that combination left
      // `/player/me` CORS-rejected with no console error, silently wiping
      // an injected dev session on every page load.
      if (!origin || ALLOWED_ORIGINS.includes(origin) || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
        cb(null, true);
      } else {
        cb(null, false);
      }
    },
    credentials: true,
  });
  await server.register(helmet);
  // Global fallback limit; sensitive routes set tighter per-route limits via
  // `config.rateLimit` (see auth/org/supu/admin routes). Key on the real
  // client, preferring Fly's own immutable `Fly-Client-IP` header (Fly sets
  // it and does not let clients override it) over `req.ip` — with
  // `trustProxy` on, `req.ip` is also the real client, but the explicit
  // header is not influenced by a client-supplied `X-Forwarded-For`.
  await server.register(rateLimit, {
    max: 100,
    timeWindow: '1 minute',
    keyGenerator: (req) => {
      const flyIp = req.headers['fly-client-ip'];
      return (typeof flyIp === 'string' && flyIp) ? flyIp : req.ip;
    },
  });
  // Blog redesign (2026-07-18): admin image upload (POST /admin/blog/upload-image)
  // is the only multipart consumer. 5MB cap matches the endpoint's own
  // content-length/size validation — set here too so an oversized body is
  // rejected before fully buffering into memory.
  await server.register(multipart, { limits: { fileSize: 5 * 1024 * 1024 } });
  // Parsing/serialization only — no secret/signing. The session cookie
  // carries an opaque random token; legitimacy comes from the DB lookup
  // (only a real, server-issued token's hash matches a row), not a
  // cryptographic signature on the cookie value itself. See
  // session.service.ts.
  await server.register(cookie);
  // ADR-008: global, not per-route — covers every mutating endpoint
  // uniformly rather than relying on 16+ route files each remembering to
  // call it. No-ops for any request without our session cookie (bearer-only
  // requests, or literally everything while USE_COOKIE_SESSIONS is off).
  server.addHook('preHandler', csrfGuard);

  await server.register(healthRoutes);
  await server.register(authRoutes);
  await server.register(sessionRoutes);
  await server.register(orgRoutes);
  await server.register(playerRoutes);
  await server.register(supuRoutes);
  await server.register(supuLabRoutes);
  await server.register(supuAnnotationRoutes);
  await server.register(supuStoryRoutes);
  await server.register(v1CanonicalRoutes);
  await server.register(puzzleRoutes);
  await server.register(featuredRoutes);
  await server.register(packsRoutes);
  await server.register(blogRoutes);
  await server.register(attemptsRoutes);
  await server.register(replaysRoutes);
  await server.register(scholarPathRoutes);
  await server.register(bulkImportRoutes);
  await server.register(teaMomentRoutes);
  await server.register(rankingRoutes);
  await server.register(dailyRoutes);
  await server.register(grandRoutes);
  await server.register(competitionRoutes);
  await server.register(rankingHistoryRoutes);
  await server.register(appealRoutes);
  await server.register(premiumRoutes);
  await server.register(promotionRoutes);
  await server.register(challengeRoutes);
  await server.register(arenaRoutes);
  await server.register(webhookRoutes);
  await server.register(adminRoutes);
  await server.register(solveRoutes);
  await server.register(studyblogRoutes);
  await server.register(studiesRoutes);

  const port = parseInt(process.env.PORT || '8080', 10);
  await server.listen({ port, host: '0.0.0.0' });
  console.log(`ORG API running on port ${port}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
