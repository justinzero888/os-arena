-- Arena pilot data model. This migration is deliberately not applied by
-- this task; production and shared environments require the existing
-- reviewed migration process. RLS is enabled atomically below; the
-- companion 019_arena_pilot.sql is an idempotent operational verification aid.
BEGIN;

CREATE TABLE "arena_sessions" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "series_id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "prior_session_id" UUID,
  "host_user_id" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'BALLOT_OPEN',
  "version" INTEGER NOT NULL DEFAULT 1,
  "host_default_preset" TEXT NOT NULL DEFAULT 'easy',
  "ballot_closes_at" TIMESTAMP(3) NOT NULL,
  "paused_at" TIMESTAMP(3),
  "paused_phase" TEXT,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  "expires_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "arena_sessions_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "arena_sessions_host_created_idx" ON "arena_sessions"("host_user_id", "created_at");
CREATE INDEX "arena_sessions_status_expiry_idx" ON "arena_sessions"("status", "expires_at");
CREATE INDEX "arena_sessions_series_created_idx" ON "arena_sessions"("series_id", "created_at");
CREATE UNIQUE INDEX "arena_sessions_prior_session_id_key" ON "arena_sessions"("prior_session_id");
ALTER TABLE "arena_sessions" ADD CONSTRAINT "arena_sessions_prior_session_id_fkey"
  FOREIGN KEY ("prior_session_id") REFERENCES "arena_sessions"("id") ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE "arena_rounds" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "session_id" UUID NOT NULL,
  "number" INTEGER NOT NULL,
  "phase" TEXT NOT NULL DEFAULT 'BALLOT',
  "preset" TEXT,
  "puzzle_id" TEXT,
  "givens" TEXT,
  "solution" TEXT,
  "board_state" TEXT,
  "board_revision" INTEGER NOT NULL DEFAULT 0,
  "started_at" TIMESTAMP(3),
  "deadline_at" TIMESTAMP(3),
  "ended_at" TIMESTAMP(3),
  "result" TEXT,
  "modifier" TEXT,
  "modifier_applied_seconds" INTEGER NOT NULL DEFAULT 0,
  "strike_status" TEXT NOT NULL DEFAULT 'NOT_OPEN',
  "strike_opened_at" TIMESTAMP(3),
  "strike_closes_at" TIMESTAMP(3),
  "strike_resolved_at" TIMESTAMP(3),
  "strike_choice" TEXT,
  "paused_duration_ms" INTEGER NOT NULL DEFAULT 0,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "arena_rounds_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "arena_rounds_session_number_key" UNIQUE ("session_id", "number"),
  CONSTRAINT "arena_rounds_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "arena_sessions"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "arena_rounds_session_phase_idx" ON "arena_rounds"("session_id", "phase");

CREATE TABLE "arena_votes" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "session_id" UUID NOT NULL,
  "guest_key_hash" TEXT NOT NULL,
  "kind" TEXT NOT NULL DEFAULT 'PRESET',
  "choice" TEXT NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "arena_votes_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "arena_votes_session_kind_guest_key" UNIQUE ("session_id", "kind", "guest_key_hash"),
  CONSTRAINT "arena_votes_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "arena_sessions"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "arena_votes_session_choice_idx" ON "arena_votes"("session_id", "choice");

CREATE TABLE "arena_events" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "session_id" UUID NOT NULL,
  "version" INTEGER NOT NULL,
  "command_key" TEXT,
  "type" TEXT NOT NULL,
  "payload" JSONB NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "arena_events_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "arena_events_session_version_key" UNIQUE ("session_id", "version"),
  CONSTRAINT "arena_events_session_command_key" UNIQUE ("session_id", "command_key"),
  CONSTRAINT "arena_events_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "arena_sessions"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "arena_events_session_created_idx" ON "arena_events"("session_id", "created_at");

CREATE TABLE "arena_solve_ingresses" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "session_id" UUID NOT NULL,
  "ingress_at" TIMESTAMP(3) NOT NULL,
  "lease_expires_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "arena_solve_ingresses_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "arena_solve_ingresses_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "arena_sessions"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX "arena_solve_ingresses_session_ingress_lease_idx"
  ON "arena_solve_ingresses"("session_id", "ingress_at", "lease_expires_at");

-- Private supply has no automatic promotion from public or official catalogs.
CREATE TABLE arena_puzzle_supply (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tier TEXT NOT NULL,
  givens TEXT NOT NULL,
  solution TEXT NOT NULL,
  eligible BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX arena_puzzle_supply_tier_eligible_idx ON arena_puzzle_supply(tier, eligible);
ALTER TABLE arena_puzzle_supply ENABLE ROW LEVEL SECURITY;

-- Protect private answers and identities atomically with table creation.
-- The companion SQL is safe to reapply during owner-reviewed operations.
ALTER TABLE arena_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_solve_ingresses ENABLE ROW LEVEL SECURITY;

COMMIT;
