-- Arena pilot RLS policy, companion to
-- backend/org-api/prisma/migrations/20261029130000_arena_pilot/migration.sql.
-- ARENA_ENABLED is application-gated and defaults off. These records are
-- backend-only: RLS is enabled with no Supabase client policies. The existing
-- Prisma service connection is the sole supported access path and remains a
-- trusted server credential.
-- The Prisma migration already enables RLS atomically at table creation;
-- these statements are intentionally safe to reapply after owner review.
ALTER TABLE arena_puzzle_supply ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_rounds ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE arena_solve_ingresses ENABLE ROW LEVEL SECURITY;

COMMENT ON COLUMN arena_rounds.solution IS 'Private backend-only Sudoku solution; never include in Arena DTOs.';
COMMENT ON TABLE arena_solve_ingresses IS 'Pre-body-parse solve tickets used to coordinate deadline resolution; expired tickets are ignored after bounded request lifetime.';
