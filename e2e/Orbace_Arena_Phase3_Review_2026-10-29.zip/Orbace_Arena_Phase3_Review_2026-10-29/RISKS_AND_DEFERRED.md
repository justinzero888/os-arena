# Risks and deferred work

- **Timing/concurrency:** pause, strike, solve, timeout, and cancellation transitions share a server-locked session. Deadline correctness remains the primary race risk; independently review ingress timestamps, pending solve lease expiry, lock ordering, and strike/deadline overlap. Regression coverage is documented in the backend tests.
- **Usage/time:** Phase 3 focused and full suites were run once after remediation. The standalone UI smoke suite is broad and verbose but passed.
- **Host selection:** the real pilot host ID is intentionally not configured; allowlist defaults empty. Requires separate approval.
- **Shared DB/RLS:** migration was run only on a fresh local database. Database-owner review and separately authorized shared migration are required.
- **Production integration:** no production settings, environment, domain, deployment, or feature enablement changed. `ARENA_ENABLED` remains off by default.
- **Puzzle bank:** rematch now excludes puzzles already used in the series, but supply must be curated to provide enough eligible unique puzzles. Existing guest vote-stuffing and small-bank product decisions remain deferred from earlier review and should be resolved before a public pilot.
- **External platforms:** Twitch, YouTube, Discord, and Reddit adapters remain explicitly out of scope.
- **Rematch semantics:** rematch creates a new Arena session linked by `seriesId` and `priorSessionId`, consistent with approved product contract. New session has a new ballot, clean round state, and fresh puzzle.
