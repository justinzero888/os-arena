# Security review evidence for independent reviewer

## Builder-verified evidence

- Host session authentication and `ARENA_ALLOWED_HOST_IDS` checks are used for host APIs; allowlist defaults empty.
- Mutating host commands retain Origin/CSRF protections, idempotency keys, version/revision checks, and route limits. CSRF middleware and Arena feature flag have unit coverage.
- Audience preset/strike voting is anonymous and cookie-backed; cookies are HttpOnly. Separate browser contexts verify guest cannot access host endpoint or edit host board.
- All host, guest, and overlay reads use an explicit projection. It omits the puzzle identifier and solution; terminal HOST-result projection also omits the completed board because that board equals the stored solution.
- Full correct candidates are never sent through the durable public board update route by the UI; that route rejects the exact stored solution. The solve route validates against server-stored solution and the successful response does not include it.
- PostgreSQL route tests inspect public/host/overlay payloads and real public puzzle lookup for solution and identifier leaks. Protected official puzzle collision returns conflict (fail closed).
- PostgreSQL integration test asserts RLS enabled for `arena_sessions`, `arena_rounds`, `arena_votes`, `arena_events`, `arena_solve_ingresses`, and `arena_puzzle_supply`.
- Solve-ingress tickets retain server ingress timestamps, bounded lease/timeout cleanup, and lock-serialized adjudication. Tests cover exact-deadline rejection, pending ingress, and expired orphan lease behavior. Reviewer should inspect deadline edge cases and transaction ordering in `arena.routes.ts` directly.

## Independent checks requested

Verify same-origin deployment behavior with the actual expected request origin/proxy configuration; inspect host and guest ownership checks; test unauthorized and cross-origin requests; review whether persisted partial boards can reveal any answer information; inspect RLS compatibility with the application's DB role; audit cleanup paths and concurrent deadline/solve traffic.

These are builder findings and pointers, not a substitute for independent source review.
