# Test results

Environment: Node v25.5.0, npm 11.9.0, Prisma CLI 6.19.3, TypeScript 5.9.3, Vitest 2.1.9, macOS arm64.

| Command / procedure | Result |
| --- | --- |
| `cd backend/org-api && npm run build` | PASS, TypeScript build exit 0. |
| `DATABASE_URL=postgresql://local:local@127.0.0.1:5432/arena_app backend/org-api/node_modules/.bin/prisma validate --schema backend/org-api/prisma/schema.prisma` | PASS, schema valid. |
| `node --check orbace-v4-frontend/js/arena.js && node --check orbace-v4-frontend/js/api.js` | PASS. |
| `node orbace-v4-frontend/test/smoke.test.js` | PASS, `ALL PASS`. |
| `cd backend/org-api && npm test` | PASS: 153 files passed, 3 skipped; 2,086 tests passed, 17 skipped. DB-backed Arena files are among skipped files in this no-DB run. |
| Fresh disposable PostgreSQL: `npx prisma migrate deploy`, `npx prisma generate`, `npm test -- --pool=forks --poolOptions.forks.singleFork src/routes/__tests__/arena.review.postgres.integration.test.ts src/routes/__tests__/arena.routes.postgres.integration.test.ts` | PASS: 2 files, 11 tests passed. All 48 migrations applied to the disposable local DB, including the local Arena migration. Cluster and data directory were removed afterward. |
| `git diff --check` | PASS, exit 0. |
| Feature flag default/off | PASS in feature-flag and route tests. Arena turns on only when `ARENA_ENABLED` is exactly `true`; absent, false, or any other value disables it. |

The first serial full-suite attempt showed four unrelated timing failures in existing Su-Pu body-limit and PDF tests. Both files passed in isolation; the repository's normal `npm test` worker-pool run then passed in full. No source change was made for those transient failures.

Full raw outputs are in `test-logs/`. No production/shared DB or external service was used.
