import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createHash } from 'node:crypto';
import Fastify from 'fastify';
import cookie from '@fastify/cookie';
import rateLimit from '@fastify/rate-limit';
import { request as httpRequest } from 'node:http';
import { setTimeout as sleep } from 'node:timers/promises';

const sessionId = '11111111-1111-4111-8111-111111111111';
const solution = '534678912672195348198342567859761423426853791713924856961537284287419635345286179';
const givens = '530070000600195000098000060800060003400803001700020006060000280000419005000080079';

const state = vi.hoisted(() => ({
  enabled: false,
  allowlist: new Set<string>(),
  user: { sub: 'verified-host' } as { sub: string } | null,
  session: null as any,
  calls: [] as string[],
}));

const transaction = vi.hoisted(() => ({
  $queryRaw: vi.fn(async () => []),
  arenaSession: {
    create: vi.fn(async ({ data }: any) => ({ id: sessionId, version: 1, status: 'BALLOT_OPEN', ...data })),
    findUnique: vi.fn(async () => state.session),
    findFirst: vi.fn(async () => null),
    update: vi.fn(async (_args?: any) => ({})),
  },
  arenaRound: { create: vi.fn(async () => ({})), findMany: vi.fn(async () => []), update: vi.fn(async () => ({})) },
  arenaVote: { upsert: vi.fn(async (_args: any) => ({})) },
  arenaEvent: { create: vi.fn(async () => ({})), findFirst: vi.fn(async () => null) },
  arenaSolveIngress: { count: vi.fn(async () => 0), create: vi.fn(async () => ({ id: 'ticket' })), deleteMany: vi.fn(async () => ({ count: 1 })) },
  arenaPuzzleSupply: { findMany: vi.fn(async () => [{ id: 'puzzle-1', givens, solution }]) },
  puzzleDaily: { findFirst: vi.fn(async () => null) },
  puzzlePool: { findFirst: vi.fn(async () => null) },
  packPuzzle: { findFirst: vi.fn(async () => null) },
  puzzle: { findFirst: vi.fn(async () => null) },
  canonicalPuzzle: { findFirst: vi.fn(async () => null) },
}));

const prismaMock = vi.hoisted(() => ({
  $transaction: vi.fn(async (callback: (tx: typeof transaction) => unknown) => callback(transaction)),
  arenaSolveIngress: transaction.arenaSolveIngress,
  playerAccount: { findFirst: vi.fn(async (_args: any): Promise<{ id: string } | null> => null) },
}));
const authMock = vi.hoisted(() => vi.fn(async () => state.user));

vi.mock('../../lib/prisma.js', () => ({ prisma: prismaMock }));
vi.mock('../../middleware/auth.middleware.js', () => ({ authenticate: authMock, tryAuthenticate: authMock }));
vi.mock('../../lib/feature-flags.js', () => ({
  isArenaEnabled: () => state.enabled,
  arenaHostAllowlist: () => state.allowlist,
  arenaAllowedOrigins: () => new Set<string>(),
}));

import { arenaRoutes } from '../arena.routes.js';

async function makeApp() {
  const app = Fastify();
  await app.register(cookie);
  await app.register(rateLimit);
  await app.register(arenaRoutes);
  return app;
}

function sessionRow(overrides: Record<string, unknown> = {}) {
  return {
    id: sessionId,
    seriesId: '11111111-1111-4111-8111-111111111112',
    priorSessionId: null,
    hostUserId: 'verified-host',
    status: 'PLAYING',
    version: 8,
    hostDefaultPreset: 'quick',
    ballotClosesAt: new Date(Date.now() - 1000),
    pausedAt: null,
    pausedPhase: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    expiresAt: new Date(Date.now() + 3600_000),
    votes: [{ id: 'private-vote', guestKeyHash: 'private-guest-hash', kind: 'PRESET', choice: 'quick' }],
    rounds: [{
      id: 'round-1', number: 1, phase: 'PLAYING', preset: 'quick', puzzleId: 'puzzle-1',
      givens, solution, startedAt: new Date(), deadlineAt: new Date(Date.now() + 60_000),
      endedAt: null, result: null, modifier: null, boardState: givens, boardRevision: 0,
      strikeStatus: 'NOT_OPEN', strikeOpenedAt: null, strikeClosesAt: null, strikeResolvedAt: null,
      strikeChoice: null, modifierAppliedSeconds: 0, pausedDurationMs: 0,
    }],
    ...overrides,
  };
}

beforeEach(() => {
  state.enabled = false;
  state.allowlist = new Set();
  state.user = { sub: 'verified-host' };
  state.session = sessionRow();
  state.calls.length = 0;
  vi.clearAllMocks();
  process.env.ARENA_ENABLED = 'false';
  delete process.env.ARENA_ALLOWED_ORIGINS;
  transaction.$queryRaw.mockResolvedValue([]);
  transaction.arenaSession.findUnique.mockImplementation(async () => state.session);
  transaction.arenaSession.findFirst.mockResolvedValue(null);
  transaction.arenaSession.update.mockImplementation((async ({ data }: any) => {
    state.session = { ...state.session, ...data, version: typeof data.version === 'number' ? data.version : state.session.version };
    return state.session;
  }) as any);
  transaction.arenaRound.update.mockImplementation((async ({ where, data }: any) => {
    if (state.session?.rounds) state.session.rounds = state.session.rounds.map((round: any) => round.id === where.id ? { ...round, ...data } : round);
    return state.session?.rounds?.find((round: any) => round.id === where.id) || {};
  }) as any);
  transaction.arenaVote.upsert.mockImplementation((async ({ where, create, update }: any) => {
    const kind = where.sessionId_kind_guestKeyHash.kind;
    const guestKeyHash = where.sessionId_kind_guestKeyHash.guestKeyHash;
    const prior = state.session.votes.find((vote: any) => vote.kind === kind && vote.guestKeyHash === guestKeyHash);
    if (prior) prior.choice = update.choice;
    else state.session.votes.push(create);
    return prior || create;
  }) as any);
  transaction.arenaEvent.findFirst.mockResolvedValue(null);
  prismaMock.$transaction.mockImplementation(async (callback) => callback(transaction));
  authMock.mockImplementation(async () => state.user);
});

afterEach(() => {
  vi.useRealTimers();
  delete process.env.ARENA_ENABLED;
  delete process.env.ARENA_ALLOWED_HOST_IDS;
  delete process.env.ARENA_ALLOWED_ORIGINS;
});

describe('Arena app integration boundary', () => {
  it('redacts unexpected database errors and rejects malformed UUIDs before querying', async () => {
    state.enabled = true;
    const app = await makeApp();
    const invalid = await app.inject({ method: 'GET', url: `/api/arena/sessions/${'-'.repeat(36)}` });
    expect(invalid.statusCode).toBe(404);
    expect(prismaMock.$transaction).not.toHaveBeenCalled();
    prismaMock.$transaction.mockRejectedValueOnce(new Error(`private database detail: ${solution}`));
    const failure = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
    expect(failure.statusCode).toBe(503);
    expect(failure.json()).toEqual({ error: 'Arena is temporarily unavailable' });
    expect(failure.body).not.toContain(solution);
    expect(failure.headers['cache-control']).toBe('no-store');
    await app.close();
  });

  it.each([
    { votes: [], hostDefaultPreset: 'endurance', selected: 'endurance' },
    { votes: [{ kind: 'PRESET', choice: 'quick' }, { kind: 'PRESET', choice: 'endurance' }], hostDefaultPreset: 'endurance', selected: 'quick' },
    { votes: [{ kind: 'PRESET', choice: 'standard' }, { kind: 'PRESET', choice: 'endurance' }], hostDefaultPreset: 'quick', selected: 'standard' },
  ])('selects $selected for no-vote default or fixed tie priority', async ({ votes, hostDefaultPreset, selected }) => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'READY', votes, hostDefaultPreset });
    const app = await makeApp();
    const response = await app.inject({ method: 'POST', url: `/api/arena/sessions/${sessionId}/start`,
      headers: { 'idempotency-key': 'start-preset-test' }, payload: { expectedVersion: 8 } });
    expect(response.statusCode).toBe(200);
    expect(transaction.arenaRound.update).toHaveBeenCalledWith(expect.objectContaining({ data: expect.objectContaining({ preset: selected }) }));
    expect(transaction.arenaPuzzleSupply.findMany).toHaveBeenCalledWith(expect.objectContaining({
      where: expect.objectContaining({ tier: 'Extreme', eligible: true }),
    }));
    await app.close();
  });

  it('lets the host start while the ballot is open using votes already cast', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'BALLOT_OPEN', ballotClosesAt: new Date(Date.now() + 30_000), votes: [{ kind: 'PRESET', choice: 'standard' }] });
    const app = await makeApp();
    const response = await app.inject({ method: 'POST', url: `/api/arena/sessions/${sessionId}/start`,
      headers: { 'idempotency-key': 'start-open-ballot-test' }, payload: { expectedVersion: 8 } });
    expect(response.statusCode).toBe(200);
    expect(transaction.arenaRound.update).toHaveBeenCalledWith(expect.objectContaining({ data: expect.objectContaining({ preset: 'standard' }) }));
    await app.close();
  });

  it('returns 404 before authentication or database access when the flag is off', async () => {
    const app = await makeApp();
    const health = await app.inject({ method: 'GET', url: '/api/arena/health' });
    const create = await app.inject({ method: 'POST', url: '/api/arena/sessions', payload: {} });
    expect(health.statusCode).toBe(404);
    expect(create.statusCode).toBe(404);
    expect(authMock).not.toHaveBeenCalled();
    expect(prismaMock.$transaction).not.toHaveBeenCalled();
    await app.close();
  });

  it('requires a verified allowlisted Orbace identity before session creation', async () => {
    state.enabled = true;
    state.allowlist = new Set(['some-other-user']);
    const app = await makeApp();
    const response = await app.inject({ method: 'POST', url: '/api/arena/sessions', payload: {} });
    expect(response.statusCode).toBe(403);
    expect(transaction.arenaSession.create).not.toHaveBeenCalled();
    await app.close();
  });

  it('creates a session for the authenticated allowlisted host without returning host capability', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'BALLOT_OPEN' });
    transaction.arenaSession.findUnique.mockResolvedValue(state.session);
    const app = await makeApp();
    const response = await app.inject({ method: 'POST', url: '/api/arena/sessions', payload: { defaultPreset: 'quick' } });
    expect(response.statusCode).toBe(201);
    expect(transaction.arenaSession.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ hostUserId: 'verified-host', hostDefaultPreset: 'quick' }),
    }));
    expect(response.json()).not.toHaveProperty('hostUserId');
    expect(response.json()).not.toHaveProperty('hostCapability');
    await app.close();
  });

  it('rejects legacy difficulty labels as time modes', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    const app = await makeApp();
    const response = await app.inject({ method: 'POST', url: '/api/arena/sessions', payload: { defaultPreset: 'easy' } });
    expect(response.statusCode).toBe(400);
    expect(response.json()).toEqual({ error: 'Invalid default time mode' });
    expect(prismaMock.$transaction).not.toHaveBeenCalled();
    await app.close();
  });

  it('keeps private solution and guest identity out of public snapshots', async () => {
    state.enabled = true;
    transaction.arenaSession.findUnique.mockResolvedValue(state.session);
    const app = await makeApp();
    const response = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
    expect(response.statusCode).toBe(200);
    expect(response.headers['cache-control']).toBe('no-store');
    const json = response.json();
    expect(JSON.stringify(json)).not.toContain(solution);
    expect(JSON.stringify(json)).not.toContain('private-guest-hash');
    expect(json).not.toHaveProperty('hostUserId');
    expect(json.round).toMatchObject({ givens });
    expect(json.round).not.toHaveProperty('puzzleId');
    await app.close();
  });

  it('does not finalize a timed-out round while an eligible pre-deadline solve ticket is active', async () => {
    state.enabled = true;
    state.session = sessionRow({ status: 'PLAYING', rounds: [{
      id: 'round-1', number: 1, phase: 'PLAYING', preset: 'quick', puzzleId: 'puzzle-1',
      givens, solution, startedAt: new Date(Date.now() - 180_000), deadlineAt: new Date(Date.now() - 16_000),
      endedAt: null, result: null, modifier: null,
    }] });
    transaction.arenaSolveIngress.count.mockResolvedValue(1);
    const app = await makeApp();
    const response = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
    expect(response.statusCode).toBe(200);
    expect(response.json().status).toBe('PLAYING');
    expect(transaction.arenaRound.update).not.toHaveBeenCalled();
    await app.close();
  });

  it('rejects a valid board whose server ingress is at or after the deadline', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'PLAYING', rounds: [{
      id: 'round-1', number: 1, phase: 'PLAYING', preset: 'quick', puzzleId: 'puzzle-1',
      givens, solution, startedAt: new Date(Date.now() - 180_000), deadlineAt: new Date(Date.now() - 100),
      endedAt: null, result: null, modifier: null,
    }] });
    const app = await makeApp();
    const response = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/solve`,
      headers: { 'idempotency-key': 'solve-late-1' },
      payload: { expectedVersion: 8, board: solution },
    });
    expect(response.statusCode).toBe(409);
    expect(transaction.arenaRound.update).not.toHaveBeenCalled();
    expect(transaction.arenaSolveIngress.create).not.toHaveBeenCalled();
    expect(transaction.arenaSolveIngress.deleteMany).not.toHaveBeenCalled();
    await app.close();
  });

  it('adjudicates a complete pre-deadline solve under the session lock and releases its ticket once', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'PLAYING', rounds: [{
      id: 'round-1', number: 1, phase: 'PLAYING', preset: 'quick', puzzleId: 'puzzle-1',
      givens, solution, startedAt: new Date(), deadlineAt: new Date(Date.now() + 60_000),
      endedAt: null, result: null, modifier: null,
    }] });
    const app = await makeApp();
    const response = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/solve`,
      headers: { 'idempotency-key': 'solve-valid-1' },
      payload: { expectedVersion: 8, board: solution },
    });
    expect(response.statusCode).toBe(200);
    expect(transaction.arenaRound.update).toHaveBeenCalledWith(expect.objectContaining({ data: expect.objectContaining({ result: 'HOST' }) }));
    expect(transaction.arenaSolveIngress.create).toHaveBeenCalledTimes(1);
    expect(transaction.arenaSolveIngress.deleteMany).toHaveBeenCalledTimes(1);
    await app.close();
  });

  it.each(['abort', 'premature-close', 'timeout'])('releases an incomplete body ticket once on %s, allowing timeout resolution', async (failure) => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'PLAYING', rounds: [{
      id: 'round-1', number: 1, phase: 'PLAYING', preset: 'quick', puzzleId: 'puzzle-1',
      givens, solution, startedAt: new Date(), deadlineAt: new Date(Date.now() + 10_000),
      endedAt: null, result: null, modifier: null,
    }] });
    transaction.arenaSolveIngress.count.mockResolvedValue(0);
    const app = await makeApp();
    const address = await app.listen({ host: '127.0.0.1', port: 0 });
    const port = Number(new URL(address).port);
    if (failure === 'timeout') vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
    const client = httpRequest({
      host: '127.0.0.1', port, method: 'POST', path: `/api/arena/sessions/${sessionId}/solve`,
      headers: { 'content-type': 'application/json', 'content-length': '200', 'idempotency-key': 'solve-abort-1' },
    });
    client.on('error', () => undefined);
    client.write('{"expectedVersion":8,');

    const waitForTicket = async () => {
      for (let attempt = 0; attempt < 100; attempt += 1) {
        if (transaction.arenaSolveIngress.create.mock.calls.length > 0) return;
        await sleep(5);
      }
      throw new Error('solve ingress ticket was not registered before body parsing');
    };
    await waitForTicket();
    state.session.rounds[0].deadlineAt = new Date(Date.now() - 16_000);
    if (failure === 'timeout') {
      await vi.advanceTimersByTimeAsync(15_001);
      vi.useRealTimers();
    } else if (failure === 'premature-close') {
      client.socket!.end();
    } else client.destroy();
    for (let attempt = 0; attempt < 100 && transaction.arenaSolveIngress.deleteMany.mock.calls.length === 0; attempt += 1) {
      await sleep(5);
    }

    expect(transaction.arenaSolveIngress.deleteMany).toHaveBeenCalledTimes(1);
    const snapshot = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
    expect(snapshot.statusCode).toBe(200);
    expect(snapshot.json().status).toBe('RESULT');
    expect(transaction.arenaRound.update).toHaveBeenCalledWith(expect.objectContaining({ data: expect.objectContaining({ result: 'AUDIENCE' }) }));
    await app.close();
  });

  it('keeps a complete solve ticket during delayed adjudication even after the old body timer would fire', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow();
    state.session.rounds[0].deadlineAt = new Date(Date.now() + 100);
    transaction.arenaSolveIngress.count.mockResolvedValue(1);
    let markEntered!: () => void;
    let proceed!: () => void;
    const entered = new Promise<void>((resolve) => { markEntered = resolve; });
    const gate = new Promise<void>((resolve) => { proceed = resolve; });
    const app = Fastify();
    await app.register(cookie);
    await app.register(rateLimit);
    app.addHook('preHandler', async (request) => {
      if (request.url.endsWith('/solve')) { markEntered(); await gate; }
    });
    await app.register(arenaRoutes);
    const solving = app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/solve`,
      headers: { 'idempotency-key': 'solve-delayed-complete' }, payload: { expectedVersion: 8, board: solution },
    }).then((response) => response);
    try {
      await entered;
      vi.useFakeTimers({ toFake: ['Date', 'setTimeout', 'clearTimeout'] });
      await vi.advanceTimersByTimeAsync(16_000);
      const poll = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
      expect(poll.json().status).toBe('PLAYING');
      expect(transaction.arenaSolveIngress.deleteMany).not.toHaveBeenCalled();
      proceed();
      expect((await solving).statusCode).toBe(200);
      expect(transaction.arenaRound.update).toHaveBeenCalledWith(expect.objectContaining({ data: expect.objectContaining({ result: 'HOST' }) }));
      expect(transaction.arenaSolveIngress.deleteMany).toHaveBeenCalledTimes(1);
      expect(prismaMock.$transaction).toHaveBeenCalledWith(expect.any(Function), { maxWait: 5_000, timeout: 10_000 });
    } finally {
      proceed();
      vi.useRealTimers();
      await app.close();
    }
  });

  it('uses ingress captured before asynchronous host authentication', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    vi.useFakeTimers({ toFake: ['Date'] });
    const ingress = Date.now();
    state.session = sessionRow();
    state.session.rounds[0].deadlineAt = new Date(ingress + 100);
    authMock.mockImplementationOnce(async () => {
      vi.setSystemTime(ingress + 500);
      return state.user;
    });
    const app = await makeApp();
    const response = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/solve`,
      headers: { 'idempotency-key': 'solve-delayed-auth' }, payload: { expectedVersion: 8, board: solution },
    });
    expect(response.statusCode).toBe(200);
    expect(transaction.arenaSolveIngress.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ ingressAt: new Date(ingress) }),
    }));
    await app.close();
  });

  it('rejects exact-deadline ingress and avoids registering tickets for non-owning hosts', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    vi.useFakeTimers({ toFake: ['Date'] });
    state.session = sessionRow();
    state.session.rounds[0].deadlineAt = new Date();
    const app = await makeApp();
    const request = { method: 'POST' as const, url: `/api/arena/sessions/${sessionId}/solve`,
      headers: { 'idempotency-key': 'solve-at-deadline' }, payload: { expectedVersion: 8, board: solution } };
    expect((await app.inject(request)).statusCode).toBe(409);
    state.session.hostUserId = 'someone-else';
    expect((await app.inject(request)).statusCode).toBe(404);
    expect(transaction.arenaSolveIngress.create).not.toHaveBeenCalled();
    await app.close();
  });

  it('replays a solve command after terminal result without a new ingress ticket; other command types conflict', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'RESULT' });
    transaction.arenaEvent.findFirst.mockResolvedValue({ type: 'ROUND_SOLVED' } as any);
    const app = await makeApp();
    const request = { method: 'POST' as const, url: `/api/arena/sessions/${sessionId}/solve`,
      headers: { 'idempotency-key': 'solve-replay-1' }, payload: { expectedVersion: 8, board: solution } };
    expect((await app.inject(request)).statusCode).toBe(200);
    transaction.arenaEvent.findFirst.mockResolvedValue({ type: 'ROUND_STARTED' } as any);
    expect((await app.inject(request)).statusCode).toBe(409);
    expect(transaction.arenaSolveIngress.create).not.toHaveBeenCalled();
    expect(transaction.arenaRound.update).not.toHaveBeenCalled();
    await app.close();
  });

  it('requires the exact request origin scheme for mutating votes', async () => {
    state.enabled = true;
    state.session = sessionRow({ status: 'BALLOT_OPEN', ballotClosesAt: new Date(Date.now() + 30_000) });
    const app = await makeApp();
    const response = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/votes`,
      headers: { origin: 'https://localhost:80' }, payload: { choice: 'quick' },
    });
    expect(response.statusCode).toBe(403);
    expect(transaction.arenaVote.upsert).not.toHaveBeenCalled();
    await app.close();
  });

  it('accepts an anonymous Demo Mode vote with one opaque browser cookie', async () => {
    state.enabled = true;
    state.user = null;
    state.session = sessionRow({ status: 'BALLOT_OPEN', ballotClosesAt: new Date(Date.now() + 30_000), votes: [] });
    transaction.arenaVote.upsert.mockClear();
    const app = await makeApp();
    const first = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/votes`,
      headers: { origin: 'http://localhost:80' }, payload: { choice: 'standard' },
    });
    expect(first.statusCode).toBe(200);
    const setCookie = String(first.headers['set-cookie']);
    expect(setCookie).toContain('arena_voter=');
    const cookie = setCookie.split(';')[0];
    const second = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/votes`,
      headers: { origin: 'http://localhost:80', cookie }, payload: { choice: 'endurance' },
    });
    expect(second.statusCode).toBe(200);
    const calls = transaction.arenaVote.upsert.mock.calls;
    expect(calls).toHaveLength(2);
    const firstHash = calls[0][0].where.sessionId_kind_guestKeyHash.guestKeyHash;
    const secondHash = calls[1][0].where.sessionId_kind_guestKeyHash.guestKeyHash;
    expect(secondHash).toBe(firstHash);
    await app.close();
  });

  it('accepts the exact legitimate same-origin authenticated vote', async () => {
    state.enabled = true;
    state.session = sessionRow({ status: 'BALLOT_OPEN', ballotClosesAt: new Date(Date.now() + 30_000) });
    const app = await makeApp();
    const response = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/votes`,
      headers: { origin: 'http://localhost:80' }, payload: { choice: 'standard' },
    });
    expect(response.statusCode).toBe(200);
    const voterKeyHash = createHash('sha256').update('verified-host').digest('hex');
    expect(transaction.arenaVote.upsert).toHaveBeenCalledWith(expect.objectContaining({
      where: { sessionId_kind_guestKeyHash: { sessionId, kind: 'PRESET', guestKeyHash: voterKeyHash } },
      create: expect.objectContaining({ sessionId, kind: 'PRESET', guestKeyHash: voterKeyHash, choice: 'standard' }),
    }));
    expect(response.json()).not.toHaveProperty('guestKeyHash');
    expect(response.headers['set-cookie']).toBeUndefined();
    await app.close();
  });

  it('updates one effective vote when the same authenticated user votes again', async () => {
    state.enabled = true;
    state.session = sessionRow({ status: 'BALLOT_OPEN', ballotClosesAt: new Date(Date.now() + 30_000), votes: [] });
    const app = await makeApp();
    const first = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/votes`,
      headers: { origin: 'http://localhost:80' }, payload: { choice: 'quick' },
    });
    const second = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/votes`,
      headers: { origin: 'http://localhost:80' }, payload: { choice: 'endurance' },
    });
    expect(first.statusCode).toBe(200);
    expect(second.statusCode).toBe(200);
    expect(state.session.votes.filter((vote: any) => vote.kind === 'PRESET')).toHaveLength(1);
    expect(state.session.votes.find((vote: any) => vote.kind === 'PRESET').choice).toBe('endurance');
    await app.close();
  });

  it('keys distinct bearer-only users by Supabase subject without an empty OR branch', async () => {
    state.enabled = true;
    state.session = sessionRow({ status: 'BALLOT_OPEN', ballotClosesAt: new Date(Date.now() + 30_000), votes: [] });
    transaction.arenaVote.upsert.mockClear();
    const findFirst = prismaMock.playerAccount.findFirst;
    findFirst.mockImplementation(async ({ where }: any) => {
      const branches = Array.isArray(where?.OR) ? where.OR : [];
      if (branches.some((branch: any) => branch.tier1Uuid === undefined && branch.supabaseId === undefined)) return { id: 'unrelated-player' };
      if (where?.supabaseId === 'bearer-a') return { id: 'player-a' };
      if (where?.supabaseId === 'bearer-b') return { id: 'player-b' };
      return null;
    });
    const app = await makeApp();
    state.user = { sub: 'bearer-a' };
    const first = await app.inject({ method: 'POST', url: `/api/arena/sessions/${sessionId}/votes`, headers: { origin: 'http://localhost:80' }, payload: { choice: 'quick' } });
    state.user = { sub: 'bearer-b' };
    const second = await app.inject({ method: 'POST', url: `/api/arena/sessions/${sessionId}/votes`, headers: { origin: 'http://localhost:80' }, payload: { choice: 'standard' } });
    expect(first.statusCode).toBe(200);
    expect(second.statusCode).toBe(200);
    const hashes = transaction.arenaVote.upsert.mock.calls.map((call: any[]) => call[0].create.guestKeyHash);
    expect(hashes).toHaveLength(2);
    expect(hashes[0]).not.toBe(hashes[1]);
    expect(hashes[0]).toBe(createHash('sha256').update('player-a').digest('hex'));
    expect(hashes[1]).toBe(createHash('sha256').update('player-b').digest('hex'));
    findFirst.mockImplementation(async () => null);
    await app.close();
  });

  it('hides an Arena session from an allowlisted host who does not own it', async () => {
    state.enabled = true;
    state.allowlist = new Set(['other-allowed-host']);
    state.user = { sub: 'other-allowed-host' };
    const app = await makeApp();
    const response = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${sessionId}/start`,
      headers: { 'idempotency-key': 'start-command-1' }, payload: { expectedVersion: 8 },
    });
    expect(response.statusCode).toBe(409);
    expect(transaction.arenaRound.update).not.toHaveBeenCalled();
    await app.close();
  });

  it('returns host controls only to the owning authenticated allowlisted host', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'READY' });
    const app = await makeApp();
    const response = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}/host` });
    expect(response.statusCode).toBe(200);
    expect(response.json().hostControls).toEqual({ canStart: true, canSolve: false, canPause: false, canResume: false, canCancel: true });
    expect(JSON.stringify(response.json())).not.toContain(solution);
    expect(response.json()).not.toHaveProperty('hostUserId');
    await app.close();
  });

  it('persists host board revisions and returns them through the safe overlay projection', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow();
    const index = givens.indexOf('0');
    const nextBoard = givens.slice(0, index) + solution[index] + givens.slice(index + 1);
    const app = await makeApp();
    const update = await app.inject({ method: 'POST', url: `/api/arena/sessions/${sessionId}/board`,
      headers: { 'idempotency-key': 'board-revision-001' }, payload: { expectedRevision: 0, board: nextBoard } });
    expect(update.statusCode).toBe(200);
    expect(update.json().round.board).toBe(nextBoard);
    expect(update.json().round.boardRevision).toBe(1);
    const overlay = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}/overlay` });
    expect(overlay.statusCode).toBe(200);
    expect(overlay.json().round.board).toBe(nextBoard);
    expect(overlay.body).not.toContain(solution);
    expect(overlay.json().round).not.toHaveProperty('puzzleId');
    await app.close();
  });

  it('freezes the round deadline while technically paused and resumes with the remaining time', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow({ status: 'PLAYING' });
    const originalDeadline = state.session.rounds[0].deadlineAt.getTime();
    const app = await makeApp();
    const paused = await app.inject({ method: 'POST', url: `/api/arena/sessions/${sessionId}/pause`,
      headers: { 'idempotency-key': 'pause-command-01' }, payload: { expectedVersion: 8, confirmed: true } });
    expect(paused.statusCode).toBe(200);
    expect(paused.json().paused).toBe(true);
    expect(paused.json().status).toBe('PLAYING');
    await sleep(15);
    const resumed = await app.inject({ method: 'POST', url: `/api/arena/sessions/${sessionId}/resume`,
      headers: { 'idempotency-key': 'resume-command-01' }, payload: { expectedVersion: 9, confirmed: true } });
    expect(resumed.statusCode).toBe(200);
    expect(resumed.json().paused).toBe(false);
    expect(resumed.json().round.deadlineAt).toBe(state.session.rounds[0].deadlineAt.toISOString());
    expect(state.session.rounds[0].deadlineAt.getTime()).toBeGreaterThan(originalDeadline);
    expect(state.session.rounds[0].pausedDurationMs).toBeGreaterThan(0);
    await app.close();
  });

  it('opens one strike at 30% effective play time and resolves zero votes and ties as Spare', async () => {
    state.enabled = true;
    const round: any = sessionRow().rounds[0];
    round.startedAt = new Date(Date.now() - 60_000);
    round.deadlineAt = new Date(Date.now() + 120_000);
    round.strikeStatus = 'NOT_OPEN';
    state.session = sessionRow({ status: 'PLAYING', rounds: [round], votes: [] });
    const app = await makeApp();
    const opened = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
    expect(opened.json().round.strike.status).toBe('OPEN');
    expect(opened.json().round.strike.opensAt).not.toBeNull();
    expect(opened.json().round.strike.counts).toEqual({ penalty: 0, spare: 0 });
    state.session.rounds[0].strikeClosesAt = new Date(Date.now() - 1);
    let resolved = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
    expect(resolved.json().round.strike.choice).toBe('SPARED');
    expect(resolved.json().round.modifierAppliedSeconds).toBe(0);

    state.session.version += 1;
    state.session.rounds[0].strikeStatus = 'OPEN';
    state.session.rounds[0].strikeClosesAt = new Date(Date.now() - 1);
    state.session.votes = [
      { id: 'penalty-vote', kind: 'STRIKE', guestKeyHash: 'g1', choice: 'PENALTY' },
      { id: 'spare-vote', kind: 'STRIKE', guestKeyHash: 'g2', choice: 'SPARE' },
    ];
    resolved = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
    expect(resolved.json().round.strike.choice).toBe('SPARED');
    expect(resolved.json().round.modifierAppliedSeconds).toBe(0);
    await app.close();
  });

  it('applies only the time-penalty fallback when penalty votes win', async () => {
    state.enabled = true;
    const round: any = sessionRow().rounds[0];
    round.strikeStatus = 'OPEN';
    round.strikeOpenedAt = new Date(Date.now() - 16_000);
    round.strikeClosesAt = new Date(Date.now() - 1);
    round.deadlineAt = new Date(Date.now() + 120_000);
    state.session = sessionRow({ status: 'PLAYING', rounds: [round], votes: [
      { id: 'penalty-1', kind: 'STRIKE', guestKeyHash: 'g1', choice: 'PENALTY' },
      { id: 'penalty-2', kind: 'STRIKE', guestKeyHash: 'g2', choice: 'PENALTY' },
      { id: 'spare-1', kind: 'STRIKE', guestKeyHash: 'g3', choice: 'SPARE' },
    ] });
    const before = round.deadlineAt.getTime();
    const app = await makeApp();
    const result = await app.inject({ method: 'GET', url: `/api/arena/sessions/${sessionId}` });
    expect(result.json().round.strike.choice).toBe('TIME_PENALTY');
    expect(result.json().round.modifier).toBe('TIME_PENALTY');
    expect(result.json().round.modifierAppliedSeconds).toBe(10);
    expect(new Date(result.json().round.deadlineAt).getTime()).toBe(before - 10_000);
    await app.close();
  });

  it('requires explicit confirmation to cancel and records a no-winner terminal result', async () => {
    state.enabled = true;
    state.allowlist = new Set(['verified-host']);
    state.session = sessionRow();
    const app = await makeApp();
    const url = `/api/arena/sessions/${sessionId}/cancel`;
    const headers = { 'idempotency-key': 'cancel-command-01' };
    expect((await app.inject({ method: 'POST', url, headers, payload: { expectedVersion: 8, confirmed: false } })).statusCode).toBe(400);
    const cancelled = await app.inject({ method: 'POST', url, headers, payload: { expectedVersion: 8, confirmed: true } });
    expect(cancelled.statusCode).toBe(200);
    expect(cancelled.json().status).toBe('CANCELLED');
    expect(cancelled.json().round.result).toBe('CANCELLED');
    await app.close();
  });
});
