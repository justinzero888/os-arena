import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import cookie from '@fastify/cookie';
import rateLimit from '@fastify/rate-limit';
import puppeteer from 'puppeteer';
import { randomUUID } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import type { AddressInfo } from 'node:net';

// No auth or database mocks: these tests use a synthetic local player and
// the real Orbace session service, authenticate(), CSRF, Prisma and browser.
const databaseUrl = process.env.ARENA_TEST_DATABASE_URL;
const fixture = '22222222-2222-4222-8222-222222222222';
const protectedSupply = '33333333-3333-4333-8333-333333333333';
const protectedDaily = 'ARENA-REVIEW-PROTECTED-DAILY';
const givens = '860010000900438000032000090200090006700206004100050009090000520000743008000020013';
const solution = '867912345915438672432675891283194756759286134146357289394861527521743968678529413';
const protectedGivens = '970020000100549000043000010300010007800307005200060001010000630000854009000030024';
const protectedSolution = '978123456126549783543786912394215867861397245257468391415972638632854179789631524';
const hostSubject = 'arena-review-test-host';
const voterSubjects = ['arena-review-voter-1', 'arena-review-voter-2', 'arena-review-voter-3'];
const frontendRoot = resolve(process.cwd(), '../../orbace-v4-frontend');

(databaseUrl ? describe : describe.skip)('Arena canonical session security and PostgreSQL review', () => {
  let app: FastifyInstance;
  let prisma: typeof import('../../lib/prisma.js').prisma;
  let hostCookie: string;
  const playerId = randomUUID();
  const voterIds = voterSubjects.map(() => randomUUID());
  const voterCookies: string[] = [];
  const sessions: string[] = [];
  const previousEnv = new Map<string, string | undefined>();
  const headers = () => ({ cookie: `orbace_session=${hostCookie}`, origin: 'http://localhost:80' });
  const voterHeaders = (index: number) => ({ cookie: `orbace_session=${voterCookies[index]}`, origin: 'http://localhost:80' });

  beforeAll(async () => {
    const url = new URL(databaseUrl!);
    if (!['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.pathname !== '/arena_app') {
      throw new Error('ARENA_TEST_DATABASE_URL must be a disposable localhost database named arena_app');
    }
    const env = { DATABASE_URL: databaseUrl!, ARENA_ENABLED: 'true', ARENA_ALLOWED_HOST_IDS: hostSubject,
      USE_COOKIE_SESSIONS: 'true', TIER1_TOKEN_SECRET: 'arena-local-review-test-only-key',
      SUPABASE_URL: 'http://127.0.0.1:1', SUPABASE_ANON_KEY: 'local-review-placeholder' };
    for (const [name, value] of Object.entries(env)) { previousEnv.set(name, process.env[name]); process.env[name] = value; }
    ({ prisma } = await import('../../lib/prisma.js'));
    const { createSession } = await import('../../services/session.service.js');
    const { arenaRoutes } = await import('../arena.routes.js');
    const { puzzleRoutes } = await import('../puzzle.routes.js');
    const { csrfGuard } = await import('../../middleware/csrf.middleware.js');
    await prisma.playerAccount.create({ data: { id: playerId, tier1Uuid: hostSubject } });
    hostCookie = (await createSession(playerId, 'instant')).rawToken;
    for (let index = 0; index < voterIds.length; index += 1) {
      await prisma.playerAccount.create({ data: { id: voterIds[index], tier1Uuid: voterSubjects[index] } });
      voterCookies.push((await createSession(voterIds[index], 'instant')).rawToken);
    }
    await prisma.arenaPuzzleSupply.create({ data: { id: fixture, tier: 'Extreme', givens, solution, eligible: true, provenance: 'TEST_FIXTURE' } });
    app = Fastify({ trustProxy: true });
    await app.register(cookie);
    // Browser E2E polls multiple independently authenticated contexts. Keep
    // the app-wide limiter out of this fixture; Arena route limiters remain
    // registered and tested separately below.
    await app.register(rateLimit, { max: 1_000, timeWindow: '1 minute' });
    app.addHook('preHandler', csrfGuard);
    app.get('/__review', async (_request, reply) => reply.type('text/html').send('<!doctype html><title>Arena API review</title>'));
    const staticFiles: Array<[string, string, string]> = [
      ['/arena', 'arena.html', 'text/html'],
      ['/js/mock-data.js', 'js/mock-data.js', 'application/javascript'],
      ['/js/api.js', 'js/api.js', 'application/javascript'],
      ['/js/auth-session.js', 'js/auth-session.js', 'application/javascript'],
      ['/js/arena.js', 'js/arena.js', 'application/javascript'],
      ['/css/tokens.css', 'css/tokens.css', 'text/css'],
      ['/css/shell.css', 'css/shell.css', 'text/css'],
      ['/css/arena.css', 'css/arena.css', 'text/css'],
    ];
    app.get('/js/config.js', async (request, reply) => {
      const config = readFileSync(resolve(frontendRoot, 'js/config.js'), 'utf8');
      const localOrgApi = `${request.protocol}://${request.headers.host}`;
      return reply.type('application/javascript').send(config.replace(
        'ORG_API_URL: "https://justinzero.fly.dev"',
        `ORG_API_URL: "${localOrgApi}"`,
      ));
    });
    for (const [route, file, contentType] of staticFiles) {
      app.get(route, async (_request, reply) => reply.type(contentType).send(readFileSync(resolve(frontendRoot, file))));
    }
    await app.register(arenaRoutes);
    await app.register(puzzleRoutes);
  }, 15_000);

  afterAll(async () => {
    try {
      if (app) await app.close();
      if (prisma) {
        await prisma.arenaSession.deleteMany({ where: { id: { in: sessions } } });
        await prisma.officialEvent.deleteMany({ where: { puzzleId: protectedDaily } });
        await prisma.puzzleDaily.deleteMany({ where: { puzzleId: protectedDaily } });
        await prisma.arenaPuzzleSupply.deleteMany({ where: { id: protectedSupply } });
        await prisma.arenaPuzzleSupply.deleteMany({ where: { id: fixture } });
        await prisma.session.deleteMany({ where: { playerId: { in: [playerId, ...voterIds] } } });
        await prisma.playerAccount.deleteMany({ where: { id: { in: [playerId, ...voterIds] } } });
        await prisma.$disconnect();
      }
    } finally {
      for (const [name, value] of previousEnv) { if (value === undefined) delete process.env[name]; else process.env[name] = value; }
    }
  });

  async function createArena(defaultPreset = 'quick') {
    const response = await app.inject({ method: 'POST', url: '/api/arena/sessions', headers: headers(), payload: { defaultPreset } });
    expect(response.statusCode).toBe(201);
    sessions.push(response.json().id);
    return response.json().id as string;
  }

  it('uses real cookie auth/allowlist and rejects missing CSRF, wrong scheme, and anonymous hosts', async () => {
    const request = { method: 'POST' as const, url: '/api/arena/sessions', payload: {} };
    expect((await app.inject(request)).statusCode).toBe(401);
    expect((await app.inject({ ...request, headers: { cookie: `orbace_session=${hostCookie}` } })).statusCode).toBe(403);
    expect((await app.inject({ ...request, headers: { ...headers(), origin: 'https://localhost:80' } })).statusCode).toBe(403);
    process.env.ARENA_ALLOWED_HOST_IDS = '';
    expect((await app.inject({ ...request, headers: headers() })).statusCode).toBe(403);
    process.env.ARENA_ALLOWED_HOST_IDS = hostSubject;
    process.env.ARENA_ENABLED = 'false';
    expect((await app.inject({ ...request, headers: headers() })).statusCode).toBe(404);
    process.env.ARENA_ENABLED = 'true';
    const proxied = await app.inject({ ...request, headers: { ...headers(), host: 'arena.local', origin: 'https://arena.local', 'x-forwarded-proto': 'https' } });
    expect(proxied.statusCode).toBe(201);
    sessions.push(proxied.json().id);
    const voterHostAttempt = await app.inject({ ...request, headers: voterHeaders(0) });
    expect(voterHostAttempt.statusCode).toBe(403);
  });

  it('serializes concurrent authenticated votes into one row and gap-free event versions', async () => {
    const id = await createArena();
    const responses = await Promise.all(Array.from({ length: 12 }, (_, index) => app.inject({
      method: 'POST', url: `/api/arena/sessions/${id}/votes`,
      headers: voterHeaders(0), payload: { choice: index % 2 ? 'quick' : 'standard' },
    })));
    expect(responses.map((response) => response.statusCode)).toEqual(Array(12).fill(200));
    const state = await prisma.arenaSession.findUniqueOrThrow({ where: { id }, include: { votes: true, events: { orderBy: { version: 'asc' } } } });
    expect(state.votes).toHaveLength(1);
    expect(state.version).toBe(13);
    expect(state.events.map((event) => event.version)).toEqual(Array.from({ length: 13 }, (_, index) => index + 1));
  });

  it('protects all six Arena tables immediately after Prisma migration, including against a granted non-owner reader', async () => {
    const tables = await prisma.$queryRaw<Array<{ relrowsecurity: boolean }>>`SELECT relrowsecurity FROM pg_class WHERE relnamespace='public'::regnamespace AND relname IN ('arena_sessions','arena_rounds','arena_votes','arena_events','arena_solve_ingresses','arena_puzzle_supply')`;
    expect(tables).toHaveLength(6);
    expect(tables.every((table) => table.relrowsecurity)).toBe(true);
    await prisma.$executeRawUnsafe('CREATE ROLE arena_review_client NOLOGIN');
    try {
      await prisma.$executeRawUnsafe('GRANT USAGE ON SCHEMA public TO arena_review_client');
      await prisma.$executeRawUnsafe('GRANT SELECT ON arena_sessions, arena_rounds, arena_votes, arena_events, arena_solve_ingresses, arena_puzzle_supply TO arena_review_client');
      const counts = await prisma.$transaction(async (tx) => {
        await tx.$executeRawUnsafe('SET LOCAL ROLE arena_review_client');
        return tx.$queryRaw<Array<{ count: bigint }>>`SELECT count(*) FROM arena_rounds`;
      });
      expect(counts[0].count).toBe(0n);
      expect(await prisma.arenaRound.count()).toBeGreaterThan(0);
    } finally {
      await prisma.$executeRawUnsafe('DROP OWNED BY arena_review_client');
      await prisma.$executeRawUnsafe('DROP ROLE arena_review_client');
    }
  });

  it('ignores expired orphan ingress leases so timeout resolution cannot be stranded by a crashed process', async () => {
    const id = await createArena();
    const now = Date.now();
    await prisma.arenaSession.update({ where: { id }, data: { status: 'PLAYING' } });
    await prisma.arenaRound.updateMany({ where: { sessionId: id }, data: { phase: 'PLAYING', deadlineAt: new Date(now - 60_000) } });
    const ticket = await prisma.arenaSolveIngress.create({ data: { sessionId: id, ingressAt: new Date(now - 61_000), leaseExpiresAt: new Date(now + 60_000) } });
    const waiting = await app.inject({ method: 'GET', url: `/api/arena/sessions/${id}` });
    expect(waiting.json().status).toBe('PLAYING');
    await prisma.arenaSolveIngress.update({ where: { id: ticket.id }, data: { leaseExpiresAt: new Date(now - 1_000) } });
    const finished = await app.inject({ method: 'GET', url: `/api/arena/sessions/${id}` });
    expect(finished.json().status).toBe('RESULT');
    expect(finished.json().round.result).toBe('AUDIENCE');
  });

  it('keeps Arena supply opaque to the registered public puzzle route', async () => {
    const id = await createArena();
    await app.inject({ method: 'POST', url: `/api/arena/sessions/${id}/votes`, headers: voterHeaders(1), payload: { choice: 'standard' } });
    await prisma.arenaSession.update({ where: { id }, data: { ballotClosesAt: new Date(Date.now() - 1_000) } });
    const ready = await app.inject({ method: 'GET', url: `/api/arena/sessions/${id}` });
    const started = await app.inject({ method: 'POST', url: `/api/arena/sessions/${id}/start`, headers: { ...headers(), 'idempotency-key': 'review-private-supply-start' }, payload: { expectedVersion: ready.json().version } });
    expect(started.statusCode).toBe(200);
    expect(started.json().round).not.toHaveProperty('puzzleId');
    const lookup = await app.inject({ method: 'GET', url: `/puzzles/${fixture}` });
    expect(lookup.statusCode).toBe(404);
    expect(lookup.body).not.toContain(solution);
  });

  it('fails closed when the only Arena-eligible candidate collides with a scheduled official puzzle', async () => {
    // The shared fixture is also Extreme for the other end-to-end cases; make
    // this test genuinely exercise the no-safe-candidate branch.
    await prisma.arenaPuzzleSupply.update({ where: { id: fixture }, data: { eligible: false } });
    await prisma.puzzleDaily.create({ data: { puzzleId: protectedDaily, tier: 'Hard', tierIndex: 1, date: new Date(Date.now() + 86_400_000), givens: protectedGivens, solution: protectedSolution, checksum: 'arena-review-protected' } });
    await prisma.officialEvent.create({ data: {
      eventType: 'daily', puzzleId: protectedDaily, puzzleChecksum: 'arena-review-protected', rankingPuzzleIds: [protectedDaily],
      windowOpensAt: new Date(Date.now() + 86_400_000), windowClosesAt: new Date(Date.now() + 172_800_000), resultsAt: new Date(Date.now() + 259_200_000), status: 'scheduled',
    } });
    await prisma.arenaPuzzleSupply.create({ data: { id: protectedSupply, tier: 'Extreme', givens: protectedGivens, solution: protectedSolution, eligible: true, provenance: 'TEST_FIXTURE' } });
    const id = await createArena('endurance');
    await prisma.arenaSession.update({ where: { id }, data: { ballotClosesAt: new Date(Date.now() - 1_000) } });
    const ready = await app.inject({ method: 'GET', url: `/api/arena/sessions/${id}` });
    const start = await app.inject({ method: 'POST', url: `/api/arena/sessions/${id}/start`, headers: { ...headers(), 'idempotency-key': 'review-protected-supply-start' }, payload: { expectedVersion: ready.json().version } });
    expect(start.statusCode).toBe(409);
    const official = await app.inject({ method: 'GET', url: `/puzzles/${protectedDaily}` });
    expect(official.statusCode).toBe(200);
    expect(official.json()).not.toHaveProperty('solution');
    await prisma.officialEvent.deleteMany({ where: { puzzleId: protectedDaily } });
    await prisma.puzzleDaily.deleteMany({ where: { puzzleId: protectedDaily } });
    await prisma.arenaPuzzleSupply.deleteMany({ where: { id: protectedSupply } });
    await prisma.arenaPuzzleSupply.update({ where: { id: fixture }, data: { eligible: true } });
  });

  it('plays a real cookie-authenticated host, anonymous viewer, and authenticated voter journey without private payloads', async () => {
    const address = await app.listen({ host: '127.0.0.1', port: 0 });
    const browser = await puppeteer.launch({ headless: true });
    try {
      const host = await browser.newPage();
      const guestContext = await browser.createBrowserContext();
      const guest = await guestContext.newPage();
      const voterContext = await browser.createBrowserContext();
      const voter = await voterContext.newPage();
      await host.setCookie({ name: 'orbace_session', value: hostCookie, url: address, httpOnly: true, sameSite: 'Lax' });
      await voter.setCookie({ name: 'orbace_session', value: voterCookies[0], url: address, httpOnly: true, sameSite: 'Lax' });
      await Promise.all([host.goto(`${address}/__review`), guest.goto(`${address}/__review`), voter.goto(`${address}/__review`)]);
      const created = await host.evaluate(async () => {
        const response = await fetch('/api/arena/sessions', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
        return { code: response.status, data: await response.json() };
      });
      expect(created.code).toBe(201);
      const id = created.data.id as string;
      sessions.push(id);
      const anonymous = await guest.evaluate(async (id) => {
        const denied = await fetch(`/api/arena/sessions/${id}/host`);
        const vote = await fetch(`/api/arena/sessions/${id}/votes`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ choice: 'standard' }) });
        return { denied: denied.status, vote: vote.status };
      }, id);
      expect(anonymous).toEqual({ denied: 401, vote: 200 });
      const voterVote = await voter.evaluate(async (id) => (await fetch(`/api/arena/sessions/${id}/votes`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ choice: 'standard' }) })).status, id);
      expect(voterVote).toBe(200);
      await prisma.arenaSession.update({ where: { id }, data: { ballotClosesAt: new Date(Date.now() - 1_000) } });
      const journey = await host.evaluate(async ({ id, solution }) => {
        const ready = await (await fetch(`/api/arena/sessions/${id}`)).json();
        const start = await fetch(`/api/arena/sessions/${id}/start`, { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'review-browser-start-1' }, body: JSON.stringify({ expectedVersion: ready.version }) });
        const started = await start.json();
        const hostBody = await (await fetch(`/api/arena/sessions/${id}/host`)).text();
        const solve = await fetch(`/api/arena/sessions/${id}/solve`, { method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'review-browser-solve-1' }, body: JSON.stringify({ expectedVersion: started.version, board: solution }) });
        const solved = await solve.json();
        return { ready: ready.status, start: start.status, preset: started.round?.preset, hostBody, solve: solve.status, result: solved.round?.result, solveBody: JSON.stringify(solved), cookieReadable: document.cookie.includes('orbace_session=') };
      }, { id, solution });
      expect(journey).toMatchObject({ ready: 'READY', start: 200, preset: 'standard', solve: 200, result: 'HOST', cookieReadable: false });
      expect(journey.solveBody).not.toContain(solution);
      const publicBody = await guest.evaluate(async (id) => (await fetch(`/api/arena/sessions/${id}`)).text(), id);
      for (const body of [journey.hostBody, publicBody]) for (const secret of [solution, hostSubject, hostCookie, voterCookies[0]]) expect(body).not.toContain(secret);
    } finally { await browser.close(); process.env.ARENA_ENABLED = 'true'; }
  }, 20_000);

  it('limits host capability probes to confirmed hosts (POC-IR-01)', async () => {
    const bound = app.server.address() as AddressInfo | null;
    const address = app.server.listening && bound
      ? `http://127.0.0.1:${bound.port}`
      : await app.listen({ host: '127.0.0.1', port: 0 });
    const id = await createArena();
    const browser = await puppeteer.launch({ headless: true });
    try {
      const host = await browser.newPage();
      const guestContext = await browser.createBrowserContext();
      const guest = await guestContext.newPage();
      const overlayContext = await browser.createBrowserContext();
      const overlay = await overlayContext.newPage();
      const probes = { host: 0, guest: 0, overlay: 0 };
      const track = (name: keyof typeof probes, page: typeof host) => {
        page.on('request', (request) => {
          if (request.url().includes(`/api/arena/sessions/${id}/host`)) probes[name] += 1;
        });
      };
      track('host', host);
      track('guest', guest);
      track('overlay', overlay);
      await host.setCookie({ name: 'orbace_session', value: hostCookie, url: address, httpOnly: true, sameSite: 'Lax' });
      await guest.setCookie({ name: 'orbace_session', value: voterCookies[0], url: address, httpOnly: true, sameSite: 'Lax' });
      await host.goto(`${address}/arena?session=${id}`, { waitUntil: 'domcontentloaded' });
      await guest.goto(`${address}/arena?session=${id}`, { waitUntil: 'domcontentloaded' });
      await overlay.goto(`${address}/arena?session=${id}&overlay=1`, { waitUntil: 'domcontentloaded' });
      await host.waitForSelector('#host-panel:not([hidden])');
      await guest.waitForSelector('#ballot-panel:not([hidden])');
      await overlay.waitForFunction(() => document.getElementById('session-state')?.textContent === 'BALLOT_OPEN');
      await new Promise((resolve) => setTimeout(resolve, 4_000));
      expect(probes.host).toBeGreaterThanOrEqual(2);
      expect(probes.guest).toBe(1);
      expect(probes.overlay).toBe(0);
      expect(await guest.$eval('#host-panel', (element) => (element as HTMLElement).hidden)).toBe(true);
    } finally {
      await browser.close();
    }
  }, 20_000);

  it('reports approximate viewer presence and unique voters only to the host', async () => {
    const id = await createArena();
    const viewer1 = await app.inject({ method: 'GET', url: `/api/arena/sessions/${id}`, headers: { 'x-arena-client': 'viewer-client-1' } });
    const viewer2 = await app.inject({ method: 'GET', url: `/api/arena/sessions/${id}/overlay`, headers: { 'x-arena-client': 'viewer-client-2' } });
    expect(viewer1.statusCode).toBe(200);
    expect(viewer2.statusCode).toBe(200);
    expect(viewer1.json()).not.toHaveProperty('audience');
    const hostPoll = () => app.inject({ method: 'GET', url: `/api/arena/sessions/${id}/host`, headers: { ...headers(), 'x-arena-client': 'host-client' } });
    const first = await hostPoll();
    expect(first.statusCode).toBe(200);
    expect(first.json().audience).toEqual({ watching: 2, voters: 0 });
    await app.inject({ method: 'POST', url: `/api/arena/sessions/${id}/votes`, headers: voterHeaders(0), payload: { choice: 'quick' } });
    const second = await hostPoll();
    expect(second.json().audience).toEqual({ watching: 2, voters: 1 });
    await app.inject({ method: 'POST', url: `/api/arena/sessions/${id}/votes`, headers: voterHeaders(0), payload: { choice: 'standard' } });
    await app.inject({ method: 'GET', url: `/api/arena/sessions/${id}`, headers: { 'x-arena-client': 'viewer-client-1' } });
    const third = await hostPoll();
    expect(third.json().audience).toEqual({ watching: 2, voters: 1 });
    const hostBody = JSON.stringify(third.json());
    for (const identity of ['viewer-client-1', 'viewer-client-2', 'host-client', voterSubjects[0]]) expect(hostBody).not.toContain(identity);
    for (let index = 0; index < 260; index += 1) {
      await app.inject({ method: 'GET', url: `/api/arena/sessions/${id}`, headers: { 'x-arena-client': `viewer-cap-${index}` } });
    }
    const capped = await hostPoll();
    expect(capped.json().audience.watching).toBeLessThanOrEqual(256);
    expect(capped.json().audience.watching).toBe(256);
  });

  it('runs the mounted Orbace Arena page in separate host and audience browser contexts through rematch', async () => {
    const bound = app.server.address() as AddressInfo | null;
    const address = app.server.listening && bound
      ? `http://127.0.0.1:${bound.port}`
      : await app.listen({ host: '127.0.0.1', port: 0 });
    const browser = await puppeteer.launch({ headless: true });
    try {
      const host = await browser.newPage();
      const guestContext = await browser.createBrowserContext();
      const guest = await guestContext.newPage();
      const secondGuestContext = await browser.createBrowserContext();
      const secondGuest = await secondGuestContext.newPage();
      const thirdGuestContext = await browser.createBrowserContext();
      const thirdGuest = await thirdGuestContext.newPage();
      const overlayContext = await browser.createBrowserContext();
      const overlay = await overlayContext.newPage();
      for (const page of [host, guest, secondGuest, thirdGuest, overlay]) {
        await page.setRequestInterception(true);
        page.on('request', (request) => request.url().startsWith(address) ? request.continue() : request.abort());
      }
      const browserDiagnostics: string[] = [];
      host.on('pageerror', (error) => browserDiagnostics.push(error instanceof Error ? error.message : String(error)));
      host.on('console', (message) => { if (message.type() === 'error') browserDiagnostics.push(message.text()); });
      host.on('response', (response) => { if (response.url().startsWith(address) && response.status() >= 400) browserDiagnostics.push(`${response.status()} ${response.url()}`); });
      await host.setCookie({ name: 'orbace_session', value: hostCookie, url: address, httpOnly: true, sameSite: 'Lax' });
      await guest.setCookie({ name: 'orbace_session', value: voterCookies[0], url: address, httpOnly: true, sameSite: 'Lax' });
      await secondGuest.setCookie({ name: 'orbace_session', value: voterCookies[1], url: address, httpOnly: true, sameSite: 'Lax' });
      await thirdGuest.setCookie({ name: 'orbace_session', value: voterCookies[2], url: address, httpOnly: true, sameSite: 'Lax' });
      process.env.ARENA_ENABLED = 'false';
      await host.goto(`${address}/arena`, { waitUntil: 'domcontentloaded' });
      expect(await host.$eval('script[src*="supabase-js"]', (element) => (element as HTMLScriptElement).async)).toBe(true);
      await host.waitForFunction(() => document.getElementById('arena-status')?.textContent === 'Arena is currently disabled.', { timeout: 5_000 }).catch(async () => {
        const state = await host.evaluate(() => {
          const page = window as Window & { ORBACE_CONFIG?: { ORG_API_URL?: string }; OrbaceAPI?: Record<string, unknown> };
          return { status: document.getElementById('arena-status')?.textContent, error: document.getElementById('arena-error')?.textContent, config: page.ORBACE_CONFIG?.ORG_API_URL, api: Object.keys(page.OrbaceAPI || {}) };
        });
        throw new Error(`Arena startup diagnostics ${JSON.stringify({ state, browserDiagnostics })}`);
      });
      expect(await host.$eval('#create-session', (element) => (element as HTMLButtonElement).disabled)).toBe(true);
      process.env.ARENA_ENABLED = 'true';
      await host.goto(`${address}/arena`, { waitUntil: 'domcontentloaded' });
      await host.waitForFunction(() => (document.getElementById('create-session') as HTMLButtonElement | null)?.disabled === false);
      await host.select('#default-preset', 'standard');
      await host.click('#create-session');
      await host.waitForFunction(() => new URL(location.href).searchParams.has('session'));
      const firstUrl = host.url();
      const firstId = new URL(firstUrl).searchParams.get('session')!;
      sessions.push(firstId);

      await guest.goto(firstUrl, { waitUntil: 'domcontentloaded' });
      await secondGuest.goto(firstUrl, { waitUntil: 'domcontentloaded' });
      await thirdGuest.goto(firstUrl, { waitUntil: 'domcontentloaded' });
      await guest.waitForSelector('#ballot-panel:not([hidden])');
      for (const voterPage of [guest, secondGuest, thirdGuest]) {
        const status = await voterPage.evaluate(async (id) => (await fetch(`/api/arena/sessions/${id}/votes`, {
          method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ choice: 'standard' }),
        })).status, firstId);
        expect(status).toBe(200);
      }
      await prisma.arenaSession.update({ where: { id: firstId }, data: { ballotClosesAt: new Date(Date.now() - 100) } });
      await host.waitForFunction(() => (document.getElementById('start-round') as HTMLButtonElement | null)?.disabled === false, { timeout: 10_000 }).catch(async () => {
        const state = await host.evaluate(() => ({
          button: (document.getElementById('start-round') as HTMLButtonElement | null)?.disabled,
          renderedState: document.getElementById('session-state')?.textContent,
          error: document.getElementById('arena-error')?.textContent,
        }));
        const snapshot = await app.inject({ method: 'GET', url: `/api/arena/sessions/${firstId}` });
        throw new Error(`Preset ballot did not reach READY: ${JSON.stringify({ state, snapshot: snapshot.json() })}`);
      });
      await host.click('#start-round');
      await host.waitForSelector('#sudoku-board .arena-cell');
      await guest.waitForSelector('#sudoku-board .arena-cell');
      const overlayUrl = new URL(firstUrl); overlayUrl.searchParams.set('overlay', '1');
      await overlay.goto(overlayUrl.href, { waitUntil: 'domcontentloaded' });
      await overlay.waitForSelector('#sudoku-board .arena-cell');
      const started = await prisma.arenaSession.findUniqueOrThrow({ where: { id: firstId }, include: { rounds: true } });
      expect(started.status).toBe('PLAYING');
      expect(started.rounds[0].givens).toBe(givens);
      const publicPayload = await guest.evaluate(async (id) => (await fetch(`/api/arena/sessions/${id}`)).json(), firstId);
      expect(publicPayload.round).not.toHaveProperty('solution');
      expect(publicPayload.round).not.toHaveProperty('puzzleId');
      expect(publicPayload).not.toHaveProperty('hostControls');
      expect(await guest.$$eval('#sudoku-board .arena-cell', (cells) => cells.every((cell) => (cell as HTMLInputElement).disabled))).toBe(true);
      expect(await host.$eval('#round-timer', (element) => element.textContent)).toMatch(/^\d{2}:\d{2}$/);
      expect(await guest.$$eval('#sudoku-board .arena-cell', (cells) => cells.some((cell) => (cell as HTMLInputElement).value === '0'))).toBe(false);
      expect(await overlay.$$eval('#sudoku-board .arena-cell', (cells) => cells.some((cell) => (cell as HTMLInputElement).value === '0'))).toBe(false);

      const firstEmpty = givens.indexOf('0');
      const partialDigit = solution[firstEmpty];
      await host.evaluate(({ index, digit }) => {
        const cell = document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell')[index];
        cell.value = digit; cell.dispatchEvent(new Event('input', { bubbles: true }));
      }, { index: firstEmpty, digit: partialDigit });
      for (let attempt = 0; attempt < 80; attempt += 1) {
        const saved = await prisma.arenaRound.findFirst({ where: { sessionId: firstId }, select: { boardRevision: true } });
        if (saved?.boardRevision) break;
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
      const persistedBoard = await prisma.arenaRound.findFirst({ where: { sessionId: firstId }, select: { boardRevision: true, boardState: true } });
      expect(persistedBoard?.boardRevision).toBe(1);
      expect(persistedBoard?.boardState?.[firstEmpty]).toBe(partialDigit);
      await guest.bringToFront();
      await guest.waitForFunction(({ index, digit }) => document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell')[index]?.value === digit, { polling: 100, timeout: 5_000 }, { index: firstEmpty, digit: partialDigit });
      expect(await guest.$$eval('#sudoku-board .arena-cell', (cells) => cells.some((cell) => (cell as HTMLInputElement).value === '0'))).toBe(false);
      await overlay.bringToFront();
      await overlay.waitForFunction(({ index, digit }) => document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell')[index]?.value === digit, { polling: 100, timeout: 5_000 }, { index: firstEmpty, digit: partialDigit });
      expect(await overlay.$$eval('#sudoku-board .arena-cell', (cells) => cells.some((cell) => (cell as HTMLInputElement).value === '0'))).toBe(false);

      const noteIndex = givens.indexOf('0', firstEmpty + 1);
      await host.bringToFront();
      await host.click('#toggle-notes');
      expect(await host.$eval('#toggle-notes', (element) => element.getAttribute('aria-pressed'))).toBe('true');
      const addNote = async (digit: string) => host.evaluate(({ index, digit }) => {
        const cell = document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell')[index];
        cell.focus(); cell.value = digit; cell.dispatchEvent(new Event('input', { bubbles: true }));
      }, { index: noteIndex, digit });
      const activeNotes = () => host.evaluate((index) => [...document.querySelectorAll('.arena-notes-cell')[index].querySelectorAll('.arena-note-digit[data-active="true"]')].map((element) => element.textContent), noteIndex);
      await addNote('1');
      await addNote('2');
      expect(await activeNotes()).toEqual(['1', '2']);
      await host.evaluate(({ index, digit }) => {
        const span = [...document.querySelectorAll('.arena-notes-cell')[index].querySelectorAll('.arena-note-digit')].find((element) => (element as HTMLElement).dataset.digit === String(digit));
        (span as HTMLElement).click();
      }, { index: noteIndex, digit: '2' });
      expect(await activeNotes()).toEqual(['1']);
      await host.click('#toggle-notes');
      await host.evaluate(({ index, digit }) => {
        const cell = document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell')[index];
        cell.focus(); cell.value = digit; cell.dispatchEvent(new Event('input', { bubbles: true }));
      }, { index: noteIndex, digit: solution[noteIndex] });
      expect(await activeNotes()).toEqual([]);
      await host.reload({ waitUntil: 'domcontentloaded' });
      await host.waitForFunction((index, digit) => document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell')[index]?.value === digit, {}, firstEmpty, partialDigit);

      const strikeOpenedAt = new Date();
      await prisma.arenaRound.update({ where: { id: started.rounds[0].id }, data: {
        startedAt: new Date(strikeOpenedAt.getTime() - 95_000), deadlineAt: new Date(strikeOpenedAt.getTime() + 205_000),
        strikeStatus: 'OPEN', strikeOpenedAt, strikeClosesAt: new Date(strikeOpenedAt.getTime() + 10_000),
      } });
      await host.waitForSelector('#pause-round:not([hidden])');
      await host.waitForSelector('#strike-panel:not([hidden])');
      await host.evaluate(() => { window.confirm = () => true; });
      const deadlineBeforePause = (await prisma.arenaRound.findUniqueOrThrow({ where: { id: started.rounds[0].id } })).deadlineAt!.getTime();
      const strikeCloseBeforePause = (await prisma.arenaRound.findUniqueOrThrow({ where: { id: started.rounds[0].id } })).strikeClosesAt!.getTime();
      expect(await host.$$eval('#sudoku-board .arena-cell[data-given="false"]:not(:disabled)', (cells) => cells.length)).toBeGreaterThan(0);
      await host.click('#pause-round');
      await host.waitForFunction(() => (document.getElementById('pause-state') as HTMLElement | null)?.hidden === false);
      expect(await host.$$eval('#sudoku-board .arena-cell[data-given="false"]:disabled', (cells) => cells.length)).toBeGreaterThan(0);
      await new Promise((resolve) => setTimeout(resolve, 500));
      const pausedSnapshot = await app.inject({ method: 'GET', url: `/api/arena/sessions/${firstId}` });
      expect(pausedSnapshot.json().paused).toBe(true);
      expect(pausedSnapshot.json().round.strike.status).toBe('OPEN');
      await host.click('#resume-round');
      await host.waitForFunction(() => (document.getElementById('pause-state') as HTMLElement | null)?.hidden === true);
      await host.waitForFunction(() => document.querySelectorAll('#sudoku-board .arena-cell[data-given="false"]:not(:disabled)').length > 0);
      const resumedRound = await prisma.arenaRound.findUniqueOrThrow({ where: { id: started.rounds[0].id } });
      expect(resumedRound.deadlineAt!.getTime()).toBeGreaterThan(deadlineBeforePause);
      expect(resumedRound.strikeClosesAt!.getTime()).toBeGreaterThan(strikeCloseBeforePause);
      for (const [voterPage, choice] of [[guest, 'PENALTY'], [secondGuest, 'PENALTY'], [thirdGuest, 'SPARE']] as const) {
        const status = await voterPage.evaluate(async ({ id, choice }) => (await fetch(`/api/arena/sessions/${id}/votes`, {
          method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ kind: 'STRIKE', choice }),
        })).status, { id: firstId, choice });
        expect(status).toBe(200);
      }
      await guest.waitForFunction(() => document.getElementById('strike-count')?.textContent?.includes('Penalty 2'));
      await prisma.arenaRound.update({ where: { id: started.rounds[0].id }, data: { strikeClosesAt: new Date(Date.now() - 1) } });
      const resolvedStrike = await app.inject({ method: 'GET', url: `/api/arena/sessions/${firstId}` });
      expect(resolvedStrike.json().round.strike.choice).toBe('TIME_PENALTY');
      expect(resolvedStrike.json().round.modifierAppliedSeconds).toBe(10);
      await host.waitForFunction(() => document.getElementById('strike-count')?.textContent?.includes('Time penalty variant applied'));
      await overlay.waitForFunction(() => document.getElementById('strike-count')?.textContent?.includes('Time penalty variant applied'));

      await host.evaluate((answer) => {
        const cells = Array.from(document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell'));
        cells.forEach((cell, index) => {
          if (!cell.disabled) {
            cell.value = answer[index];
            cell.dispatchEvent(new Event('input', { bubbles: true }));
          }
        });
      }, solution);
      await host.waitForFunction(() => (document.getElementById('submit-solve') as HTMLButtonElement | null)?.disabled === false, { timeout: 10_000 }).catch(async () => {
        const state = await host.evaluate(() => ({
          solveDisabled: (document.getElementById('submit-solve') as HTMLButtonElement | null)?.disabled,
          sessionState: document.getElementById('session-state')?.textContent,
          error: document.getElementById('arena-error')?.textContent,
          pauseStateHidden: (document.getElementById('pause-state') as HTMLElement | null)?.hidden,
          blanks: Array.from(document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell')).filter((cell) => !cell.disabled && !cell.value).length,
          enabledCells: Array.from(document.querySelectorAll<HTMLInputElement>('#sudoku-board .arena-cell')).filter((cell) => !cell.disabled).length,
          publicSnapshot: null as unknown,
          hostSnapshot: null as unknown,
        }));
        state.publicSnapshot = await host.evaluate(async (id) => (await (await fetch(`/api/arena/sessions/${id}`)).json()), firstId);
        const hostStatus = await host.evaluate(async (id) => {
          const response = await fetch(`/api/arena/sessions/${id}/host`);
          return { status: response.status, body: await response.json() };
        }, firstId);
        state.hostSnapshot = hostStatus;
        throw new Error(`Host solve did not become enabled: ${JSON.stringify(state)}`);
      });
      await host.click('#submit-solve');
      await host.waitForFunction(() => document.getElementById('session-state')?.textContent === 'RESULT', { timeout: 10_000 });
      await guest.waitForFunction(() => document.getElementById('session-state')?.textContent === 'RESULT', { timeout: 10_000 });
      await overlay.waitForFunction(() => document.getElementById('session-state')?.textContent === 'RESULT', { timeout: 10_000 });
      expect(await host.$eval('#round-result', (element) => element.textContent)).toContain('Host wins');
      expect(await guest.$eval('#round-result', (element) => element.textContent)).toContain('Host wins');
      expect(await overlay.$eval('#round-result', (element) => element.textContent)).toContain('Host wins');
      const hostJson = await host.evaluate(async (id) => JSON.stringify(await (await fetch(`/api/arena/sessions/${id}/host`)).json()), firstId);
      const guestJson = JSON.stringify(publicPayload);
      expect(hostJson).not.toContain(solution);
      expect(guestJson).not.toContain(solution);
      const overlayJson = await overlay.evaluate(async (id) => JSON.stringify(await (await fetch(`/api/arena/sessions/${id}/overlay`)).json()), firstId);
      expect(overlayJson).not.toContain(solution);

      await host.click('#rematch');
      await host.waitForFunction(() => new URL(location.href).searchParams.get('session') !== null && document.getElementById('session-state')?.textContent === 'BALLOT_OPEN');
      const secondId = new URL(host.url()).searchParams.get('session')!;
      sessions.push(secondId);
      expect(secondId).not.toBe(firstId);
      expect(await prisma.arenaVote.count({ where: { sessionId: secondId } })).toBe(0);
      const nextSession = await prisma.arenaSession.findUniqueOrThrow({ where: { id: secondId }, include: { rounds: true, votes: true } });
      expect(nextSession.status).toBe('BALLOT_OPEN');
      expect(nextSession.ballotClosesAt.getTime()).toBeGreaterThan(Date.now());
      expect(nextSession.votes).toHaveLength(0);
      expect(nextSession.rounds).toMatchObject([{ number: 1, phase: 'BALLOT', preset: null, givens: null, solution: null, modifier: null, result: null }]);
      await guest.goto(host.url(), { waitUntil: 'domcontentloaded' });
      await guest.waitForSelector('#ballot-panel:not([hidden])');
      expect(await guest.$eval('#ballot-count', (element) => element.textContent)).toContain('0 audience vote');
      const secondSupplyId = '44444444-4444-4444-8444-444444444444';
      // Digit permutation preserves Sudoku validity while ensuring this
      // rematch fixture cannot collide with the protected-puzzle test above.
      const rematchGivens = '970010000200549000043000020300020007800307005100060002020000630000854009000030014';
      const rematchSolution = '978213456216549783543786921394125867862397145157468392425971638631854279789632514';
      await prisma.arenaPuzzleSupply.create({ data: { id: secondSupplyId, tier: 'Extreme', givens: rematchGivens, solution: rematchSolution, eligible: true, provenance: 'TEST_FIXTURE' } });
      await prisma.arenaSession.update({ where: { id: secondId }, data: { ballotClosesAt: new Date(Date.now() - 100) } });
      await host.waitForFunction(() => (document.getElementById('start-round') as HTMLButtonElement | null)?.disabled === false);
      await host.click('#start-round');
      await host.waitForFunction(() => document.getElementById('session-state')?.textContent === 'PLAYING');
      const rematchRound = await prisma.arenaRound.findFirstOrThrow({ where: { sessionId: secondId } });
      expect(rematchRound.puzzleId).toBe(secondSupplyId);
      expect(rematchRound.puzzleId).not.toBe(started.rounds[0].puzzleId);
      await prisma.arenaPuzzleSupply.delete({ where: { id: secondSupplyId } });
    } finally { await browser.close(); process.env.ARENA_ENABLED = 'true'; }
  }, 90_000);

  it('enforces the actual registered solve rate limit with Retry-After', async () => {
    const id = await createArena();
    const responses = [];
    for (let index = 0; index < 9; index += 1) {
      responses.push(await app.inject({ method: 'POST', url: `/api/arena/sessions/${id}/solve`, headers: headers(), payload: {} }));
    }
    expect(responses.at(-1)!.statusCode).toBe(429);
    expect(Number(responses.at(-1)!.headers['retry-after'])).toBeGreaterThan(0);
    expect(await prisma.arenaSolveIngress.count({ where: { sessionId: id } })).toBe(0);
  });
});
