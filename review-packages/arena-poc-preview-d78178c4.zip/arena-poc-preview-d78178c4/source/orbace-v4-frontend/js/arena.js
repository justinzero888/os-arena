(function () {
  'use strict';

  const params = new URLSearchParams(location.search);
  const sessionIdParam = params.get('session');
  const overlayMode = params.get('overlay') === '1';
  const $ = (id) => document.getElementById(id);
  const TIME_MODE_LABELS = { quick: 'Quick · 3 min', standard: 'Standard · 5 min', endurance: 'Endurance · 8 min' };
  const POLL_MS = 2000;
  const ui = {
    status: $('arena-status'), startPanel: $('arena-start'), sessionPanel: $('arena-session'),
    preset: $('default-preset'), create: $('create-session'), sessionInput: $('session-id'), join: $('join-session'),
    sessionTitle: $('session-title'), sessionLink: $('session-link'), state: $('session-state'),
    ballot: $('ballot-panel'), ballotCount: $('ballot-count'), voteMessage: $('vote-message'),
    strike: $('strike-panel'), strikeMessage: $('strike-message'), strikeCount: $('strike-count'),
    host: $('host-panel'), hostMessage: $('host-message'), start: $('start-round'),
    pause: $('pause-round'), resume: $('resume-round'), cancel: $('cancel-session'), pauseState: $('pause-state'),
    game: $('game-panel'), roundTitle: $('round-title'), timer: $('round-timer'), instructions: $('game-instructions'),
    board: $('sudoku-board'), solve: $('submit-solve'), result: $('result-panel'), resultText: $('round-result'), rematch: $('rematch'),
    presence: $('audience-presence'), notes: $('toggle-notes'),
    error: $('arena-error'),
  };
  const clientId = () => {
    try { return window.crypto.randomUUID(); } catch (_) { return Date.now() + '-' + Math.random().toString(36).slice(2); }
  };
  let sessionId = sessionIdParam;
  let accepted = null;
  let hostCanControl = false;
  // POC-IR-01: non-host viewers must not probe the host-only endpoint on every
  // poll. Probe once per session, then use the host projection only for a
  // confirmed host and the public projection for everyone else.
  let hostProbe = 'unknown';
  let board = '';
  let timerId = null;
  let pollId = null;
  let lastVote = null;
  let lastStrikeVote = null;
  let busy = false;
  let boardPending = false;
  let boardSyncTimer = null;
  let acceptedSessionId = null;
  const presenceClient = clientId();
  let notesMode = false;
  let notes = Array.from({ length: 81 }, () => new Set());
  let givensState = '';
  let acceptedRoundKey = '';
  let lastServerNotes = '';
  function hasStoredSupabaseSession() {
    try {
      for (let index = 0; index < localStorage.length; index += 1) {
        const key = localStorage.key(index);
        if (key && (key.startsWith('sb-') || key.startsWith('supabase.'))) return true;
      }
    } catch (_) {}
    return false;
  }

  function waitForSupabaseSdk() {
    if (window.supabase || !hasStoredSupabaseSession()) return Promise.resolve();
    const script = document.querySelector('script[src*="supabase-js"]');
    if (!script) return Promise.resolve();
    return new Promise((resolve) => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        resolve();
      };
      script.addEventListener('load', finish, { once: true });
      script.addEventListener('error', finish, { once: true });
      setTimeout(finish, 8000);
    });
  }

  const authReady = waitForSupabaseSdk().then(() => {
    return window.OrbaceAuthSession && window.OrbaceAuthSession.restore
      ? window.OrbaceAuthSession.restore()
      : null;
  }).catch(() => null);

  async function callApi(method, ...args) {
    const api = window.OrbaceAPI;
    if (!api || typeof api[method] !== 'function') throw new Error('Arena API adapter is unavailable.');
    if (['createArenaSession', 'getArenaHostSession', 'startArenaRound', 'submitArenaSolve', 'updateArenaBoard', 'pauseArenaSession', 'resumeArenaSession', 'cancelArenaSession', 'rematchArenaSession', 'castArenaPresetVote', 'castArenaStrikeVote'].includes(method)) await authReady;
    return api[method](...args);
  }


  function showError(error) {
    ui.error.textContent = error && error.status === 401
      ? 'Sign in to host this Arena, or open the session link to watch.'
      : error && error.status === 403
        ? 'This Orbace account is not enabled to host Arena yet.'
        : (error && error.message || 'Arena is unavailable right now.');
    ui.error.hidden = false;
  }

  function resetError() { ui.error.hidden = true; ui.error.textContent = ''; }
  function idempotencyKey(action) { return 'arena-' + action + '-' + clientId(); }
  function setSessionUrl(id) {
    const url = new URL(location.href);
    url.searchParams.set('session', id);
    if (overlayMode) url.searchParams.set('overlay', '1');
    history.replaceState({}, '', url);
    sessionId = id;
    hostProbe = 'unknown';
    ui.sessionLink.innerHTML = '';
    const link = document.createElement('a');
    link.href = url.href;
    link.textContent = 'Share this Arena link';
    ui.sessionLink.append(link);
    const overlayUrl = new URL(url.href);
    overlayUrl.searchParams.set('overlay', '1');
    const overlay = document.createElement('a');
    overlay.href = overlayUrl.href;
    overlay.textContent = ' · Open read-only overlay';
    ui.sessionLink.append(overlay);
  }

  function stashArenaReturnTo() {
    try { sessionStorage.setItem('orbace_return_to', location.pathname + location.search); } catch (_) {}
  }


  function renderNotesMode() {
    if (!ui.notes) return;
    ui.notes.textContent = notesMode ? 'Notes: On' : 'Notes: Off';
    ui.notes.setAttribute('aria-pressed', notesMode ? 'true' : 'false');
    ui.board.classList.toggle('notes-mode', notesMode && hostCanControl);
  }

  function renderNotes() {
    const overlay = ui.board.querySelector('.arena-notes-overlay');
    if (!overlay) return;
    for (let index = 0; index < 81; index += 1) {
      const cell = overlay.children[index];
      if (!cell) continue;
      const empty = givensState[index] === '0' && board[index] === '0';
      for (let digit = 1; digit <= 9; digit += 1) {
        const span = cell.children[digit - 1];
        const active = empty && notes[index].has(String(digit));
        span.textContent = active ? String(digit) : '';
        span.dataset.active = active ? 'true' : 'false';
        span.style.pointerEvents = active && notesMode && hostCanControl ? 'auto' : 'none';
      }
    }
  }

  function toggleNote(index, digit) {
    if (!hostCanControl || !notesMode) return;
    if (givensState[index] !== '0' || board[index] !== '0') return;
    const key = String(digit);
    if (notes[index].has(key)) notes[index].delete(key);
    else notes[index].add(key);
    renderNotes();
    scheduleBoardSync();
  }

  function renderBoard(givens, currentBoard) {
    if (typeof givens !== 'string' || !/^[0-9]{81}$/.test(givens)) return;
    givensState = givens;
    board = typeof currentBoard === 'string' && /^[0-9]{81}$/.test(currentBoard) ? currentBoard : givens;
    ui.board.replaceChildren();
    for (let index = 0; index < 81; index += 1) {
      const input = document.createElement('input');
      input.className = 'arena-cell';
      input.type = 'text';
      input.inputMode = 'numeric';
      input.maxLength = 1;
      input.autocomplete = 'off';
      input.setAttribute('role', 'gridcell');
      input.setAttribute('aria-label', 'Row ' + (Math.floor(index / 9) + 1) + ', column ' + (index % 9 + 1));
      input.dataset.given = givens[index] !== '0' ? 'true' : 'false';
      input.disabled = givens[index] !== '0';
      input.value = input.disabled ? givens[index] : board[index] === '0' ? '' : board[index];
      input.addEventListener('input', () => {
        if (notesMode) {
          const digit = /^[1-9]$/.test(input.value) ? input.value : '';
          input.value = board[index] === '0' ? '' : board[index];
          if (digit && hostCanControl && givens[index] === '0' && board[index] === '0') toggleNote(index, Number(digit));
          return;
        }
        const digit = /^[1-9]$/.test(input.value) ? input.value : '0';
        input.value = digit === '0' ? '' : digit;
        board = board.slice(0, index) + digit + board.slice(index + 1);
        if (digit !== '0') notes[index].clear();
        renderNotes();
        ui.solve.disabled = !hostCanControl || Boolean(accepted?.paused) || board.includes('0') || boardPending;
        scheduleBoardSync();
      });
      ui.board.append(input);
    }
    const overlay = document.createElement('div');
    overlay.className = 'arena-notes-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    for (let index = 0; index < 81; index += 1) {
      const cell = document.createElement('div');
      cell.className = 'arena-notes-cell';
      for (let digit = 1; digit <= 9; digit += 1) {
        const span = document.createElement('span');
        span.className = 'arena-note-digit';
        span.dataset.digit = String(digit);
        span.dataset.index = String(index);
        cell.append(span);
      }
      overlay.append(cell);
    }
    overlay.addEventListener('click', (event) => {
      const span = event.target.closest('.arena-note-digit');
      if (!span) return;
      event.preventDefault();
      event.stopPropagation();
      toggleNote(Number(span.dataset.index), Number(span.dataset.digit));
    });
    ui.board.append(overlay);
    ui.solve.disabled = true;
    renderNotes();
  }

  function render(session, isHost) {
    if (acceptedSessionId !== session.id) {
      acceptedSessionId = session.id;
      accepted = null;
      board = '';
      boardPending = false;
      clearTimeout(boardSyncTimer);
      acceptedRoundKey = '';
    } else if (accepted && session.version < accepted.version) {
      return false;
    }
    const roundKey = session.id + ':' + (session.round?.startedAt || 'ballot');
    if (roundKey !== acceptedRoundKey) {
      acceptedRoundKey = roundKey;
      notes = Array.from({ length: 81 }, () => new Set());
      notesMode = false;
      lastServerNotes = '';
    }
    accepted = session;
    hostCanControl = isHost;
    if (!isHost && notesMode) notesMode = false;
    const canVote = !overlayMode;
    if (ui.presence) {
      if (isHost && session.audience) {
        ui.presence.hidden = false;
        ui.presence.textContent = session.audience.watching + ' watching · ' + session.audience.voters + ' voters';
      } else ui.presence.hidden = true;
    }
    if (ui.notes) {
      ui.notes.hidden = overlayMode || !isHost || session.status !== 'PLAYING';
      ui.notes.disabled = overlayMode || !isHost || session.status !== 'PLAYING';
    }
    renderNotesMode();
    document.body.classList.toggle('arena-overlay', overlayMode);
    ui.startPanel.hidden = overlayMode || Boolean(sessionId);
    ui.sessionPanel.hidden = false;
    ui.status.textContent = 'Session ' + session.id;
    ui.sessionTitle.textContent = 'Arena session';
    ui.state.textContent = session.status;
    ui.ballot.hidden = session.status !== 'BALLOT_OPEN';
    ui.host.hidden = overlayMode || !isHost || !['BALLOT_OPEN', 'READY', 'PLAYING'].includes(session.status) && !session.paused;
    ui.game.hidden = session.status !== 'PLAYING';
    ui.result.hidden = !['RESULT', 'CANCELLED'].includes(session.status);
    ui.start.disabled = !(isHost && ['BALLOT_OPEN', 'READY'].includes(session.status) && !session.paused);
    ui.hostMessage.textContent = session.status === 'READY' ? 'The ballot is closed. Start when you are ready.' : 'Votes update live. Start when the audience is ready.';
    ui.pause.hidden = overlayMode || !isHost || session.paused || !['BALLOT_OPEN', 'PLAYING'].includes(session.status);
    ui.resume.hidden = overlayMode || !isHost || !session.paused;
    ui.cancel.hidden = overlayMode || !isHost || ['RESULT', 'CANCELLED'].includes(session.status);
    ui.pauseState.hidden = !session.paused;
    if (session.round?.strike) {
      const strike = session.round.strike;
      ui.strike.hidden = !['OPEN', 'RESOLVED'].includes(strike.status);
      ui.strikeCount.textContent = strike.status === 'OPEN'
        ? 'Penalty ' + (strike.counts?.penalty || 0) + ' · Spare ' + (strike.counts?.spare || 0) + ' · closes ' + new Date(strike.closesAt).toLocaleTimeString()
        : strike.choice === 'TIME_PENALTY'
          ? session.round.modifierAppliedSeconds > 0 ? 'Time penalty variant applied: −' + session.round.modifierAppliedSeconds + ' seconds.' : 'Penalty vote won; no time was removed because 30 seconds or less remained.'
          : 'The crowd spared the streamer.';
      document.querySelectorAll('[data-strike-vote]').forEach((button) => {
        button.hidden = overlayMode;
        button.disabled = isHost || !canVote || strike.status !== 'OPEN';
        button.setAttribute('aria-pressed', button.dataset.strikeVote === lastStrikeVote ? 'true' : 'false');
      });
    } else ui.strike.hidden = true;
    const ballot = session.ballot || {};
    ui.ballotCount.textContent = ballot.closed
      ? 'Vote total: ' + ballot.voteCount
      : ballot.voteCount + ' audience vote(s) · closes ' + new Date(ballot.closesAt).toLocaleTimeString();
    document.querySelectorAll('[data-vote]').forEach((button) => {
      button.hidden = overlayMode;
      button.disabled = !canVote || session.status !== 'BALLOT_OPEN';
      button.setAttribute('aria-pressed', button.dataset.vote === lastVote ? 'true' : 'false');
    });
    if (overlayMode) ui.voteMessage.textContent = '';
    else if (session.status !== 'BALLOT_OPEN') ui.voteMessage.textContent = 'Voting is closed for this round.';
    else if (ui.voteMessage.textContent === 'Voting is closed for this round.') ui.voteMessage.textContent = '';
    ui.rematch.hidden = !(isHost && session.status === 'RESULT');
    if (session.status === 'PLAYING' && session.round) {
      ui.roundTitle.textContent = 'Round ' + session.round.number + ' · ' + (TIME_MODE_LABELS[session.round.preset] || 'Extreme Sudoku');
      ui.instructions.textContent = isHost ? 'Fill the empty cells. The server checks the submitted solution.' : 'The host is playing. The board is read-only for the audience.';
      if (!isHost && Array.isArray(session.round.notes)) {
        const serializedNotes = JSON.stringify(session.round.notes);
        if (serializedNotes !== lastServerNotes) {
          lastServerNotes = serializedNotes;
          notes = Array.from({ length: 81 }, (_, index) => new Set(String(session.round.notes[index] ?? '').split('')));
          renderNotes();
        }
      }
      const serverBoard = session.round.board || session.round.givens;
      if (!boardPending && board !== serverBoard) {
        if (!ui.board.children.length || board.length !== 81) renderBoard(session.round.givens, serverBoard);
        else {
          board = serverBoard;
          document.querySelectorAll('#sudoku-board .arena-cell').forEach((cell, index) => {
            const fixed = cell.dataset.given === 'true';
            cell.value = fixed ? session.round.givens[index] : board[index] === '0' ? '' : board[index];
          });
          renderNotes();
        }
      }
      document.querySelectorAll('.arena-cell[data-given="false"]').forEach((cell) => { cell.disabled = !isHost || Boolean(session.paused); });
      ui.solve.hidden = !isHost || overlayMode;
      ui.solve.disabled = !isHost || Boolean(session.paused) || boardPending || board.includes('0');
      startTimer(session.round.deadlineAt, session.paused ? session.pausedAt : null);
    } else {
      clearInterval(timerId);
      ui.timer.textContent = '--:--';
    }
    if (session.status === 'RESULT') {
      ui.resultText.textContent = session.round && session.round.result === 'HOST' ? 'Host wins — solved before the deadline.' : 'Audience wins — time expired.';
    } else if (session.status === 'CANCELLED') {
      ui.resultText.textContent = 'Round cancelled — no winner.';
    }
    return true;
  }

  function startTimer(deadlineAt, pausedAt) {
    clearInterval(timerId);
    const update = () => {
      const end = pausedAt ? Date.parse(pausedAt) : Date.now();
      const remaining = Math.max(0, Math.ceil((Date.parse(deadlineAt) - end) / 1000));
      ui.timer.textContent = String(Math.floor(remaining / 60)).padStart(2, '0') + ':' + String(remaining % 60).padStart(2, '0');
    };
    update();
    if (!pausedAt) timerId = setInterval(update, 250);
  }

  async function refresh() {
    if (!sessionId || busy) return;
    try {
      let session;
      let isHost = false;
      if (overlayMode) {
        session = await callApi('getArenaOverlay', sessionId, presenceClient);
      } else if (hostProbe === 'host') {
        try {
          session = await callApi('getArenaHostSession', sessionId, presenceClient);
          isHost = true;
        } catch (error) {
          if (error.status !== 401 && error.status !== 403 && error.status !== 404) throw error;
          hostProbe = 'not-host';
          session = await callApi('getArenaSession', sessionId, presenceClient);
        }
      } else if (hostProbe === 'not-host') {
        session = await callApi('getArenaSession', sessionId, presenceClient);
      } else {
        try {
          session = await callApi('getArenaHostSession', sessionId, presenceClient);
          isHost = true;
          hostProbe = 'host';
        } catch (error) {
          if (error.status !== 401 && error.status !== 403 && error.status !== 404) throw error;
          hostProbe = 'not-host';
          session = await callApi('getArenaSession', sessionId, presenceClient);
        }
      }
      render(session, isHost);
      resetError();
    } catch (error) {
      showError(error);
    }
  }

  async function createSession() {
    if (busy) return;
    busy = true; resetError(); ui.create.disabled = true;
    try {
      const session = await callApi('createArenaSession', ui.preset.value);
      setSessionUrl(session.id);
      hostProbe = 'host';
      render(session, true);
      if (!pollId) pollId = setInterval(refresh, POLL_MS);
    } catch (error) { showError(error); }
    finally { busy = false; ui.create.disabled = false; }
  }

  async function joinSession() {
    const raw = ui.sessionInput.value.trim();
    const match = raw.match(/[0-9a-f]{8}-[0-9a-f-]{27}/i);
    if (!match) { showError(new Error('Enter an Arena session ID or link.')); return; }
    setSessionUrl(match[0]);
    resetError();
    await refresh();
    if (!pollId) pollId = setInterval(refresh, POLL_MS);
  }

  async function vote(choice) {
    if (!sessionId || busy || !accepted || accepted.status !== 'BALLOT_OPEN' || overlayMode) return;
    busy = true; resetError();
    try {
      const session = await callApi('castArenaPresetVote', sessionId, choice);
      lastVote = choice;
      render(session, hostCanControl);
      ui.voteMessage.textContent = 'Your vote is recorded. You can change it until the ballot closes.';
    } catch (error) { showError(error); }
    finally { busy = false; }
  }

  async function strikeVote(choice) {
    if (!sessionId || busy || hostCanControl || overlayMode || !accepted || accepted.round?.strike?.status !== 'OPEN') return;
    busy = true; resetError();
    try {
      const session = await callApi('castArenaStrikeVote', sessionId, choice);
      lastStrikeVote = choice;
      render(session, false);
      ui.strikeMessage.textContent = 'Vote recorded. Spare wins ties; zero votes means Spare.';
    } catch (error) { showError(error); }
    finally { busy = false; }
  }

  async function startRound() {
    if (!sessionId || busy || !accepted || !['BALLOT_OPEN', 'READY'].includes(accepted.status)) return;
    busy = true; ui.start.disabled = true; resetError();
    try {
      const session = await callApi('startArenaRound', sessionId, accepted.version, idempotencyKey('start'));
      render(session, true);
    } catch (error) {
      busy = false;
      showError(error);
      let latest = null;
      try { latest = await callApi('getArenaHostSession', sessionId, presenceClient); } catch (_) {}
      if (latest) render(latest, true);
      if (error.status === 409 && latest && ['BALLOT_OPEN', 'READY'].includes(latest.status) && !latest.paused) {
        try { render(await callApi('startArenaRound', sessionId, latest.version, idempotencyKey('start')), true); resetError(); }
        catch (retryError) { showError(retryError); }
      }
    } finally { busy = false; }
  }

  async function solve() {
    if (!sessionId || busy || !accepted || accepted.status !== 'PLAYING' || !hostCanControl || board.includes('0')) return;
    busy = true; ui.solve.disabled = true; resetError();
    try {
      const session = await callApi('submitArenaSolve', sessionId, accepted.version, board, idempotencyKey('solve'));
      render(session, true);
    } catch (error) { showError(error); await refresh(); }
    finally { busy = false; }
  }

  function scheduleBoardSync() {
    if (!sessionId || busy || !accepted || accepted.status !== 'PLAYING' || !hostCanControl || accepted.paused || board.length !== 81) return;
    // Never persist a complete candidate through the public board projection.
    // A complete board is sent only to the private, server-validated solve route.
    if (!board.includes('0')) {
      clearTimeout(boardSyncTimer);
      boardPending = false;
      ui.solve.disabled = false;
      return;
    }
    boardPending = true;
    ui.solve.disabled = true;
    clearTimeout(boardSyncTimer);
    boardSyncTimer = setTimeout(async () => {
      const snapshot = board;
      const notesSnapshot = notes.map((cell) => Array.from(cell).sort().join(''));
      try {
        const session = await callApi('updateArenaBoard', sessionId, accepted.round?.boardRevision || 0, snapshot, idempotencyKey('board'), notesSnapshot);
        if (session.id === acceptedSessionId && (!accepted || session.version >= accepted.version)) accepted = session;
        boardPending = false;
        if (board !== snapshot) scheduleBoardSync();
        else ui.solve.disabled = !hostCanControl || Boolean(accepted?.paused) || board.includes('0');
      } catch (error) {
        boardPending = false;
        showError(error);
        ui.solve.disabled = true;
      }
    }, 220);
  }

  async function pauseRound() {
    if (!accepted || !window.confirm('Pause the Arena for a technical issue?')) return;
    try { render(await callApi('pauseArenaSession', sessionId, accepted.version, idempotencyKey('pause')), true); }
    catch (error) { showError(error); await refresh(); }
  }

  async function resumeRound() {
    if (!accepted || !window.confirm('Resume the Arena clock?')) return;
    try { render(await callApi('resumeArenaSession', sessionId, accepted.version, idempotencyKey('resume')), true); }
    catch (error) { showError(error); await refresh(); }
  }

  async function cancelSession() {
    if (!accepted || !window.confirm('Cancel this Arena? It will end with no winner.')) return;
    try { render(await callApi('cancelArenaSession', sessionId, accepted.version, idempotencyKey('cancel')), true); }
    catch (error) { showError(error); await refresh(); }
  }

  async function rematch() {
    if (!hostCanControl || !accepted || accepted.status !== 'RESULT') return;
    busy = true; resetError(); ui.rematch.disabled = true;
    try {
      const session = await callApi('rematchArenaSession', sessionId, accepted.version, idempotencyKey('rematch'));
      setSessionUrl(session.id);
      hostProbe = 'host';
      render(session, true);
      if (!pollId) pollId = setInterval(refresh, POLL_MS);
    } catch (error) { showError(error); }
    finally { busy = false; ui.rematch.disabled = false; }
  }

  async function checkAvailability() {
    try {
      const health = await callApi('getArenaHealth');
      if (!health || health.enabled !== true) {
        const error = new Error('Arena is currently disabled.');
        error.status = 404;
        throw error;
      }
      if (!sessionId) ui.status.textContent = 'Host a round or join an Arena with its session link.';
      return true;
    } catch (error) {
      if (error.status === 404) {
        ui.status.textContent = 'Arena is currently disabled.';
        ui.startPanel.hidden = false;
        ui.create.disabled = true;
        ui.join.disabled = true;
        return false;
      }
      ui.status.textContent = 'Arena service is unavailable.';
      showError(error);
      return false;
    }
  }

  ui.create.addEventListener('click', createSession);
  ui.join.addEventListener('click', joinSession);
  ui.start.addEventListener('click', startRound);
  ui.solve.addEventListener('click', solve);
  ui.rematch.addEventListener('click', rematch);
  ui.pause.addEventListener('click', pauseRound);
  ui.resume.addEventListener('click', resumeRound);
  ui.cancel.addEventListener('click', cancelSession);
  document.querySelectorAll('[data-vote]').forEach((button) => button.addEventListener('click', () => vote(button.dataset.vote)));
  document.querySelectorAll('[data-strike-vote]').forEach((button) => button.addEventListener('click', () => strikeVote(button.dataset.strikeVote)));
  if (ui.notes) ui.notes.addEventListener('click', () => { notesMode = !notesMode; renderNotesMode(); renderNotes(); });

  // Keep the existing sign-in return-to mechanism (js/app.js) pointing at
  // Arena when the sign-in link is used from this page; otherwise /signin
  // defaults to /account after authentication.
  const signInLink = document.getElementById('arena-signin');
  if (signInLink) signInLink.addEventListener('click', stashArenaReturnTo);

  checkAvailability().then((enabled) => {
    if (!enabled) return;
    if (sessionId) {
      ui.sessionInput.value = sessionId;
      setSessionUrl(sessionId);
      ui.startPanel.hidden = true;
      ui.sessionPanel.hidden = false;
      refresh();
      pollId = setInterval(refresh, POLL_MS);
    } else {
      ui.startPanel.hidden = false;
    }
  });
  window.addEventListener('pagehide', () => { clearInterval(timerId); clearInterval(pollId); });
  // Re-detect host state after a reconnect without probing on every poll.
  window.addEventListener('online', () => {
    hostProbe = 'unknown';
    if (sessionId && !overlayMode) refresh();
  });
})();
