# Preview Final State and Cleanup Evidence — Final TwitchCon Demo Mode Candidate

**Candidate:** `d78178c4cd20040bf6e6da3b8ffaac4d0615c87d`  
**Prior candidate:** `3576aba240cfbb5681173486b25be1e013876e4d`  
**Captured:** 2026-10-31 (America/Los_Angeles)  
**Raw log:** `preview-final-state.log`

## Environment state

| Check | Final state |
|---|---|
| Candidate worktree | clean at `d78178c4cd20040bf6e6da3b8ffaac4d0615c87d`, branch `codex/arena-phase4-preview` |
| Fly API health | `200` |
| Anonymous Preview page | `200` for `/arena` and overlay; no Vercel authentication |
| Backend capacity | one Fly machine for POC presence coherence |
| Vercel Deployment Protection | disabled (`ssoProtection: null`) for the dedicated POC Preview only |
| Fly `ARENA_ENABLED` | present |
| Fly `ARENA_ALLOWED_HOST_IDS` | present (Preview host Supabase UUID only) |
| Fly `ARENA_ALLOWED_ORIGINS` | present (new Preview origin only) |
| Fly database/auth/session secrets | present, unchanged in name |
| Arena sessions for Preview host | `0` remaining after cleanup |
| Synthetic Arena accounts | `4` remaining (`arena-host-test`, `arena-voter-1/2/3`) |
| Final Demo Mode journey | host + 3 anonymous audience + overlay; pass; 0 `429`, 0 page errors |
| Anonymous audience auth | no sign-in required; opaque browser cookie voting; host-only APIs remain protected |
| Notes spectator sync | audience + overlay saw 12 → 1 → cleared, then final value |
| Test puzzle | owner Preview-only supply row remains first eligible for submission testing |
| Read-limit control | 40 same-client reads `200`; 41st `429`; other client `200` (code unchanged) |
| Preview read relaxation | `ARENA_PREVIEW_PUBLIC_READS=true` only on POC Preview; default false |

## Cleanup performed

- Deleted all test Arena sessions created during validation (POC-IR-01, sign-in, anonymous share, Flow 1 six-context journey, API smoke); the Preview host has zero remaining sessions.
- Vercel Deployment Protection remains intentionally disabled for the dedicated POC Preview so anonymous audience/overlay URLs reach the app. Production is untouched; Arena API auth/host/CSRF/origin remain server-enforced.
- Left the four synthetic Preview auth/player accounts in place for independent review.
- Removed no unrelated Preview accounts or data.
- No production resources were touched.

## Explicitly not performed

- No commit was pushed; the candidate is a local commit in the isolated worktree.
- No merge.
- No production deployment or production configuration change.
- No shared/production database migration or RLS application.
- No production feature-flag enablement.

## Cleanup limitations

- The Preview deployment URL is ephemeral. If the frontend is redeployed, `ARENA_ALLOWED_ORIGINS` must be updated and the Fly app restarted.
- The Preview URL is unlisted/noindex but reachable by anyone with the link because Vercel Protection is disabled for the POC. This is a deliberate, Preview-only access decision; production remains protected.
- The synthetic account passwords are intentionally not in this package; they are held outside the repository.
