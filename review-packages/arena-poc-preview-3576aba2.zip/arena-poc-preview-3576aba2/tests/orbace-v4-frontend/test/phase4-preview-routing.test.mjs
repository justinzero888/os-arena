import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { JSDOM } from 'jsdom';

const source = await readFile(new URL('../js/api.js', import.meta.url), 'utf8');
const mockData = await readFile(new URL('../js/mock-data.js', import.meta.url), 'utf8');
const arenaHtml = await readFile(new URL('../arena.html', import.meta.url), 'utf8');
const arenaJs = await readFile(new URL('../js/arena.js', import.meta.url), 'utf8');
assert.match(arenaHtml, /Extreme puzzles/);
assert.match(arenaHtml, /id="arena-signin"/);
assert.match(arenaJs, /sessionStorage\.setItem\('orbace_return_to', location\.pathname \+ location\.search\)/);
assert.match(arenaHtml, /Quick · 3 min/);
assert.match(arenaHtml, /Standard · 5 min/);
assert.match(arenaHtml, /Endurance · 8 min/);
assert.doesNotMatch(arenaHtml, />Easy</);
assert.doesNotMatch(arenaHtml, />Medium</);
assert.doesNotMatch(arenaHtml, />Hard</);
const calls = [];
const dom = new JSDOM('<!doctype html>', { url: 'https://arena-preview.example/arena', runScripts: 'outside-only' });
dom.window.ORBACE_CONFIG = {
  USE_MOCKS: false,
  MOCK_LATENCY_MS: 0,
  API_BASE_URL: dom.window.location.origin,
  ORG_API_URL: dom.window.location.origin,
  SAME_ORIGIN_API: true,
};
dom.window.eval(mockData);
dom.window.fetch = async (url) => {
  calls.push(String(url));
  return { ok: true, status: 200, text: async () => '{}', json: async () => ({}) };
};
dom.window.eval(source);
await dom.window.OrbaceAPI.getArenaHealth();
await dom.window.OrbaceAPI.getRecentPuzzles(1);
await dom.window.OrbaceAPI.previewPromoCode('TEST', 'web');
assert.equal(calls[0], 'https://arena-preview.example/api/arena/health');
assert.match(calls[1], /^https:\/\/arena-preview\.example\/api\/puzzles\/recent\?/);
assert.equal(calls[2], 'https://arena-preview.example/api/api/v1/promotions/preview');

const productionCalls = [];
const production = new JSDOM('<!doctype html>', { url: 'https://orbacesudoku.com/', runScripts: 'outside-only' });
production.window.ORBACE_CONFIG = {
  USE_MOCKS: false,
  MOCK_LATENCY_MS: 0,
  API_BASE_URL: 'https://api.example',
  ORG_API_URL: 'https://api.example',
};
production.window.eval(mockData);
production.window.fetch = async (url) => {
  productionCalls.push(String(url));
  return { ok: true, status: 200, text: async () => '{}', json: async () => ({}) };
};
production.window.eval(source);
await production.window.OrbaceAPI.getRecentPuzzles(1);
assert.match(productionCalls[0], /^https:\/\/api\.example\/puzzles\/recent\?/);
console.log('Phase 4 Preview API routing passed; existing absolute API routing is unchanged.');
dom.window.close();
production.window.close();

// Verify the actual Preview build output, including runtime origin expressions.
const { mkdtemp, rm } = await import('node:fs/promises');
const { tmpdir } = await import('node:os');
const { join } = await import('node:path');
const { spawnSync } = await import('node:child_process');
const output = await mkdtemp(join(tmpdir(), 'arena-preview-build-test-'));
try {
  const buildScript = new URL('../scripts/build-phase4-preview.mjs', import.meta.url);
  const env = { ...process.env, PHASE4_PREVIEW_OUTPUT_DIR: output, PHASE4_PREVIEW_SUPABASE_URL: 'https://cjimlozschaolqqsqksu.supabase.co', PHASE4_PREVIEW_SUPABASE_ANON_KEY: '"public-test-placeholder"' };
  const result = spawnSync(process.execPath, [buildScript.pathname], { env, encoding: 'utf8' });
  assert.equal(result.status, 0, 'Preview build must succeed');
  const config = await readFile(join(output, 'js/config.js'), 'utf8');
  assert.match(config, /API_BASE_URL:\s*window\.location\.origin\s*,/);
  assert.match(config, /ORG_API_URL:\s*window\.location\.origin\s*,/);
  assert.doesNotMatch(config, /(?:API_BASE_URL|ORG_API_URL):\s*["']window\.location\.origin["']/);
  assert.match(config, /SUPABASE_ANON_KEY:\s*"public-test-placeholder"/);
  assert.doesNotMatch(config, /\\"public-test-placeholder\\"/);
  const wrong = spawnSync(process.execPath, [buildScript.pathname], { env: { ...env, PHASE4_PREVIEW_SUPABASE_URL: 'https://invalid-project.supabase.co' }, encoding: 'utf8' });
  assert.notEqual(wrong.status, 0, 'Unexpected projects must fail closed');
  console.log('Phase 4 Preview build target and browser origin passed.');
} finally { await rm(output, { recursive: true, force: true }); }
