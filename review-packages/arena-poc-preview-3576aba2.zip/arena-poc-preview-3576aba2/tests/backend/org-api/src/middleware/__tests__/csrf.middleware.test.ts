import { describe, it, expect, vi, beforeEach } from 'vitest';
import { csrfGuard } from '../csrf.middleware.js';

function makeReq(overrides: Partial<{ method: string; url: string; protocol: string; headers: Record<string, string>; cookies: Record<string, string> }> = {}) {
  return {
    method: 'POST',
    url: '/',
    protocol: 'http',
    hostname: 'localhost',
    headers: {},
    cookies: {},
    ...overrides,
  } as any;
}

function makeReply() {
  const send = vi.fn().mockReturnValue(undefined);
  const status = vi.fn().mockReturnValue({ send });
  return { status, send } as any;
}

beforeEach(() => vi.clearAllMocks());

describe('csrfGuard', () => {
  it('never checks GET/HEAD/OPTIONS requests, even with a session cookie', async () => {
    const req = makeReq({ method: 'GET', cookies: { orbace_session: 'x' }, headers: { origin: 'https://evil.com' } });
    const reply = makeReply();
    await csrfGuard(req, reply);
    expect(reply.status).not.toHaveBeenCalled();
  });

  it('passes through a mutating request with no session cookie (bearer-only, immune to CSRF)', async () => {
    const req = makeReq({ method: 'POST', cookies: {}, headers: { origin: 'https://evil.com' } });
    const reply = makeReply();
    await csrfGuard(req, reply);
    expect(reply.status).not.toHaveBeenCalled();
  });

  it('allows a mutating request with the session cookie and a matching allowed Origin', async () => {
    const req = makeReq({ cookies: { orbace_session: 'x' }, headers: { origin: 'https://orbacesudoku.com' } });
    const reply = makeReply();
    await csrfGuard(req, reply);
    expect(reply.status).not.toHaveBeenCalled();
  });

  it('allows the www variant and localhost as origins', async () => {
    for (const origin of ['https://www.orbacesudoku.com', 'http://localhost:3000']) {
      const req = makeReq({ cookies: { orbace_session: 'x' }, headers: { origin } });
      const reply = makeReply();
      await csrfGuard(req, reply);
      expect(reply.status).not.toHaveBeenCalled();
    }
  });

  it('rejects a mutating request with the session cookie and a mismatched Origin', async () => {
    const req = makeReq({ cookies: { orbace_session: 'x' }, headers: { origin: 'https://evil.com' } });
    const reply = makeReply();
    await csrfGuard(req, reply);
    expect(reply.status).toHaveBeenCalledWith(403);
  });

  it('accepts exact same-origin Arena requests and rejects a scheme mismatch', async () => {
    const accepted = makeReq({
      url: '/api/arena/sessions', protocol: 'http', headers: { host: 'localhost:8080', origin: 'http://localhost:8080' },
      cookies: { orbace_session: 'x' },
    });
    const acceptedReply = makeReply();
    await csrfGuard(accepted, acceptedReply);
    expect(acceptedReply.status).not.toHaveBeenCalled();

    const rejected = makeReq({
      url: '/api/arena/sessions', protocol: 'http', headers: { host: 'localhost:8080', origin: 'https://localhost:8080' },
      cookies: { orbace_session: 'x' },
    });
    const rejectedReply = makeReply();
    await csrfGuard(rejected, rejectedReply);
    expect(rejectedReply.status).toHaveBeenCalledWith(403);
  });

  it('allows configured Preview Origin only on Arena mutations', async () => {
    process.env.ARENA_ALLOWED_ORIGINS = 'https://arena-preview.example';
    const arena = makeReq({
      url: '/api/arena/sessions', protocol: 'https', headers: { host: 'justinzero-preview.fly.dev', origin: 'https://arena-preview.example' },
      cookies: { orbace_session: 'x' },
    });
    const arenaReply = makeReply();
    await csrfGuard(arena, arenaReply);
    expect(arenaReply.status).not.toHaveBeenCalled();

    const unrelated = makeReq({
      url: '/api/supu', protocol: 'https', headers: { host: 'justinzero-preview.fly.dev', origin: 'https://arena-preview.example' },
      cookies: { orbace_session: 'x' },
    });
    const unrelatedReply = makeReply();
    await csrfGuard(unrelated, unrelatedReply);
    expect(unrelatedReply.status).toHaveBeenCalledWith(403);
    delete process.env.ARENA_ALLOWED_ORIGINS;
  });

  it('rejects when the session cookie is present, no Origin header, and no double-submit token', async () => {
    const req = makeReq({ cookies: { orbace_session: 'x' }, headers: {} });
    const reply = makeReply();
    await csrfGuard(req, reply);
    expect(reply.status).toHaveBeenCalledWith(403);
  });

  it('allows when the session cookie is present, no Origin header, but a matching double-submit token is', async () => {
    const req = makeReq({
      cookies: { orbace_session: 'x', orbace_csrf: 'matching-token' },
      headers: { 'x-csrf-token': 'matching-token' },
    });
    const reply = makeReply();
    await csrfGuard(req, reply);
    expect(reply.status).not.toHaveBeenCalled();
  });

  it('rejects when the double-submit cookie and header do not match', async () => {
    const req = makeReq({
      cookies: { orbace_session: 'x', orbace_csrf: 'real-token' },
      headers: { 'x-csrf-token': 'forged-token' },
    });
    const reply = makeReply();
    await csrfGuard(req, reply);
    expect(reply.status).toHaveBeenCalledWith(403);
  });
});
