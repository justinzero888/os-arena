import { describe, expect, it } from 'vitest';
import { serializeRequestForLog } from '../request-log-serializer.js';

describe('request log privacy serializer', () => {
  it('keeps only request metadata and strips query values and network identifiers', () => {
    const serialized = serializeRequestForLog({
      id: 'req-test', method: 'POST', url: '/api/arena/sessions?guest=private-value', hostname: 'preview.example',
      routeOptions: { url: '/api/arena/sessions/:id/votes' },
      remoteAddress: '203.0.113.1', remotePort: 54321,
      headers: { cookie: 'arena_guest=private-value', authorization: 'Bearer private-value' },
    } as any);
    expect(serialized).toEqual({ reqId: 'req-test', method: 'POST', url: '/api/arena/sessions/:id/votes', hostname: 'preview.example' });
    expect(JSON.stringify(serialized)).not.toContain('private-value');
    expect(JSON.stringify(serialized)).not.toContain('203.0.113.1');
  });
});
