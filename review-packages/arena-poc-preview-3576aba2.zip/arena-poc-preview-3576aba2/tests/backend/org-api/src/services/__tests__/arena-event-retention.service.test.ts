import { describe, expect, it, vi } from 'vitest';
import { purgeOldArenaEvents, readArenaEventRetentionDays } from '../arena-event-retention.service.js';

describe('Arena event retention', () => {
  it.each([undefined, '', '0', '8', '30', '7days', ' 7'])('fails closed for invalid retention setting %j', (value) => {
    const env = {} as NodeJS.ProcessEnv;
    if (value !== undefined) env.ARENA_EVENT_RETENTION_DAYS = value;
    expect(readArenaEventRetentionDays(env)).toBeNull();
  });

  it('accepts only a whole-number window from one through seven days', () => {
    expect(readArenaEventRetentionDays({ ARENA_EVENT_RETENTION_DAYS: '7' } as NodeJS.ProcessEnv)).toBe(7);
    expect(readArenaEventRetentionDays({ ARENA_EVENT_RETENTION_DAYS: '1' } as NodeJS.ProcessEnv)).toBe(1);
  });

  it('purges only events older than the configured maximum window', async () => {
    const deleteMany = vi.fn(async () => ({ count: 3 }));
    const now = new Date('2026-10-29T12:00:00.000Z');
    const result = await purgeOldArenaEvents({ arenaEvent: { deleteMany } }, now, 7);
    expect(result).toEqual({ enabled: true, retentionDays: 7, deleted: 3 });
    expect(deleteMany).toHaveBeenCalledWith({
      where: { createdAt: { lt: new Date('2026-10-22T12:00:00.000Z') } },
    });
  });

  it('does not query when retention is unset or greater than seven days', async () => {
    const deleteMany = vi.fn(async () => ({ count: 0 }));
    const db = { arenaEvent: { deleteMany } };
    expect(await purgeOldArenaEvents(db, new Date(), null)).toEqual({ enabled: false, retentionDays: null, deleted: 0 });
    expect(await purgeOldArenaEvents(db, new Date(), 8)).toEqual({ enabled: false, retentionDays: null, deleted: 0 });
    expect(deleteMany).not.toHaveBeenCalled();
  });
});
