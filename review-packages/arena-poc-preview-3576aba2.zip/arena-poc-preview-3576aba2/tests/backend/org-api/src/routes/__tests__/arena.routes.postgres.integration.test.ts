import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import cookie from '@fastify/cookie';
import rateLimit from '@fastify/rate-limit';
import puppeteer from 'puppeteer';

const authMock = vi.hoisted(() => vi.fn(async () => ({ sub: 'arena-test-host' })));
vi.mock('../../middleware/auth.middleware.js', () => ({ authenticate: authMock }));

const databaseUrl = process.env.ARENA_TEST_DATABASE_URL;
const integrationDescribe = databaseUrl ? describe : describe.skip;
const puzzleId = '11111111-1111-4111-8111-111111111112';
const puzzleGivens = '860010000900438000032000090200090006700206004100050009090000520000743008000020013';
const puzzleSolution = '867912345915438672432675891283194756759286134146357289394861527521743968678529413';

integrationDescribe('Arena Fastify + Prisma + disposable PostgreSQL', () => {
  let app: FastifyInstance;
  let prisma: typeof import('../../lib/prisma.js').prisma;
  let arenaRoutes: typeof import('../arena.routes.js').arenaRoutes;
  const sessionIds: string[] = [];

  beforeAll(async () => {
    const url = new URL(databaseUrl!);
    if (!['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || url.pathname !== '/arena_app') {
      throw new Error('ARENA_TEST_DATABASE_URL must point to a local database named arena_app');
    }
    process.env.DATABASE_URL = databaseUrl;
    process.env.ARENA_ENABLED = 'true';
    process.env.ARENA_ALLOWED_HOST_IDS = 'arena-test-host';
    const prismaModule = await import('../../lib/prisma.js');
    prisma = prismaModule.prisma;
    ({ arenaRoutes } = await import('../arena.routes.js'));
    await prisma.arenaPuzzleSupply.deleteMany({ where: { id: puzzleId } });
    await prisma.arenaPuzzleSupply.create({
      data: { id: puzzleId, tier: 'Extreme', givens: puzzleGivens, solution: puzzleSolution, eligible: true, provenance: 'TEST_FIXTURE' },
    });
  }, 15_000);

  afterAll(async () => {
    if (sessionIds.length) await prisma.arenaSession.deleteMany({ where: { id: { in: sessionIds } } });
    if (prisma) {
      await prisma.arenaPuzzleSupply.deleteMany({ where: { id: puzzleId } });
      await prisma.$disconnect();
    }
    if (app) await app.close();
    delete process.env.ARENA_ENABLED;
    delete process.env.ARENA_ALLOWED_HOST_IDS;
    delete process.env.DATABASE_URL;
  });

  it('persists vote, state transition, private solution, and result without leaking private fields', async () => {
    app = Fastify();
    await app.register(cookie);
    await app.register(rateLimit);
    // Test-only fixture controls; this server is never exported or used by
    // the production Fastify app.
    app.get('/__arena_e2e', async (_request, reply) => reply.type('text/html').send('<!doctype html><title>Arena E2E</title><main>Arena local browser test</main>'));
    app.post<{ Body: { sessionId: string } }>('/__arena_e2e/close-ballot', async (request) => {
      await prisma.arenaSession.update({ where: { id: request.body.sessionId }, data: { ballotClosesAt: new Date(Date.now() - 1_000) } });
      return { closed: true };
    });
    await app.register(arenaRoutes);

    const createdResponse = await app.inject({ method: 'POST', url: '/api/arena/sessions', payload: { defaultPreset: 'quick' } });
    expect(createdResponse.statusCode).toBe(201);
    const created = createdResponse.json();
    const dbSessionId = created.id as string;
    sessionIds.push(dbSessionId);
    expect(created.status).toBe('BALLOT_OPEN');

    const voteResponse = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${dbSessionId}/votes`,
      headers: { origin: 'http://localhost:80' }, payload: { choice: 'standard' },
    });
    expect(voteResponse.statusCode).toBe(200);
    expect(voteResponse.headers['set-cookie']).toBeUndefined();

    await prisma.arenaSession.update({ where: { id: dbSessionId }, data: { ballotClosesAt: new Date(Date.now() - 1_000) } });
    const readyResponse = await app.inject({ method: 'GET', url: `/api/arena/sessions/${dbSessionId}` });
    expect(readyResponse.json().status).toBe('READY');

    const startedResponse = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${dbSessionId}/start`,
      headers: { 'idempotency-key': 'arena-start-local-1' }, payload: { expectedVersion: readyResponse.json().version },
    });
    expect(startedResponse.statusCode).toBe(200);
    expect(startedResponse.json().round.preset).toBe('standard');

    const publicSnapshot = await app.inject({ method: 'GET', url: `/api/arena/sessions/${dbSessionId}` });
    expect(publicSnapshot.statusCode).toBe(200);
    expect(publicSnapshot.body).not.toContain(puzzleSolution);
    expect(publicSnapshot.body).not.toContain('arena-test-host');

    const hostSnapshot = await app.inject({ method: 'GET', url: `/api/arena/sessions/${dbSessionId}/host` });
    expect(hostSnapshot.statusCode).toBe(200);
    expect(hostSnapshot.json().hostControls).toEqual({ canStart: false, canSolve: true, canPause: true, canResume: false, canCancel: true });
    expect(hostSnapshot.body).not.toContain(puzzleSolution);

    const solvedResponse = await app.inject({
      method: 'POST', url: `/api/arena/sessions/${dbSessionId}/solve`,
      headers: { 'idempotency-key': 'arena-solve-local-1' },
      payload: { expectedVersion: startedResponse.json().version, board: puzzleSolution },
    });
    expect(solvedResponse.statusCode).toBe(200);
    expect(solvedResponse.json().status).toBe('RESULT');

    const persisted = await prisma.arenaSession.findUniqueOrThrow({
      where: { id: dbSessionId }, include: { rounds: true, votes: true, events: true },
    });
    expect(persisted.votes).toHaveLength(1);
    expect(persisted.rounds[0].solution).toBe(puzzleSolution);
    expect(persisted.rounds[0].result).toBe('HOST');
    expect(persisted.events.map((event) => event.version)).toEqual([1, 2, 3, 4, 5]);
  }, 15_000);

  it('plays the persisted route journey from a real same-origin browser', async () => {
    const address = await app.listen({ host: '127.0.0.1', port: 0 });
    const browser = await puppeteer.launch({ headless: true });
    try {
      const page = await browser.newPage();
      await page.goto(`${address}/__arena_e2e`);
      const journey = await page.evaluate(async (solution) => {
        const createdResponse = await fetch('/api/arena/sessions', {
          method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ defaultPreset: 'quick' }),
        });
        const created = await createdResponse.json();
        const voteResponse = await fetch(`/api/arena/sessions/${created.id}/votes`, {
          method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ choice: 'standard' }),
        });
        await fetch('/__arena_e2e/close-ballot', {
          method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ sessionId: created.id }),
        });
        const readyResponse = await fetch(`/api/arena/sessions/${created.id}`);
        const ready = await readyResponse.json();
        const startResponse = await fetch(`/api/arena/sessions/${created.id}/start`, {
          method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'arena-browser-start-1' },
          body: JSON.stringify({ expectedVersion: ready.version }),
        });
        const started = await startResponse.json();
        const publicResponse = await fetch(`/api/arena/sessions/${created.id}`);
        const publicBody = await publicResponse.text();
        const hostResponse = await fetch(`/api/arena/sessions/${created.id}/host`);
        const hostBody = await hostResponse.text();
        const solveResponse = await fetch(`/api/arena/sessions/${created.id}/solve`, {
          method: 'POST', headers: { 'content-type': 'application/json', 'idempotency-key': 'arena-browser-solve-1' },
          body: JSON.stringify({ expectedVersion: started.version, board: solution }),
        });
        return {
          sessionId: created.id as string,
          createdStatus: createdResponse.status,
          voteStatus: voteResponse.status,
          readyStatus: ready.status,
          startStatus: startResponse.status,
          preset: started.round?.preset,
          publicBody,
          hostBody,
          solveStatus: solveResponse.status,
          result: (await solveResponse.json()).status,
        };
      }, puzzleSolution);

      sessionIds.push(journey.sessionId);
      expect(journey.createdStatus).toBe(201);
      expect(journey.voteStatus).toBe(200);
      expect(journey.readyStatus).toBe('READY');
      expect(journey.startStatus).toBe(200);
      expect(journey.preset).toBe('standard');
      expect(journey.publicBody).not.toContain(puzzleSolution);
      expect(journey.publicBody).not.toContain('arena-test-host');
      expect(journey.hostBody).not.toContain(puzzleSolution);
      expect(journey.solveStatus).toBe(200);
      expect(journey.result).toBe('RESULT');
    } finally {
      await browser.close();
    }
  }, 20_000);
});
