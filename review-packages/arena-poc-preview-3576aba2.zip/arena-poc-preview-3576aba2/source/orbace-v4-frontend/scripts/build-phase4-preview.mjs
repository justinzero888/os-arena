import { cp, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.resolve(process.env.PHASE4_PREVIEW_OUTPUT_DIR || path.join(root, 'dist-phase4-preview'));
// Supabase CLI `-o env` emits values with surrounding quotes. Strip one pair
// so the generated browser config contains the raw key, not a quoted string
// (which Supabase rejects with "Invalid API key").
const unquote = (value) => typeof value === 'string' ? value.replace(/^(['"])(.*)\1$/, '$2') : value;
const supabaseUrl = unquote(process.env.PHASE4_PREVIEW_SUPABASE_URL);
const anonKey = unquote(process.env.PHASE4_PREVIEW_SUPABASE_ANON_KEY);

if (!supabaseUrl || !anonKey || /\s/.test(anonKey)) {
  throw new Error('Preview build requires PHASE4_PREVIEW_SUPABASE_URL and PHASE4_PREVIEW_SUPABASE_ANON_KEY.');
}
let supabaseHost;
try {
  const parsed = new URL(supabaseUrl);
  if (parsed.protocol !== 'https:' || parsed.pathname !== '/' || parsed.search || parsed.hash) throw new Error();
  supabaseHost = parsed.hostname;
} catch {
  throw new Error('PHASE4_PREVIEW_SUPABASE_URL must be an HTTPS project URL.');
}
if (supabaseHost !== 'cjimlozschaolqqsqksu.supabase.co') {
  throw new Error('Preview build refused: Supabase URL does not match the owner-authorized Preview project.');
}

await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
for (const entry of await readdir(root)) {
  if (['node_modules', '.vercel', '.git', 'dist', 'dist-phase4-preview'].includes(entry)) continue;
  await cp(path.join(root, entry), path.join(output, entry), { recursive: true });
}

const configPath = path.join(output, 'js/config.js');
let config = await readFile(configPath, 'utf8');
const replaceOne = (name, value) => {
  const pattern = new RegExp(`(^\\s*${name}:\\s*)[^,]+,`, 'm');
  if (!pattern.test(config)) throw new Error(`Preview build could not safely override ${name}.`);
  const expression = (name === 'API_BASE_URL' || name === 'ORG_API_URL') ? value : JSON.stringify(value);
  config = config.replace(pattern, `$1${expression},`);
};
replaceOne('API_BASE_URL', 'window.location.origin');
replaceOne('ORG_API_URL', 'window.location.origin');
replaceOne('SUPABASE_URL', supabaseUrl);
replaceOne('SUPABASE_ANON_KEY', anonKey);
replaceOne('GOOGLE_CLIENT_ID', '');
replaceOne('GA4_ID', null);
config = config.replace(/(ADS:\s*\{\s*ENABLED:\s*)true/, '$1false');
if (!/SAME_ORIGIN_API:\s*true/.test(config)) {
  config = config.replace(/(ORG_API_URL:[^\n]*\n)/, '$1  SAME_ORIGIN_API: true,\n');
}
await writeFile(configPath, config);
console.log('Built isolated Phase 4 Preview frontend with same-origin API routing; analytics and ads disabled.');
