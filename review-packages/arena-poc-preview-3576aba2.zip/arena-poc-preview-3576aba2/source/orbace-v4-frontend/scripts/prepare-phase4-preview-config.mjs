import { readFile, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

const configPath = new URL('../vercel.json', import.meta.url);
const outputPath = path.join(os.tmpdir(), 'orbace-arena-phase4-preview-vercel.json');
const previewSupabaseOrigin = 'https://cjimlozschaolqqsqksu.supabase.co';
const config = JSON.parse(await readFile(configPath, 'utf8'));
// The local .vercel link lives at the monorepo root for this POC project, so
// build commands and the output directory are relative to that root.
config.buildCommand = 'cd orbace-v4-frontend && npm run build:phase4-preview';
config.outputDirectory = 'orbace-v4-frontend/dist-phase4-preview';
config.installCommand = 'cd orbace-v4-frontend && npm ci';
config.rewrites = [
  { source: '/api/arena/:path*', destination: 'https://justinzero-preview.fly.dev/api/arena/:path*' },
  { source: '/api/:path*', destination: 'https://justinzero-preview.fly.dev/:path*' },
  ...config.rewrites.filter((rewrite) => rewrite.source !== '/api/:path*'),
];
// Preview builds use the Preview Supabase project; the committed production
// CSP only allows the production Supabase origin.
for (const header of config.headers ?? []) {
  for (const entry of header.headers ?? []) {
    if (entry.key === 'Content-Security-Policy' && !entry.value.includes(previewSupabaseOrigin)) {
      entry.value = entry.value.replace("connect-src 'self'", `connect-src 'self' ${previewSupabaseOrigin}`);
    }
  }
}
await writeFile(outputPath, `${JSON.stringify(config, null, 2)}\n`);
console.log(`Prepared local-only Vercel Preview config at ${outputPath}; production vercel.json was not changed.`);
