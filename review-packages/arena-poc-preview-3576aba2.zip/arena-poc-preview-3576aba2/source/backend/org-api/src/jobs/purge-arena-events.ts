/** Run with `npm run purge:arena-events`. Schedule only in the authorized
 * Preview app after target verification. Unset/invalid retention is a no-op. */
import { prisma } from '../lib/prisma.js';
import { purgeOldArenaEvents, readArenaEventRetentionDays } from '../services/arena-event-retention.service.js';

async function main() {
  const result = await purgeOldArenaEvents(prisma, new Date(), readArenaEventRetentionDays());
  // Counts only; never log event payloads, guest keys, host IDs, or request IPs.
  console.log('[purge-arena-events]', JSON.stringify(result));
}

main()
  .then(() => prisma.$disconnect())
  .then(() => process.exit(0))
  .catch(async (error: unknown) => {
    console.error('[purge-arena-events] failed', error instanceof Error ? error.name : 'unknown');
    await prisma.$disconnect().catch(() => {});
    process.exit(1);
  });
