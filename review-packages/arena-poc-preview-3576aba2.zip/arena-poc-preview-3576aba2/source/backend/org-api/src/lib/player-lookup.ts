import type { AuthenticatedUser } from '../middleware/auth.middleware.js';

export interface PlayerLookupDb {
  playerAccount: {
    // Method shorthand (not an arrow-typed property) is required here — the
    // arrow form fails `strictFunctionTypes` against Prisma's real client
    // signature (contravariant checking rejects it; method shorthand is
    // checked bivariantly and accepts it). Don't "clean this up".
    findFirst(args: unknown): Promise<{ id: string; [key: string]: unknown } | null>;
  };
}

// Tier-1 players are looked up by tier1_uuid, Tier-2 (Supabase-linked) players
// by supabase_id — `user.sub` alone is not a player row id for either case.
export async function findPlayerForUser(db: PlayerLookupDb, user: AuthenticatedUser) {
  return db.playerAccount.findFirst({
    where: {
      OR: [
        { tier1Uuid: user.tier1Uuid ?? undefined },
        { supabaseId: user.sub },
      ],
    },
  });
}
