/**
 * Phase 2 puzzle-identity feature flags (instruction §13).
 *
 * There is no pre-existing feature-flag module in this backend (confirmed by
 * grep across src/ before writing this) — every prior conditional behavior
 * in this codebase is either always-on or gated by ad hoc env checks at the
 * call site. This module exists only to give the Phase 2 flags one shared,
 * uniform evaluation path so they can't drift from each other or from the
 * "unknown/missing/error resolves to disabled" contract below.
 *
 * All flags default OFF and are independently controlled — enabling one
 * never implicitly enables another; each is read fresh from `process.env`
 * on every call rather than cached at startup, since Phase 2 has to
 * tolerate a flag flip mid-request (instruction §16: "Feature flag changes
 * during request").
 *
 * `puzzle_key_dual_write_catalog` / `puzzle_key_dual_write_attempts` (PM
 * review, 2026-09-03): originally one flag, `puzzle_key_dual_write`, gated
 * both the puzzle-source/catalog-ingestion flows (pack-loader.ts, admin
 * PuzzleDaily import, Challenge-the-House — puzzle-source-dual-write
 * .service.ts) AND the Attempt/bulk-import/competition-attempt flows
 * (attempt-dual-write.service.ts, bulk-import.service.ts, attempts.routes
 * .ts) — meaning it could not be activated for the approved first shadow
 * scope (source/catalog ingestion only) without also activating Attempt
 * dual-write, which the shadow-activation plan explicitly does not
 * authorize yet. Split into two independently-activatable flags along
 * exactly that boundary; every other flow already had its own dedicated
 * flag from the start (`supu_dual_write`, `tea_manifest_shadow`,
 * `competition_attempt_shadow`) and needed no change. Never deployed with
 * the old single flag enabled anywhere (confirmed by Team D's dormant-
 * deployment verification — zero `FLAG_*` secrets in production), so this
 * is a clean rename, not a migration.
 *
 * `puzzle_key_dual_write_catalog_flows` (Phase 2 closeout §4, 2026-09-03):
 * `puzzle_key_dual_write_catalog` still gates all three source/catalog
 * call sites together — pack-loader.ts (PACK_LOAD), the admin PuzzleDaily
 * import route (ADMIN_DAILY_IMPORT), *and* public Challenge-the-House
 * puzzle creation (CHALLENGE_THE_HOUSE) — which the closeout instruction's
 * non-negotiable boundary #1 forbids: "Public Challenge-the-House must
 * have a separate flag or be excluded by a fail-closed flow allowlist."
 * Rather than a second boolean (the instruction's other approved pattern),
 * this adds a comma-separated allowlist read alongside the master flag:
 * only a call site whose canonical flow identifier appears in
 * `FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS` gets canonical access, even
 * when the master flag is `true`. The production allowlist is authorized
 * to contain only `PACK_LOAD,ADMIN_DAILY_IMPORT` — `CHALLENGE_THE_HOUSE`
 * has no approved production configuration and stays excluded by omission.
 * Missing, empty, unparseable, or containing any token outside the known
 * three identifiers: the whole allowlist resolves to empty (nothing
 * allowed), never "allow what we understood." See
 * `parseCatalogDualWriteFlowAllowlist` / `isCatalogDualWriteFlowAllowed`.
 *
 * `tea_manifest_publish` (Phase 3 Workstream 1, dormant): gates
 * `tea-manifest-generator.service.ts`'s real publication of signed
 * `TeaManifest` rows. Deliberately independent of `tea_manifest_shadow` —
 * that flag gates Phase 2's existing, already-proven-safe-in-prod
 * observation-only `TeaReconciliationAudit` write (unchanged by this
 * workstream); `tea_manifest_publish` gates a materially new, real write
 * surface with a signing-key dependency and a new failure mode
 * (`SIGNING_KEY_UNAVAILABLE`) that `tea_manifest_shadow` never had.
 * Conflating them would mean flipping one flag for audit purposes could
 * accidentally also start real manifest publication. Known open item
 * (Phase 2 ambiguity report, not yet resolved by this workstream):
 * `puzzle_key_shadow_validate` still has no defined per-flow scope — it
 * remains global across every dual-write call site including this new
 * one, same as every existing flow. Scoping it per-flow (mirroring the
 * catalog allowlist above) is a deliberately deferred decision, not
 * silently dropped — retrofitting the shared
 * `dual-write-observability.service.ts` helper that every Phase 2 call
 * site already relies on is a bigger, separately-reviewable change than
 * this workstream's own scope.
 *
 * `canonical_supu_write` (Phase 3 Workstream 3, dormant): gates
 * `supu-canonical-write.service.ts`'s creation of real canonical `Solve` +
 * `SuPu` rows from `POST /supu`. Deliberately a new, independent flag
 * rather than reusing `supu_dual_write` -- an earlier planning note
 * (docs/plans/2026-09-02-team-d-phase1-post-schema-backend-audit.md line
 * 283) suggested folding this into `supu_dual_write`, but that flag
 * already gates a materially different, already-shipped write surface
 * (the `CanonicalLinkage` mapping row only -- no `Solve`/`SuPu` creation).
 * Reusing it here would mean flipping `supu_dual_write` for its existing,
 * already-proven-safe purpose could silently also start minting real
 * canonical `Solve`/`SuPu` rows -- exactly the conflated-risk-surface
 * mistake `puzzle_key_dual_write_catalog`/`puzzle_key_dual_write_attempts`
 * were split apart to avoid (see above). WS3 deliberately does not write
 * `SolveEvent` rows or populate `SuPu.replayHash` -- neither web nor
 * mobile sends real per-move timestamps today (both down-convert to a
 * lossy `{i,v,t}` wire shape before `POST /supu`), so `clientElapsedMs`
 * has no truthful value to write into the frozen, hash-chained
 * `event-hash-v1` contract. Fabricating one was considered and explicitly
 * rejected (user decision, 2026-09-03) -- a future workstream adds real
 * per-move timing to the wire contract before `SolveEvent` gets built.
 *
 * `canonical_supu_read` (Phase 3 Workstream 4, dormant): gates both new
 * read-only routes — `GET /v1/supus/:supuId` and
 * `GET /v1/solves/:solveId/events` — added by
 * `supu-canonical-read.service.ts`. A GET endpoint has no side effects of
 * its own, but the PM boundary is explicit that no Phase 3 capability
 * "cuts a live read path over to canonical storage" without its own
 * activation decision, so these routes stay flag-gated like every write:
 * when off, they respond `404` as if the route doesn't exist at all,
 * rather than a distinguishing "feature disabled" error that would leak
 * the route's existence to a prober. One flag for both endpoints — the
 * plan groups them as a single "read adapter" capability, and they always
 * activate together (the events endpoint is meaningless without the
 * parent SuPu endpoint to link from).
 *
 * `guest_claim_shadow` (Phase 3 Workstream 2, dormant): gates
 * `POST /auth/install/register-key`, `POST /auth/install/challenge`
 * (`guest-claim.service.ts`), and the new optional `installation_claim`
 * branch inside `POST /auth/uuid/upgrade`. One flag covers all three —
 * registering a key is useless without the challenge/verify consumer and
 * vice versa, same reasoning as `canonical_supu_read` covering its pair of
 * endpoints. Per Phase 0 Decision 5 (gap-analysis plan §4.6): the
 * installation-key signature this gates is a non-blocking audit/risk
 * signal only, layered on top of `/auth/uuid/upgrade`'s existing
 * OAuth-verification trust anchor — this flag never changes that route's
 * actual authorization decision, on or off.
 *
 * `supu_capture_v2_validate` / `supu_lab_write` / `supu_capture_v2_share`
 * (Su-Pu Replay v2 Phase 3, 2026-09-09): gate the new isolated
 * `/supu/lab/*` endpoints and, eventually, the real save path.
 * `supu_capture_v2_validate` allows a v2 envelope on the lab endpoints;
 * `supu_lab_write` gates whether the lab write path exists at all — when
 * off, every `/supu/lab/*` route responds 404 as if it doesn't exist,
 * same "don't leak the route's existence" discipline as
 * `canonical_supu_read`. Both are independent of each other (a lab reader
 * could exist without ever accepting a v2 body) and, deliberately, of
 * `supu_capture_v2_share` — that third flag is for a LATER change (v2 on
 * the real `POST /supu`) and stays off through all of Phase 3; flipping
 * the two lab flags must never be able to affect `SupuShare` in any way,
 * since `SupuShare` is never inserted into or updated by lab code at all.
 *
 * `supu_annotation_write` (Su-Pu Replay v2 Phase 5, 2026-09-09): gates the
 * new `/supu/:supuId/annotation*` routes — self-documentation + coach
 * review notes anchored to an already-recorded Su-Pu capture stream, never
 * editing `SupuShare` or its capture columns. Off (the production default)
 * means every annotation route responds 404, same "don't leak the route's
 * existence" discipline as `canonical_supu_read` and `supu_lab_write`.
 * Independent of the three `supu_capture_v2_*`/`supu_lab_write` flags —
 * annotating a real, already-saved Su-Pu has nothing to do with the lab's
 * draft-authoring surface.
 *
 * `supu_story_write` (Su-Pu six-priorities brief, Priority 2, 2026-09-21):
 * gates `/supu/lab/:draftId/story*` — an author's own post-solve narrative
 * shaping (title, opening question, takeaway, ordered chapters) of a draft
 * they already own. Off (the production default) means every story route
 * responds 404, same "don't leak the route's existence" discipline as
 * `supu_lab_write` and `supu_annotation_write`. Independent of both:
 * shaping a story on a draft has nothing to do with whether the lab's own
 * write path or the separate self/coach annotation surface are on.
 *
 * `supu_capture_versioning` (Su-Pu Capture workspace execution plan,
 * Package 3, 2026-09-22): gates the "Continue work" capability —
 * `continued_from_version_id` on `POST /supu/lab` (a new row/version in
 * an existing family, rather than an ordinary same-sitting update) and
 * the whole `GET /supu/lab/:id/versions` endpoint. Off (the production
 * default) means `continued_from_version_id` is rejected with 403 and
 * the versions endpoint responds 404, same "don't leak the route's
 * existence" discipline as `supu_lab_write`/`supu_story_write` — but,
 * unlike those, an ORDINARY save/create/update on `/supu/lab` is
 * completely unaffected either way, on or off: every existing caller
 * that never sends `continued_from_version_id` sees zero behavior
 * change regardless of this flag, including the new `version`/
 * `family_id`/`parent_version_id` fields on every response, which are
 * unconditional (informational only, never gated) since they carry no
 * write-path risk on their own. Independent of `supu_lab_write` and
 * `supu_story_write` — versioning an existing draft has nothing to do
 * with whether the lab's write path or the separate story-shaping
 * surface are on.
 *
 * `canonical_solve_history_read` (Phase 3 Workstream 6, dormant, reframed):
 * gates `GET /v1/me/solves` (`solve-history-read.service.ts`) — a list of
 * a player's own canonical `Solve` rows across every context. Originally
 * scoped as a mirror of `GET /me/results`/`GET /player/me/submissions`
 * (competition-result views: rank, points, event status), but no
 * canonical table carries any of that — reframed to a general solve
 * history instead (user decision, 2026-09-04) rather than shipping an
 * endpoint that's mostly null for its stated purpose. Independent flag
 * from `canonical_supu_read`: listing every solve a player has ever made
 * is a different-shaped, more sensitive read than fetching one
 * already-known SuPu id, and the plan treats them as separate PM-named
 * capabilities.
 */

/** The three call sites `puzzle_key_dual_write_catalog` covers. Only
 *  `PACK_LOAD` and `ADMIN_DAILY_IMPORT` have an approved production
 *  allowlist entry — `CHALLENGE_THE_HOUSE` exists here so the allowlist
 *  parser and isolation tests can name it, not because it's authorized. */
export type CatalogDualWriteFlow = 'PACK_LOAD' | 'ADMIN_DAILY_IMPORT' | 'CHALLENGE_THE_HOUSE';

const CATALOG_DUAL_WRITE_FLOWS: readonly CatalogDualWriteFlow[] = [
  'PACK_LOAD',
  'ADMIN_DAILY_IMPORT',
  'CHALLENGE_THE_HOUSE',
];

const CATALOG_FLOWS_ENV_VAR = 'FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS';

/**
 * Parses `FLAG_PUZZLE_KEY_DUAL_WRITE_CATALOG_FLOWS` into the set of
 * catalog flows currently allowed canonical access. Fails closed (returns
 * an empty set) on anything not a clean, comma-separated list of exactly
 * the three known identifiers — missing, empty, whitespace-only, unknown
 * tokens, or duplicate-only input with an unknown token mixed in. A
 * thrown error (e.g. `process.env` unavailable) also fails closed.
 */
export function parseCatalogDualWriteFlowAllowlist(): ReadonlySet<CatalogDualWriteFlow> {
  try {
    const raw = process.env[CATALOG_FLOWS_ENV_VAR];
    if (!raw || raw.trim() === '') return new Set();
    const tokens = raw.split(',').map((t) => t.trim()).filter((t) => t !== '');
    if (tokens.length === 0) return new Set();
    const known = new Set(CATALOG_DUAL_WRITE_FLOWS);
    for (const token of tokens) {
      if (!known.has(token as CatalogDualWriteFlow)) return new Set();
    }
    return new Set(tokens as CatalogDualWriteFlow[]);
  } catch {
    return new Set();
  }
}

/**
 * True only when `puzzle_key_dual_write_catalog` is enabled AND `flow` is
 * present in the parsed allowlist. This is the single choke point
 * `puzzle-source-dual-write.service.ts` must call — no call site may
 * proceed on the master flag alone.
 */
export function isCatalogDualWriteFlowAllowed(flow: CatalogDualWriteFlow): boolean {
  if (!isPuzzleIdentityFlagEnabled('puzzle_key_dual_write_catalog')) return false;
  return parseCatalogDualWriteFlowAllowlist().has(flow);
}

export type PuzzleIdentityFlag =
  | 'puzzle_key_dual_write_catalog'
  | 'puzzle_key_dual_write_attempts'
  | 'puzzle_key_shadow_validate'
  | 'solve_dual_write'
  | 'supu_dual_write'
  | 'tea_manifest_shadow'
  | 'competition_attempt_shadow'
  | 'tea_manifest_publish'
  | 'canonical_supu_write'
  | 'canonical_supu_read'
  | 'canonical_solve_history_read'
  | 'guest_claim_shadow'
  | 'supu_capture_v2_validate'
  | 'supu_capture_v3_validate'
  | 'supu_capture_v4_validate'
  | 'supu_capture_v5_validate'
  | 'supu_lab_write'
  | 'supu_capture_v2_share'
  | 'supu_annotation_write'
  | 'supu_story_write'
  | 'supu_capture_versioning'
  | 'ranking_capture_v5_validate'
  /** Su-Pu Library Phase 1 (2026-10-19): enables the library index writer's
   *  side effects on existing write paths (POST /supu entry upsert, capture
   *  publish entry upsert, appeal create/resolve release holds). Default off;
   *  writes only to the new supu_library_* tables, never to existing rows. */
  | 'supu_library_index_write'
  /** Su-Pu Library Phase 3 read switch (2026-10-19): reserved. NOT read by
   *  any code in Phase 1/2 — wiring it is held until the PM decisions and
   *  per-format release conditions are recorded in docs/shared_artifacts/. */
  | 'supu_library_v2';

export const PUZZLE_IDENTITY_FLAGS: readonly PuzzleIdentityFlag[] = [
  'puzzle_key_dual_write_catalog',
  'puzzle_key_dual_write_attempts',
  'puzzle_key_shadow_validate',
  'solve_dual_write',
  'supu_dual_write',
  'tea_manifest_shadow',
  'competition_attempt_shadow',
  'tea_manifest_publish',
  'canonical_supu_write',
  'canonical_supu_read',
  'canonical_solve_history_read',
  'guest_claim_shadow',
  'supu_capture_v2_validate',
  'supu_capture_v3_validate',
  'supu_capture_v4_validate',
  'supu_capture_v5_validate',
  'supu_lab_write',
  'supu_capture_v2_share',
  'supu_annotation_write',
  'supu_story_write',
  'supu_capture_versioning',
  'ranking_capture_v5_validate',
  'supu_library_index_write',
  'supu_library_v2',
];

const ENV_PREFIX = 'FLAG_';

function envVarName(flag: PuzzleIdentityFlag): string {
  return `${ENV_PREFIX}${flag.toUpperCase()}`;
}

/**
 * Resolves a Phase 2 flag against `process.env.FLAG_<UPPER_SNAKE_NAME>`.
 * Only the exact string `'true'` enables it — unset, empty, `'1'`,
 * `'TRUE'`, `'false'`, or any other value resolves to disabled. Any thrown
 * error (e.g. `process.env` unavailable in an unusual runtime) also resolves
 * to disabled, never throws — a flag check must never be the reason a
 * customer request fails.
 */
export function isPuzzleIdentityFlagEnabled(flag: PuzzleIdentityFlag): boolean {
  try {
    return process.env[envVarName(flag)] === 'true';
  } catch {
    return false;
  }
}

/** Arena is independent of puzzle-identity flags and remains unavailable
 * unless explicitly enabled in a local/test deployment. */
export function isArenaEnabled(): boolean {
  try {
    return process.env.ARENA_ENABLED === 'true';
  } catch {
    return false;
  }
}

/** Host authorization is deny-by-default. Entries are verified Orbace
 * AuthenticatedUser.sub values, never client-supplied IDs. */
export function arenaHostAllowlist(): ReadonlySet<string> {
  try {
    const raw = process.env.ARENA_ALLOWED_HOST_IDS;
    if (!raw?.trim()) return new Set();
    const values = raw.split(',').map((value) => value.trim()).filter(Boolean);
    if (values.some((value) => value.length > 128)) return new Set();
    return new Set(values);
  } catch {
    return new Set();
  }
}

/** Exact browser origins authorized to call the Arena API. Empty by default.
 * Values must be canonical origins (scheme + host + optional port), with no
 * path, credentials, query, or fragment. This is intentionally separate from
 * the global CORS list so Preview access cannot broaden unrelated APIs. */
export function arenaAllowedOrigins(): ReadonlySet<string> {
  try {
    const raw = process.env.ARENA_ALLOWED_ORIGINS;
    if (!raw?.trim() || raw.length > 2048) return new Set();
    const values = raw.split(',').map((value) => value.trim());
    if (values.some((value) => !value || value.length > 256)) return new Set();
    const origins = values.map((value) => {
      const parsed = new URL(value);
      if (!['http:', 'https:'].includes(parsed.protocol) || parsed.origin !== value ||
        parsed.username || parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash) {
        throw new Error('invalid Arena origin');
      }
      return parsed.origin;
    });
    return new Set(origins);
  } catch {
    return new Set();
  }
}

/** Snapshot of every Phase 2 flag's current resolved value — for the
 *  feature-flag inventory doc's "verified off" check and for tests. */
export function snapshotPuzzleIdentityFlags(): Record<PuzzleIdentityFlag, boolean> {
  const out = {} as Record<PuzzleIdentityFlag, boolean>;
  for (const flag of PUZZLE_IDENTITY_FLAGS) out[flag] = isPuzzleIdentityFlagEnabled(flag);
  return out;
}
