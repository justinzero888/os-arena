/** Whitelist request metadata for Fastify logs. Never include IPs, ports,
 * cookies, auth headers, request bodies, or query values (which can carry
 * transient tokens/identifiers). */
export function serializeRequestForLog(request: {
  id?: string;
  method?: string;
  url?: string;
  hostname?: string;
  routeOptions?: { url?: string };
}) {
  const safePath = request.routeOptions?.url || (request.url || '').split('?')[0];
  return {
    reqId: request.id,
    method: request.method,
    url: safePath,
    hostname: request.hostname,
  };
}
