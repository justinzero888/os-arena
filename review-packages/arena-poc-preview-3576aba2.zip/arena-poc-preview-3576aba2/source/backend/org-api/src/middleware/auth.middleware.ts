import { FastifyRequest, FastifyReply } from 'fastify';
import { createClient } from '@supabase/supabase-js';
import { verifyTier1Token } from '../lib/tokens.js';
import { prisma } from '../lib/prisma.js';
import { resolveSession } from '../services/session.service.js';
import { SESSION_COOKIE_NAME, MUTATING_METHODS } from './csrf.middleware.js';

const supabaseUrl = process.env.SUPABASE_URL!;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY!;

// A single shared client is enough — auth.getUser(token) verifies whichever
// JWT is passed in per-call, it does not depend on a signed-in session here.
const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});

export interface AuthenticatedUser {
  sub: string;
  tier1Uuid?: string;
  accountId?: string;
}

async function validateSupabaseJwt(token: string): Promise<AuthenticatedUser | null> {
  // Cheap shape check to skip a network round-trip for tokens that are
  // obviously not a Supabase JWT (e.g. our own 2-part signed tier1 tokens).
  if (token.split('.').length !== 3) return null;

  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) return null;

  return {
    sub: data.user.id,
    accountId: data.user.id,
  };
}

function decodeUuidToken(token: string): AuthenticatedUser | null {
  const payload = verifyTier1Token(token);
  if (!payload) return null;
  return {
    sub: payload.tier1_uuid,
    tier1Uuid: payload.tier1_uuid,
  };
}

async function resolveUser(token: string): Promise<AuthenticatedUser | null> {
  const uuidUser = decodeUuidToken(token);
  if (uuidUser) return uuidUser;
  return await validateSupabaseJwt(token);
}

// Resolves a session cookie all the way to its real player row and an
// AuthenticatedUser-compatible shape — reusing whichever identity field
// (tier1Uuid or supabaseId/accountId) the player actually has, so every
// existing findPlayerForUser() call site across ~16 route files resolves a
// cookie-derived user exactly the same way it already resolves a
// bearer-derived one, with zero changes needed there.
async function resolveSessionUser(rawToken: string): Promise<{ user: AuthenticatedUser; playerId: string } | null> {
  const resolved = await resolveSession(rawToken);
  if (!resolved) return null;
  const player = await prisma.playerAccount.findUnique({ where: { id: resolved.playerId } });
  if (!player) return null;
  const user: AuthenticatedUser = player.tier1Uuid
    ? { sub: player.tier1Uuid, tier1Uuid: player.tier1Uuid }
    : { sub: player.supabaseId ?? player.id, accountId: player.supabaseId ?? player.id };
  return { user, playerId: player.id };
}

async function resolveBearerPlayerId(user: AuthenticatedUser): Promise<string | null> {
  const player = await prisma.playerAccount.findFirst({
    where: { OR: [{ tier1Uuid: user.tier1Uuid ?? undefined }, { supabaseId: user.sub }] },
  });
  return player?.id ?? null;
}

export interface DualCredentialResult {
  user: AuthenticatedUser | undefined;
  conflict: boolean;
  // Preserves the exact pre-Phase-3 distinction ('Unauthorized' — no token
  // at all — vs 'Invalid token' — a token was presented but didn't resolve)
  // for the flag-off / bearer-only path, so behavior stays byte-identical
  // to today whenever USE_COOKIE_SESSIONS is off.
  noTokenPresented: boolean;
  // Populated only when both credentials are present and conflict — the
  // candidate players GET /auth/session (ADR-009) needs for its merge-UI
  // response. undefined in every other case.
  bearerPlayerId?: string;
  cookiePlayerId?: string;
}

// ADR-009 dual-credential migration. Byte-identical to today's bearer-only
// behavior whenever USE_COOKIE_SESSIONS is off (the flag this whole
// function short-circuits on first) — nothing here executes at all in that
// case, not even the cookie lookup. Exported (not just authenticate()/
// tryAuthenticate()) so GET /auth/session can build its own 200-with-
// conflict-status response (ADR-009's read-only-request case) from the
// same resolution logic instead of duplicating it.
export async function resolveDualCredential(req: FastifyRequest): Promise<DualCredentialResult> {
  const bearerToken = req.headers.authorization?.replace('Bearer ', '');
  const bearerUser = bearerToken ? await resolveUser(bearerToken) : null;

  if (process.env.USE_COOKIE_SESSIONS !== 'true') {
    return { user: bearerUser ?? undefined, conflict: false, noTokenPresented: !bearerToken };
  }

  const cookieToken = req.cookies?.[SESSION_COOKIE_NAME];
  const cookieResolved = cookieToken ? await resolveSessionUser(cookieToken) : null;

  if (!bearerUser && !cookieResolved) {
    return { user: undefined, conflict: false, noTokenPresented: !bearerToken && !cookieToken };
  }
  if (bearerUser && !cookieResolved) {
    return { user: bearerUser, conflict: false, noTokenPresented: false };
  }
  if (!bearerUser && cookieResolved) {
    return { user: cookieResolved.user, conflict: false, noTokenPresented: false };
  }

  // Both present — compare by their actual player row, not by the
  // AuthenticatedUser shape's fields (tier1Uuid vs accountId mean different
  // things depending on which path produced them; the player id is the only
  // unambiguous identity).
  const bearerPlayerId = await resolveBearerPlayerId(bearerUser!);
  if (bearerPlayerId === cookieResolved!.playerId) {
    // Same player — the cookie is what's trusted going forward (no
    // rotation forced just because a bearer token happened to also be
    // presented; ADR-009 doesn't ask for that).
    return { user: cookieResolved!.user, conflict: false, noTokenPresented: false };
  }
  return {
    user: cookieResolved!.user,
    conflict: true,
    noTokenPresented: false,
    bearerPlayerId: bearerPlayerId ?? undefined,
    cookiePlayerId: cookieResolved!.playerId,
  };
}

export async function authenticate(
  req: FastifyRequest,
  reply: FastifyReply,
): Promise<AuthenticatedUser | undefined> {
  const { user, conflict, noTokenPresented } = await resolveDualCredential(req);

  if (conflict && MUTATING_METHODS.has(req.method)) {
    reply.status(409).send({ error: 'conflict', retry_with: 'cookie' });
    return undefined;
  }

  if (!user) {
    reply.status(401).send({ error: noTokenPresented ? 'Unauthorized' : 'Invalid token' });
    return undefined;
  }

  return user;
}

// Optional auth for endpoints that allow anonymous use (e.g. POST /supu):
// returns the verified identity if a valid token is present, otherwise null.
// Never sends a reply, so the caller can proceed anonymously.
export async function tryAuthenticate(
  req: FastifyRequest,
): Promise<AuthenticatedUser | null> {
  const { user } = await resolveDualCredential(req);
  return user ?? null;
}
