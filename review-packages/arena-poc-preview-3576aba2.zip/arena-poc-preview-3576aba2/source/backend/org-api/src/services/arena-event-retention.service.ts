/** Arena events can include short-lived staging identifiers. Retention is
 * disabled unless explicitly set, and values above the owner-approved
 * seven-day ceiling fail closed instead of silently extending retention. */
export interface ArenaEventRetentionDb {
  arenaEvent: { deleteMany(args: unknown): Promise<{ count: number }> };
}

export function readArenaEventRetentionDays(env: NodeJS.ProcessEnv = process.env): number | null {
  const raw = env.ARENA_EVENT_RETENTION_DAYS;
  if (!raw || !/^[1-7]$/.test(raw)) return null;
  return Number(raw);
}

export async function purgeOldArenaEvents(
  db: ArenaEventRetentionDb,
  now: Date,
  retentionDays: number | null,
): Promise<{ enabled: boolean; retentionDays: number | null; deleted: number }> {
  if (retentionDays === null || !Number.isInteger(retentionDays) || retentionDays < 1 || retentionDays > 7) {
    return { enabled: false, retentionDays: null, deleted: 0 };
  }
  const cutoff = new Date(now.getTime() - retentionDays * 24 * 60 * 60 * 1000);
  const result = await db.arenaEvent.deleteMany({ where: { createdAt: { lt: cutoff } } });
  return { enabled: true, retentionDays, deleted: result.count };
}
