import { defineConfig } from 'vitest/config';

// The opt-in Arena PostgreSQL suites share one explicitly disposable database
// and create eligible puzzle fixtures. Serialize test files in that mode so
// one suite cannot change another suite's puzzle selection.
export default defineConfig({
  test: { fileParallelism: !process.env.ARENA_TEST_DATABASE_URL },
});
