# infra/supabase/migrations — live second track (RLS / security / cron)

**Status (corrected 2026-08-04 by Team D): live, hand-written second track.**

This directory was *briefly* marked frozen in 2026-07-08 (D3), but it is **not
archived** — it is the home for Postgres-level security Prisma does not model:
Row-Level Security, policies, pg_cron/pg_net scheduling, Vault helpers. These
are applied manually through the Supabase SQL editor or CLI; Prisma never
touches them. See `docs/deployment.md` §4d and the AGENTS.md "Known Structural
Debt" rule.

History:

- `001`–`006` — early-phase schema + RLS + pg_cron schedule (historical).
- `007_rls_new_tables.sql` (2026-07-15) — closed the first 10-table RLS gap.
- `008_rls_daily_series.sql` (2026-08-03) — RLS on the A2 Daily Series tables.
- `009_rls_grand_season_circuit.sql` (2026-08-03) — RLS on the A3 Grand/Season/Circuit tables.
- `010_rls_platform_tables.sql` (2026-08-04, Team D) — RLS on 4 tables created
  2026-07-26 (anon_signin_attempts, sessions, merge_cases, submission_appeals)
  that the same-session rule was not applied to.
- `014_rls_v1_submitter_puzzle_submission.sql` (2026-09-02, Team D) — RLS on the
  legacy v1 tables `submitter`, `puzzle`, `submission` (Puzzle Challenge) flagged
  by a Supabase security scan; backend-only, default-deny.
- `015_rls_puzzle_identity_phase1.sql` (2026-09-02, Team D) — RLS on the 12
  Puzzle Identity/Tea Moment/Competition/Su-Pu Phase 1 tables; backend-only,
  default-deny, applied + verified live same session as the companion Prisma
  migration `20260902120000_puzzle_identity_tea_moment_competition_phase1`.
- `016_rls_puzzle_identity_phase2.sql` (2026-09-02, Team A) — RLS on the one
  Phase 2 additive table, `canonical_linkages`; backend-only, default-deny.
  Companion to `20260902130000_puzzle_identity_phase2_canonical_linkage` —
  same same-session deploy rule; not yet applied to any database (see that
  migration's own header and the Phase 2 RC report).
- `020_rls_arena_pilot.sql` (2026-10-29) — RLS enabled with zero client policies
  for the Arena session, round, vote, event, solve-ingress, and private puzzle-supply tables. Its
  table DDL is in the companion Prisma migration
  `20261029130000_arena_pilot`, which now enables RLS atomically in the DDL
  transaction. This SQL companion is idempotent. Neither is applied to a shared or
  production database by this task.

## Do
- Add a new `.sql` here whenever a Prisma migration adds a table, enabling RLS
  with zero policies (default-deny). This is the standing rule from AGENTS.md.
- Apply against the production Supabase project (SQL editor or CLI) **after
  confirming with a human** per `docs/deployment.md` §5 change-gating.

## Do NOT
- Use this directory for ordinary table structure (columns/types/indexes/FKs) —
  that is Prisma's job:

    cd backend/org-api && npx prisma migrate dev --name <description>

## Verification
After applying any RLS migration, confirm zero public tables are unprotected:

    select tablename from pg_tables
    where schemaname = 'public' and rowsecurity = false;

(Expected: 0 rows when 014 and all prior RLS migrations are applied.)
