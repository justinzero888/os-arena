# Arena POC Preview — Security and Privacy Review

**Candidate:** `cc40537534e6fdd6d1061f7d721c8e8fbb89c210`  
**Prior candidate:** `dc06cb118bef91c892989c136d7a8b8a8e1add42`  
**Baseline:** `3d5f0d331b1edf1bd942a9e3142de7bd6ea00d09`  
**Scope:** Arena authenticated voting POC, POC-IR-01 polling correction, sign-in return / Preview key normalization, anonymous share-link access, Flow 1 demo readiness (F1-01 through F1-04), Preview deployment and evidence. This is a builder security review for independent inspection, not independent approval.

## 1. Authentication and identity

### Credential paths

`authenticate()` in `backend/org-api/src/middleware/auth.middleware.ts` accepts:

- a Supabase bearer JWT, verified server-side with `supabase.auth.getUser(token)` — the subject is the verified Supabase user UUID, never a client-decoded claim;
- a signed Tier-1 token, verified with `verifyTier1Token()`, producing the signed `tier1_uuid` subject;
- a server-side session cookie, resolved through `resolveSession()` and a `PlayerAccount` row lookup.

`resolveDualCredential()` compares a bearer identity and a cookie identity by their resolved player row when both are present. For mutating requests, different players produce `409 { error: "conflict", retry_with: "cookie" }`; the same player is accepted. A missing or invalid credential produces `401`. This preserves the existing Orbace auth contract and prevents a cookie/bearer mixture from being treated as two independent identities on a mutating request.

### Vote identity

Arena voting requires `authenticate()`; anonymous votes return `401`. The vote key is the resolved `PlayerAccount.id`, falling back to the JWT subject only when no player row is linked:

```
canonicalVoterKeyHash(voter) -> sha256(player.id ?? voter.sub)
```

This is stored in the existing `arena_votes.guest_key_hash` column and is never returned in a projection. Using the player row makes one Orbace player one effective vote even if the same person presents bearer and cookie credentials at different times. Unlinked Supabase users still get one vote per Supabase subject. Repeat votes upsert the same row.

### Host identity and allowlist

`requireHost()` requires `authenticate()` and membership in `ARENA_ALLOWED_HOST_IDS`; otherwise it returns `403`. The allowlist is deny-by-default, empty when unset, length-bounded, and compared against the verified `AuthenticatedUser.sub`. It is never populated from a client-supplied host ID. Host commands additionally verify that the locked session’s `hostUserId` matches the authenticated host.

**Follow-up (non-blocking for the POC):** `AuthenticatedUser.sub` is transport-dependent. Bearer auth yields the Supabase UUID; cookie auth yields `tier1Uuid` when present, otherwise `supabaseId` or the player ID. The Preview host uses bearer auth with the Supabase UUID, and the local cookie-host integration fixture configures the corresponding `tier1Uuid`. Both are fail-closed. Production should canonicalize host allowlisting to `PlayerAccount.id` so the allowlist is independent of credential transport, matching the voter-key approach.

## 2. Origin and CSRF

- `csrfGuard` applies only to requests carrying the Orbace session cookie; bearer-only requests are structurally CSRF-immune.
- Arena mutating routes additionally use `sameAllowedOrigin()`, which requires an exact `scheme://authority` match against the request host or an entry in `ARENA_ALLOWED_ORIGINS`.
- `ARENA_ALLOWED_ORIGINS` accepts only canonical origins (scheme + host + optional port; no path, credentials, query, or fragment), is length-bounded, and is empty when unset.
- Preview sets the exact Vercel deployment origin and the Fly host is accepted through the same-origin comparison. A disallowed origin received `403 Origin not allowed` in the Preview smoke.
- Bearer-only host commands can omit `Origin`; this is intentional for non-browser clients and does not weaken cookie CSRF protection.

## 3. Puzzle privacy and public projection

- Arena selects only `arena_puzzle_supply` rows with `eligible = true`.
- Candidates already present in the public `puzzleDaily`, `puzzlePool`, or `packPuzzle` stores are rejected.
- There is no public-catalog or protected-official fallback. If no eligible candidate remains, start returns `409` and the session does not start.
- The public `projection()` omits the solution, `puzzleId`, `hostUserId`, host controls, and individual vote rows. It exposes the givens and the host’s current board progress so the audience can watch.
- When the result is `HOST`, the projected board is `null`, so the winning board (the stored solution) is not returned even in the terminal projection.
- Host-only controls are added only by the `/host` route after `requireHost` and ownership checks.
- The overlay route uses the same public projection; the overlay UI hides voting and host controls and is read-only.
- `arena_rounds.solution` is explicitly commented as private backend-only data.

The Preview API smoke verified that the public payload contained no solution, no `hostControls`, and no `puzzleId`.

## 4. Solve validation, timing, and concurrency

- The server validates the full board against the stored solution; a partial or inconsistent board is rejected as a solve.
- A valid partial board may be persisted as host progress with a revision bump, but it does not produce a win.
- Solve ingress is captured before asynchronous work and compared with the authoritative `deadlineAt`; a request that arrives after the deadline is not accepted.
- Session/round transitions use `SELECT ... FOR UPDATE`, bounded transaction timeouts, version checks, and idempotency keys.
- Solve tickets coordinate deadline adjudication and are released exactly once.
- Arena route limiters cover solves and host commands; the app-wide limiter also applies.

### 4.1 POC-IR-01 polling correction

Normal non-host viewers previously probed the host-only endpoint on every one-second refresh, generating expected `401`/`403` responses and consuming the global per-IP budget. The frontend now keeps a tri-state host probe (`unknown` / `host` / `not-host`):

- one host probe per session;
- a confirmed host polls the host endpoint as its snapshot (one request per tick);
- non-host and anonymous viewers poll only the public session;
- overlay polls only the public overlay endpoint and never probes host capability;
- `setSessionUrl` resets the probe for a new session; create/rematch mark the creator as host; an `online` listener re-detects host state after reconnect.

Host authorization remains server-authoritative. Mutation rate limits, CSRF/origin checks, and abuse controls are unchanged; no limit was raised or disabled. A controlled Preview journey (host + 3 authenticated voters + anonymous viewer + overlay) completed with **zero 429 responses and zero page errors**. The focused suite includes a regression test asserting voter host-probe count `1`, overlay `0`, and continuous host polling only for a confirmed host.

### 4.2 Sign-in return and Preview config normalization

Two experience defects were found during owner inspection:

- The Arena Sign in link went to `/signin` without a return path; the sign-in page defaults to `/account` after authentication.
- The Preview build env supplied the Supabase anon key with surrounding quotes, so the generated browser config contained a doubly quoted key and Supabase rejected email sign-in with `Invalid API key`.

Corrections:

- `arena.html` exposes `id="arena-signin"`; `arena.js` stashes `location.pathname + location.search` in the existing `orbace_return_to` session-storage value before navigation. The sign-in page consumes it and returns to the exact Arena URL, including `?session=…`.
- `build-phase4-preview.mjs` strips one pair of surrounding quotes from the Supabase URL/anon-key env values before writing `js/config.js`.
- `phase4-preview-routing.test.mjs` asserts the sign-in wiring and unquoted key output.

The actual email sign-in flow was validated on Preview with the synthetic host account: `/arena` → `/signin` → email/password → `/arena`, auth `registered` as `arena-host-test`, then host session creation; zero `429` and zero page errors. No auth server behavior or rate limit changed.

### 4.3 Anonymous share-link access and Vercel protection separation

Vercel Deployment Protection is a deployment-wide access layer and cannot be scoped to `/arena` or overlay by path. The dedicated Preview project had `ssoProtection: all_except_custom_domains` with no password or automation bypass, so anonymous share/overlay URLs were redirected to Vercel before the app loaded.

For the approved controlled POC Preview, `ssoProtection` was disabled on the dedicated `orbace-arena-phase4-preview` project only. The production project remains untouched. This removes the Vercel access layer; it does not change Orbace application authentication or Arena authorization:

- anonymous visitors can load the Arena and overlay, but the vote API returns `401` and the host panel is hidden;
- `arena-voter-1/2/3` sign in through the existing Orbace email flow and return to the same `?session=` URL;
- only the allowlisted `arena-host-test` receives host capability;
- the overlay remains public/read-only;
- Origin/CSRF checks, host allowlist, and all Arena API authorization remain server-enforced.

The Preview URL is unlisted/noindex but reachable by anyone with the link. This is a deliberate POC-Preview-only access decision and must not be copied to production or a shared environment without a new owner/security decision.

### 4.4 Flow 1 demo readiness (F1-01 through F1-04)

- **F1-01:** Anonymous pages show an explicit `Sign in to vote` action and disabled vote controls. The action uses the existing Orbace email/OAuth authentication and the existing `orbace_return_to` value, returning to the exact `/arena?session=…` URL. Authenticated ordinary Orbace users can vote; no Arena-specific identity or Tier-2 requirement was added. Host capability remains host allowlist plus session ownership.
- **F1-02:** The audience board-update path now uses `cell.dataset.given` rather than `cell.disabled`. Audience cells are disabled, so the old branch rendered givens `0` for empty cells and ignored host progress. Fixed clues now render givens; empty editable cells render blank or the current board value. Audience, anonymous, and overlay pages converge through the existing 2-second public polling; the timer is local; the terminal result converges; refresh recovers state. The three read-only Arena GETs are exempt from the 100/min global fallback on this POC Preview so six normal pages do not receive false `429`s. Authorization, host allowlist, no-store, vote/start/solve host limiters, and all mutation protections remain unchanged. This is a POC-only rate-limit exception and must be reviewed before production.
- **F1-03:** Host presence is an in-memory, 10-second-TTL view on the single POC API instance. `watching` counts distinct opaque page client IDs that fetched the public session or overlay endpoint, excluding the host page's `/host` heartbeats; it is active page instances, not unique people, and multiple tabs/devices count separately. `voters` counts distinct canonical voter keys with at least one vote. The host response is the only place presence is exposed; no viewer UUID, email, or identity is returned. It resets on restart and is approximate by design. The Preview app is scaled to one machine for coherence.
- **F1-04:** Notes/Pencil mode is frontend-only. The host can toggle notes, add/remove candidate digits 1–9 in empty editable cells, click a candidate to toggle it, and entering a final value clears that cell's notes. Fixed clues cannot be noted. Notes are never sent to the board or solve API and cannot affect authoritative validation. No undo/hints/auto-candidates/propagation or persistence was added. Existing strike behavior is unchanged.
- **Early start / ballot window:** The ballot window is 60 seconds; the host may start while it is open and the preset resolves from votes already cast. A stale-version start 409 triggers one host-session refresh/retry so the demo needs one click. This is a state-machine allowance, not a new endpoint or identity path.




## 5. Database/RLS

- The Arena Prisma migration creates the session, round, vote, event, solve-ingress, and private puzzle-supply tables and enables RLS in the same DDL transaction.
- The companion `infra/supabase/migrations/020_rls_arena_pilot.sql` re-enables RLS idempotently and adds no client policies.
- With RLS enabled and zero policies, Supabase client roles are denied. The intended access path is the trusted Prisma server connection (table owner/service credential). A future Supabase client integration must add explicit policies rather than assuming these tables are client-readable.
- The disposable PostgreSQL validation applied all 49 Prisma migrations plus the companion; all six Arena tables reported `relrowsecurity=true`, with zero Arena policies before the companion.

## 6. Voter privacy

- The vote table stores only a SHA-256 of the canonical voter key; no email, Supabase UUID, display name, or raw cookie is stored.
- Public projections expose only aggregate vote counts; preset totals are withheld until the ballot closes.
- The two synthetic Preview accounts’ passwords and the Supabase service key are not in the package.

## 7. Preview-specific security state

- `ARENA_ENABLED=true` only on the Fly Preview app; production remains off/unmodified.
- `ARENA_ALLOWED_HOST_IDS` contains only the Preview host’s Supabase UUID.
- `ARENA_ALLOWED_ORIGINS` contains only the tested Flow 1 Preview deployment origin (`https://orbace-arena-phase4-preview-44plnxqb1.vercel.app`).
- Vercel Deployment Protection is intentionally disabled for the dedicated POC Preview (`ssoProtection: null`). Anonymous `/arena` and overlay requests return `200`; production remains protected and untouched. The Preview URL is unlisted/noindex; Arena API auth, host allowlist, CSRF/origin, and host authorization remain server-enforced.
- All test Arena sessions created during validation were deleted; the host has zero remaining sessions. The four synthetic Preview accounts remain for reviewer/owner use.
- The Fly Preview app is scaled to **one machine** so the in-memory presence counts are coherent for the POC; presence is approximate and resets on restart.
- No production deploy, production DB/RLS change, push, merge, or production enablement was performed.

## 8. Findings summary

No blocking security or privacy defect was found within the POC scope. The following are production-hardening items, not POC blockers:

1. Canonicalize host allowlisting to `PlayerAccount.id` for transport-independent host identity.
2. Treat the Preview deployment origin as ephemeral; update `ARENA_ALLOWED_ORIGINS` on every frontend redeploy. Misconfiguration fails closed.
3. Do not add Supabase client policies for Arena tables without a new security review; current RLS is intentionally deny-all for clients.
4. Keep `ARENA_ENABLED` off by default and enable only per approved environment.
5. Keep the POC-IR-01 host-probe, session-preserving sign-in, anonymous share-link, and build-env unquote regressions; use interval polling and disabled background-timer throttling for multi-tab browser automation.
6. Do not disable Vercel Deployment Protection or carry the read-only Arena GET rate-limit exemption outside this controlled POC Preview; production and shared environments require the owner/security decision and independent review.
7. Replace in-memory single-instance presence with a shared presence mechanism before multi-instance or production use; keep the exact counting semantics and identity-free projection.
