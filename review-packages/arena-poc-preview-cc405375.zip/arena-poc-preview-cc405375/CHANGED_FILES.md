# Changed Files — Baseline to Candidate

**Baseline:** `3d5f0d331b1edf1bd942a9e3142de7bd6ea00d09`  
**Candidate:** `cc40537534e6fdd6d1061f7d721c8e8fbb89c210`  
**Prior candidate:** `dc06cb118bef91c892989c136d7a8b8a8e1add42`  
**Authoritative diff:** `implementation.patch` (`git diff --binary --full-index baseline candidate`)  
**Focused remediation diffs:** `ir01-remediation.patch` (`3f97269e` -> `86b9113c`), `signin-preview-fix.patch` (`86b9113c` -> `720bbb25`), `anonymous-share-fix.patch` (`720bbb25` -> `dc06cb11`), and `flow1-remediation.patch` (`dc06cb11` -> candidate)

## POC-IR-01 remediation delta

Only the following files changed between `3f97269e` and the POC-IR-01 candidate `86b9113c`:

| Status | Path | Change |
|---|---|---|
| M | `orbace-v4-frontend/js/arena.js` | Host probe is now tri-state and one-per-session; confirmed hosts poll the host endpoint, everyone else polls public only; overlay never probes host capability; reconnect re-detects. |
| M | `backend/org-api/src/routes/__tests__/arena.review.postgres.integration.test.ts` | Adds the POC-IR-01 mounted-page regression: host probes continuous, voter `1`, overlay `0`. |

No backend route behavior, migration, rate limit, auth rule, or security control changed in this remediation.

## Sign-in / Preview key normalization delta

Only the following files changed between the POC-IR-01 candidate (`86b9113c`) and the sign-in candidate (`720bbb25`):

| Status | Path | Change |
|---|---|---|
| M | `orbace-v4-frontend/arena.html` | Adds `id="arena-signin"` so the Arena sign-in link can stash its return path. |
| M | `orbace-v4-frontend/js/arena.js` | Stashes `orbace_return_to=/arena` before navigating to `/signin`, using the existing sign-in return-to mechanism. |
| M | `orbace-v4-frontend/scripts/build-phase4-preview.mjs` | Strips one pair of surrounding quotes from the Supabase URL/anon-key env values before writing browser config. |
| M | `orbace-v4-frontend/test/phase4-preview-routing.test.mjs` | Asserts the Arena sign-in wiring and unquoted Preview key output. |

No backend, auth, rate-limit, or security-control change.

## Anonymous share-link delta

Only the following files changed between the sign-in candidate (`720bbb25`) and this candidate:

| Status | Path | Change |
|---|---|---|
| M | `orbace-v4-frontend/js/arena.js` | Sign-in return path now uses `location.pathname + location.search`, preserving the shared `?session=…` URL. |
| M | `orbace-v4-frontend/test/phase4-preview-routing.test.mjs` | Asserts the session-preserving return expression. |

The Vercel Deployment Protection change (`ssoProtection: null` on the dedicated Preview project) is environment configuration, not a source change. Production is untouched.

## Flow 1 demo-readiness delta

Only the following files changed between the anonymous-share candidate (`dc06cb11`) and this candidate:

| Status | Path | Change |
|---|---|---|
| M | `backend/org-api/src/routes/arena.routes.ts` | In-memory presence snapshot on host projection; early host start from BALLOT_OPEN; 60-second ballot; read-only Arena GET exemption from the global fallback (POC-only). |
| M | `backend/org-api/src/routes/__tests__/arena.routes.test.ts` | Early-start preset test. |
| M | `backend/org-api/src/routes/__tests__/arena.review.postgres.integration.test.ts` | Presence counting test; audience live sync/zero-rendering assertions; Notes mode test. |
| M | `orbace-v4-frontend/arena.html` | `Sign in to vote` action, host presence line, Notes toggle. |
| M | `orbace-v4-frontend/css/arena.css` | Pencil-mark overlay and board-tool styles. |
| M | `orbace-v4-frontend/js/api.js` | Opaque per-page presence header on read-only Arena getters. |
| M | `orbace-v4-frontend/js/arena.js` | Explicit voter sign-in, session-preserving return, audience board sync/zero fix, presence rendering, Notes mode, 2-second poll, early-start retry. |

No new identity, login, WebSocket/SSE, database table, Twitch, chat, or production infrastructure was added. The read-only GET rate-limit exemption and single-machine presence are POC-Preview-only and documented in the security review.

## Full candidate file inventory

| Status | Path | Purpose |
|---|---|---|
| M | `backend/org-api/.env.example` | Documents `ARENA_ENABLED=false` default. |
| M | `backend/org-api/package.json` | Adds the Arena event-purge job script. |
| A | `backend/org-api/prisma/migrations/20261029130000_arena_pilot/migration.sql` | Arena tables, constraints, indexes, and RLS enablement. |
| M | `backend/org-api/prisma/schema.prisma` | Arena session/round/vote/event/ingress/supply models. |
| M | `backend/org-api/src/index.ts` | Registers Arena routes and request-log redaction. |
| A | `backend/org-api/src/jobs/purge-arena-events.ts` | Retention job for Arena events. |
| M | `backend/org-api/src/lib/__tests__/feature-flags.test.ts` | Arena flag/allowlist/origin tests. |
| A | `backend/org-api/src/lib/__tests__/request-log-serializer.test.ts` | Log-redaction test. |
| M | `backend/org-api/src/lib/feature-flags.ts` | `isArenaEnabled`, host allowlist, allowed origins. |
| A | `backend/org-api/src/lib/request-log-serializer.ts` | Redacts Arena private fields from logs. |
| M | `backend/org-api/src/middleware/__tests__/csrf.middleware.test.ts` | Arena origin/CSRF tests. |
| M | `backend/org-api/src/middleware/csrf.middleware.ts` | Exact Arena origin handling. |
| A | `backend/org-api/src/routes/__tests__/arena.review.postgres.integration.test.ts` | Real-auth, disposable-PostgreSQL and mounted-browser review journey, including the POC-IR-01 host-probe regression. |
| A | `backend/org-api/src/routes/__tests__/arena.routes.postgres.integration.test.ts` | Fastify + Prisma + PostgreSQL browser journey. |
| A | `backend/org-api/src/routes/__tests__/arena.routes.test.ts` | Arena unit/HTTP tests, including authenticated voting and repeat-vote upsert. |
| A | `backend/org-api/src/routes/arena.routes.ts` | Arena API, projections, host authorization, voting, solve, rematch, presence, early start. |
| A | `backend/org-api/src/services/__tests__/arena-event-retention.service.test.ts` | Retention behavior tests. |
| A | `backend/org-api/src/services/arena-event-retention.service.ts` | Arena event retention logic. |
| A | `backend/org-api/vitest.config.ts` | Backend test configuration used by the suite. |
| A | `infra/supabase/migrations/020_rls_arena_pilot.sql` | Idempotent RLS companion; no client policies. |
| M | `infra/supabase/migrations/README.md` | Documents the Arena RLS companion. |
| M | `orbace-v4-frontend/.gitignore` | Ignores the Preview build output. |
| A | `orbace-v4-frontend/arena.html` | Arena host/audience/overlay page, sign-in action, presence, Notes toggle. |
| M | `orbace-v4-frontend/compete.html` | Arena entry link. |
| A | `orbace-v4-frontend/css/arena.css` | Arena page styling. |
| M | `orbace-v4-frontend/js/api.js` | Arena API adapter methods. |
| A | `orbace-v4-frontend/js/arena.js` | Arena UI, authenticated voting, host controls, overlay, polling correction, live board, presence, Notes. |
| M | `orbace-v4-frontend/package.json` | Preview build/routing scripts. |
| A | `orbace-v4-frontend/scripts/build-phase4-preview.mjs` | Isolated Preview build with same-origin API routing and quoted-env normalization. |
| A | `orbace-v4-frontend/scripts/prepare-phase4-preview-config.mjs` | Preview-only Vercel config, rewrites, and Preview Supabase CSP. |
| M | `orbace-v4-frontend/site-src/pages/compete.html` | Arena entry link source. |
| A | `orbace-v4-frontend/test/phase4-preview-routing.test.mjs` | Preview routing/build/sign-in guards. |

## Notes

- All paths above are relative to the Orbace repository worktree.
- `tests/` contains independent copies of the Arena-relevant test files for reviewer convenience; the same files are included in `implementation.patch` and `source/`.
- The package also contains `docs/ARENA_POC_PREVIEW_EVIDENCE.md` and `docs/evidence/arena-poc-preview-e2e-2026-10-31.json` from the control repository (`os-twitcharena`), which are not part of the Orbace candidate commit.
- No production-only files, secrets, or environment files are included.
