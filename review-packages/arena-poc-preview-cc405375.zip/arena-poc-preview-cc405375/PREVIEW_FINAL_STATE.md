# Preview Final State and Cleanup Evidence — Flow 1 Demo-Readiness Candidate

**Candidate:** `cc40537534e6fdd6d1061f7d721c8e8fbb89c210`  
**Prior candidate:** `dc06cb118bef91c892989c136d7a8b8a8e1add42`  
**Captured:** 2026-10-31 (America/Los_Angeles)  
**Raw log:** `preview-final-state.log`

## Environment state

| Check | Final state |
|---|---|
| Candidate worktree | clean at `cc40537534e6fdd6d1061f7d721c8e8fbb89c210`, branch `codex/arena-phase4-preview` |
| Fly API health | `200` |
| Anonymous Preview page | `200` for `/arena` and overlay; no Vercel authentication |
| Backend capacity | one Fly machine for POC presence coherence |
| Vercel Deployment Protection | disabled (`ssoProtection: null`) for the dedicated POC Preview only |
| Fly `ARENA_ENABLED` | present |
| Fly `ARENA_ALLOWED_HOST_IDS` | present (Preview host Supabase UUID only) |
| Fly `ARENA_ALLOWED_ORIGINS` | present (new Preview origin only) |
| Fly database/auth/session secrets | present, unchanged in name |
| Arena sessions for Preview host | `0` remaining after cleanup |
| Synthetic Arena accounts | `4` remaining (`arena-host-test`, `arena-voter-1/2/3`) |
| Flow 1 six-context journey | pass; 0 `429`, 0 page errors |

## Cleanup performed

- Deleted all test Arena sessions created during validation (POC-IR-01, sign-in, anonymous share, Flow 1 six-context journey, API smoke); the Preview host has zero remaining sessions.
- Vercel Deployment Protection remains intentionally disabled for the dedicated POC Preview so anonymous audience/overlay URLs reach the app. Production is untouched; Arena API auth/host/CSRF/origin remain server-enforced.
- Left the four synthetic Preview auth/player accounts in place for independent review.
- Removed no unrelated Preview accounts or data.
- No production resources were touched.

## Explicitly not performed

- No commit was pushed; the candidate is a local commit in the isolated worktree.
- No merge.
- No production deployment or production configuration change.
- No shared/production database migration or RLS application.
- No production feature-flag enablement.

## Cleanup limitations

- The Preview deployment URL is ephemeral. If the frontend is redeployed, `ARENA_ALLOWED_ORIGINS` must be updated and the Fly app restarted.
- The Preview URL is unlisted/noindex but reachable by anyone with the link because Vercel Protection is disabled for the POC. This is a deliberate, Preview-only access decision; production remains protected.
- The synthetic account passwords are intentionally not in this package; they are held outside the repository.
