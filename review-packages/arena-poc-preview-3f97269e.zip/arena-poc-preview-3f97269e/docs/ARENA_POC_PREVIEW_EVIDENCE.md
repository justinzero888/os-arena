# Arena POC — Preview Execution Evidence (2026-10-31)

> **Status:** IMPLEMENTATION PASS — READY FOR INDEPENDENT REVIEW. This is a builder record, not independent acceptance. Production, commit, push, merge, and production enablement were not performed.

## 1. Objective and governing directive

Execute the authenticated-host + authenticated-audience timed Sudoku POC on the existing Orbace auth/backend/DB/deployment stack:

- `docs/Arena POC — Controlling Implementation Directive/Arena POC — Controlling Implementation Directive.md`
- The POC supersedes anonymous guest voting: one authenticated Orbace user = one effective vote; repeat votes update the same vote; anonymous viewers may watch but not vote; only the allowlisted host may host.

## 2. Implementation identity

| Item | Value |
|---|---|
| Worktree | `/Users/justinzero/.codex/worktrees/orbace-arena-phase4-preview` |
| Branch | `codex/arena-phase4-preview` |
| HEAD at evidence time | `3d5f0d331b1edf1bd942a9e3142de7bd6ea00d09` |
| State | Uncommitted changes; no commit, push, or merge performed |
| Control repo | `/Users/justinzero/orbacetech/DevProjects/os-twitcharena` |

## 3. Preview environment

| Component | Value |
|---|---|
| Backend | Fly app `justinzero-preview` (latest deployed backend image; machines restarted before final validation) |
| Frontend | Vercel project `orbace-arena-phase4-preview` (root `.vercel` link); deployment `https://orbace-arena-phase4-preview-9rco6rvlk.vercel.app` |
| Database/Auth | Supabase project `orbace-sudoku-zerotap-test` (`cjimlozschaolqqsqksu`) |
| Fly secrets | `ARENA_ENABLED=true`, `ARENA_ALLOWED_HOST_IDS=5b881dec-70a9-4c40-b207-ebc884019e01`, `ARENA_ALLOWED_ORIGINS=https://orbace-arena-phase4-preview-9rco6rvlk.vercel.app`; existing `DATABASE_URL`, `SUPABASE_*`, `TIER1_TOKEN_SECRET`, `USE_COOKIE_SESSIONS` unchanged |
| Vercel access | Deployment Protection (SSO) was temporarily disabled for automation, then restored to `all_except_custom_domains` after validation |

### Synthetic Preview accounts

Created through the existing `/auth/uuid/register` → `/auth/uuid/upgrade` → `PUT /player/me` path. Passwords were generated locally and are not stored in this repository.

| Account | Supabase UUID | Player UUID |
|---|---|---|
| `arena-host-test` | `5b881dec-70a9-4c40-b207-ebc884019e01` | `a03481ad-3fca-42ed-acc9-c5772dd4f676` |
| `arena-voter-1` | `9ab84f9a-9c49-43d8-9892-c232fc6f2318` | `4e23dc97-8291-49a6-87f0-23e63fd08701` |
| `arena-voter-2` | `f37e4219-3794-409e-883f-112d747a5385` | `8302624a-b0f7-4396-9067-52950f3270e3` |
| `arena-voter-3` | `0c07d0ea-1764-42b6-8ca1-e34c7948fce6` | `03ae962f-a228-49d5-a40a-08ce3964683e` |

## 4. Code changes

### Backend

- `backend/org-api/src/routes/arena.routes.ts`
  - `POST /api/arena/sessions/:id/votes` now requires `authenticate()`; anonymous votes return `401`.
  - Voter identity is the resolved `PlayerAccount.id` (falling back to the JWT subject when no player row is linked), hashed into the existing `arena_votes.guest_key_hash` column. This keeps one effective vote per Orbace player even if the same person switches between bearer and cookie auth, and repeat votes upsert one row.
  - Defensive `401` if `authenticate()` returns null without having sent a reply.
  - No schema migration was needed; the Phase 4 Arena schema and RLS companion migration are unchanged.

### Frontend

- `orbace-v4-frontend/js/arena.js`
  - Votes and strike votes are available only when signed in and not in overlay mode.
  - Non-signed-in viewers see `Sign in to Orbace to vote.`
  - `getArenaHostSession` returning `403` is treated as “not the host” instead of a page-level error, so authenticated non-host voters can still watch and vote.
- `orbace-v4-frontend/arena.html`
  - Start-panel copy now states viewers must sign in to vote.
- `orbace-v4-frontend/scripts/prepare-phase4-preview-config.mjs`
  - Preview-only config uses root-relative build commands (`cd orbace-v4-frontend && …`) for the monorepo-root Vercel link.
  - Preview CSP adds `https://cjimlozschaolqqsqksu.supabase.co` to `connect-src`; production `vercel.json` is unchanged.

### Tests

- `arena.routes.test.ts`: authenticated-vote hash assertion, anonymous-vote 401, repeat-vote-updates-one-row.
- `arena.routes.postgres.integration.test.ts`: guest cookie assertion replaced with `set-cookie` absence.
- `arena.review.postgres.integration.test.ts`: host + anonymous viewer + three authenticated voters; voter-cannot-host 403; mounted-page journey uses voter cookies.

## 5. Validation

### Focused local backend

Command (disposable PostgreSQL 16 on loopback, database `arena_app`, all Prisma migrations plus `infra/supabase/migrations/020_rls_arena_pilot.sql`):

```bash
ARENA_TEST_DATABASE_URL=... npx vitest run \
  src/routes/__tests__/arena.routes.test.ts \
  src/routes/__tests__/arena.routes.postgres.integration.test.ts \
  src/routes/__tests__/arena.review.postgres.integration.test.ts \
  src/lib/__tests__/feature-flags.test.ts \
  src/middleware/__tests__/csrf.middleware.test.ts
```

Result: **84 passed / 0 failed** (5 files). RLS check before the companion migration: all six Arena tables `relrowsecurity=true`, 49 Prisma migrations applied.

### Full backend regression

```bash
ARENA_TEST_DATABASE_URL=... npx vitest run
```

Result: **2,346 passed / 6 skipped**; 169 test files passed, 1 skipped.

### Static/build

- `npx tsc --noEmit` — pass.
- `npm run build` (`tsc`) — pass.
- `npm run test:phase4-preview-routing` — pass.

### Preview API smoke

Against `https://justinzero-preview.fly.dev` with `Origin: https://orbace-arena-phase4-preview-9rco6rvlk.vercel.app`:

| Check | Result |
|---|---|
| `GET /api/arena/health` | `200 {"enabled":true}` |
| Host `POST /api/arena/sessions` | `201`, `BALLOT_OPEN` |
| Anonymous vote | `401 Unauthorized` |
| Authenticated voter vote | `200` |
| Voter changes vote | `200`; host projection `voteCount=2` for two distinct voters (repeat updated, not duplicated) |
| Voter `GET .../host` | `403` |
| Voter `POST .../start` | `403` |
| Vote from disallowed origin | `403 Origin not allowed` |
| Anonymous `GET /api/arena/sessions/:id` | `200`, no solution |
| Host `GET .../host` | `200`, host controls present |

### Post-hardening Preview API smoke

After the canonical voter-key change was redeployed, the same Preview smoke was rerun with three distinct authenticated voters plus one repeat vote. Result: three vote calls returned `200`; the host projection reported `voteCount=3` (repeat changed the existing vote rather than adding a fourth). Anonymous vote, voter-cannot-host, and disallowed-origin checks still returned `401`/`403`.

### Preview browser E2E (pre-hardening full pass)

Driver: Puppeteer, five isolated browser contexts (host, three voters, one anonymous viewer) against the Vercel Preview deployment. Each account signed in through the page’s Supabase SDK, then exercised the mounted Arena UI.

Evidence: `docs/evidence/arena-poc-preview-e2e-2026-10-31.json`.

| Step | Result |
|---|---|
| Four synthetic accounts sign in | pass |
| Host creates session | pass |
| Three distinct voters vote | `3 audience vote(s)` |
| Voter changes vote | count remains 3; `standard` pressed |
| Anonymous viewer | vote controls disabled; `Sign in to Orbace to vote.`; host panel hidden; can watch |
| Ordinary voter | host panel hidden; start disabled |
| Host starts round | `PLAYING`; audience cells read-only |
| Server validates solve | `Host wins — solved before the deadline.` |
| Public payload privacy | no solution, no `hostControls`, no `puzzleId` |
| Rematch | new session created; voter sees ballot and votes |

The browser diagnostics contained only expected Arena polling responses: non-host host-projection checks (`403`), anonymous host-projection checks (`401`), occasional rate-limit responses (`429`), and a missing favicon (`404`). No unexpected page errors occurred.

The full five-context pass above was recorded before the final voter-key hardening. After hardening, the Preview main flow (sign-in, three voters, repeat vote, anonymous watch-only, voter-cannot-host, start, solve, privacy) passed again and rematch creation succeeded. The final ad-hoc Preview rematch voter re-auth/vote re-run was blocked by Puppeteer background-tab throttling and protocol timeouts in the harness, not by an application error; the post-hardening local mounted-page integration journey through rematch passed in the focused suite.

## 6. Security and privacy checks

- Anonymous vote rejected (`401`); one authenticated user cannot create multiple effective votes (upsert by `sha256(sub)`).
- Non-allowlisted authenticated users cannot host (`403`); UI also hides host controls.
- Origin allowlist is enforced on Arena state-changing routes; a disallowed origin receives `403`.
- Public session projection does not expose the solution, `hostControls`, or `puzzleId`.
- Arena puzzle supply remains private/eligible-only; the Preview database contains owner-seeded `OWNER_PHASE4_PREVIEW_20261030` Extreme puzzles.
- Arena feature flag is enabled only on the Preview app; production configuration was not touched.
- Test Arena sessions created during validation were deleted (9 sessions; cascade removes rounds/votes/events/ingresses). The four synthetic accounts remain for reviewer/owner use.

## 7. Known limitations and owner-controlled gates

- **No push/merge/deploy to production.** The candidate is a local commit (`3f97269e3a4c1446f478a35fbf1a261617f0f2e9`) in the isolated worktree; it was not pushed or merged.
- **Vercel Preview URL is ephemeral.** A new frontend deployment changes the origin; `ARENA_ALLOWED_ORIGINS` on Fly must be updated and the app restarted.
- **Vercel SSO protection** is enabled again. A reviewer/owner must be signed in to Vercel or use an approved automation bypass to open the deployment in a browser.
- **20-second ballot.** Voters must join the session link promptly; a rematch creates a fresh 20-second ballot. The E2E forces a full reload when moving an existing browser context to the new rematch query string.
- **Preview browser-harness flakiness.** Puppeteer’s default `requestAnimationFrame` polling is throttled on background tabs when several pages are open; the final ad-hoc Preview rematch re-run used interval polling and still hit a protocol timeout. This is a harness issue, not an application defect; the recorded full pass and the local mounted-page rematch test are the authoritative browser evidence.
- **Preview CSP patch is local-only.** The committed production `vercel.json` was not modified.
- **Synthetic accounts** exist only in the Preview Supabase project; their passwords are held outside the repository.
- **Independent review is still required.** This document records builder validation only.

## 8. Reproduction notes

1. Start from the isolated worktree and install backend/frontend dependencies.
2. Run the focused and full backend commands above with a disposable PostgreSQL database and the RLS companion migration.
3. Build the Preview frontend with `PHASE4_PREVIEW_SUPABASE_URL` and `PHASE4_PREVIEW_SUPABASE_ANON_KEY`; use `prepare-phase4-preview-config.mjs` to generate the local Vercel config.
4. Deploy the backend to `justinzero-preview` and the frontend to the Preview Vercel project.
5. Set `ARENA_ENABLED=true`, `ARENA_ALLOWED_HOST_IDS=<host Supabase UUID>`, and `ARENA_ALLOWED_ORIGINS=<Preview origin>` on Fly.
6. Run the browser E2E with the four synthetic accounts.

## 9. Review package

- **Candidate:** `3f97269e3a4c1446f478a35fbf1a261617f0f2e9`
- **Baseline:** `3d5f0d331b1edf1bd942a9e3142de7bd6ea00d09`
- **Tag:** `arena-poc-preview-2026-10-31`
- **Package:** `review-packages/arena-poc-preview-3f97269e.zip`
- **Contents:** review request, candidate/baseline identity, complete implementation patch, changed-file inventory, evidence docs/JSON, Arena source/test snapshots, full and focused test logs, TypeScript/build/routing logs, Preview API smoke, security/privacy review, Preview final-state evidence, and `MANIFEST.sha256`.
- **Delivery:** placed in the ChatGPT Project “Orbace Sudoku Twitchcon Arena” under `review-packages/` and `sources/`, with a provenance copy in this repository’s `review-packages/` directory.

