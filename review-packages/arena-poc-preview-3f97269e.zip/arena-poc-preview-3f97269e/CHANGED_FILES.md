# Changed Files — Baseline to Candidate

**Baseline:** `3d5f0d331b1edf1bd942a9e3142de7bd6ea00d09`  
**Candidate:** `3f97269e3a4c1446f478a35fbf1a261617f0f2e9`  
**Authoritative diff:** `implementation.patch` (`git diff --binary --full-index baseline candidate`)

| Status | Path | Purpose |
|---|---|---|
| M | `backend/org-api/.env.example` | Documents `ARENA_ENABLED=false` default. |
| M | `backend/org-api/package.json` | Adds the Arena event-purge job script. |
| A | `backend/org-api/prisma/migrations/20261029130000_arena_pilot/migration.sql` | Arena tables, constraints, indexes, and RLS enablement. |
| M | `backend/org-api/prisma/schema.prisma` | Arena session/round/vote/event/ingress/supply models. |
| M | `backend/org-api/src/index.ts` | Registers Arena routes and request-log redaction. |
| A | `backend/org-api/src/jobs/purge-arena-events.ts` | Retention job for Arena events. |
| M | `backend/org-api/src/lib/__tests__/feature-flags.test.ts` | Arena flag/allowlist/origin tests. |
| A | `backend/org-api/src/lib/__tests__/request-log-serializer.test.ts` | Log-redaction test. |
| M | `backend/org-api/src/lib/feature-flags.ts` | `isArenaEnabled`, host allowlist, allowed origins. |
| A | `backend/org-api/src/lib/request-log-serializer.ts` | Redacts Arena private fields from logs. |
| M | `backend/org-api/src/middleware/__tests__/csrf.middleware.test.ts` | Arena origin/CSRF tests. |
| M | `backend/org-api/src/middleware/csrf.middleware.ts` | Exact Arena origin handling. |
| A | `backend/org-api/src/routes/__tests__/arena.review.postgres.integration.test.ts` | Real-auth, disposable-PostgreSQL and mounted-browser review journey. |
| A | `backend/org-api/src/routes/__tests__/arena.routes.postgres.integration.test.ts` | Fastify + Prisma + PostgreSQL browser journey. |
| A | `backend/org-api/src/routes/__tests__/arena.routes.test.ts` | Arena unit/HTTP tests, including authenticated voting and repeat-vote upsert. |
| A | `backend/org-api/src/routes/arena.routes.ts` | Arena API, projections, host authorization, voting, solve, rematch. |
| A | `backend/org-api/src/services/__tests__/arena-event-retention.service.test.ts` | Retention behavior tests. |
| A | `backend/org-api/src/services/arena-event-retention.service.ts` | Arena event retention logic. |
| A | `backend/org-api/vitest.config.ts` | Backend test configuration used by the suite. |
| A | `infra/supabase/migrations/020_rls_arena_pilot.sql` | Idempotent RLS companion; no client policies. |
| M | `infra/supabase/migrations/README.md` | Documents the Arena RLS companion. |
| M | `orbace-v4-frontend/.gitignore` | Ignores the Preview build output. |
| A | `orbace-v4-frontend/arena.html` | Arena host/audience/overlay page. |
| M | `orbace-v4-frontend/compete.html` | Arena entry link. |
| A | `orbace-v4-frontend/css/arena.css` | Arena page styling. |
| M | `orbace-v4-frontend/js/api.js` | Arena API adapter methods. |
| A | `orbace-v4-frontend/js/arena.js` | Arena UI, authenticated voting gates, host controls, overlay. |
| M | `orbace-v4-frontend/package.json` | Preview build/routing scripts. |
| A | `orbace-v4-frontend/scripts/build-phase4-preview.mjs` | Isolated Preview build with same-origin API routing. |
| A | `orbace-v4-frontend/scripts/prepare-phase4-preview-config.mjs` | Preview-only Vercel config, rewrites, and Preview Supabase CSP. |
| M | `orbace-v4-frontend/site-src/pages/compete.html` | Arena entry link source. |
| A | `orbace-v4-frontend/test/phase4-preview-routing.test.mjs` | Preview routing/build guards. |

## Notes

- All paths above are relative to the Orbace repository worktree.
- `tests/` contains independent copies of the Arena-relevant test files for reviewer convenience; the same files are included in `implementation.patch` and `source/`.
- The package also contains `docs/ARENA_POC_PREVIEW_EVIDENCE.md` and `docs/evidence/arena-poc-preview-e2e-2026-10-31.json` from the control repository (`os-twitcharena`), which are not part of the Orbace candidate commit.
- No production-only files, secrets, or environment files are included.
