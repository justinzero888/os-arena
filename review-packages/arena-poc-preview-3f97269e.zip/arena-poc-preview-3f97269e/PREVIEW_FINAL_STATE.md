# Preview Final State and Cleanup Evidence

**Candidate:** `3f97269e3a4c1446f478a35fbf1a261617f0f2e9`  
**Captured:** 2026-10-31 (America/Los_Angeles)  
**Raw log:** `preview-final-state.log`

## Environment state

| Check | Final state |
|---|---|
| Candidate worktree | clean at `3f97269e3a4c1446f478a35fbf1a261617f0f2e9`, branch `codex/arena-phase4-preview` |
| Fly API health | `200`, Arena health `{"enabled":true}` |
| Vercel Preview page | `302` to Vercel SSO; protection restored |
| Vercel SSO setting | `{"deploymentType":"all_except_custom_domains"}` |
| Fly `ARENA_ENABLED` | present |
| Fly `ARENA_ALLOWED_HOST_IDS` | present (Preview host Supabase UUID only) |
| Fly `ARENA_ALLOWED_ORIGINS` | present (tested Preview origin only) |
| Fly database/auth/session secrets | present, unchanged in name |
| Arena sessions for Preview host | `0` remaining after cleanup |
| Synthetic Arena accounts | `4` remaining (`arena-host-test`, `arena-voter-1/2/3`) |

## Cleanup performed

- Deleted all test Arena sessions created by the Preview host (`count=0` confirmed afterwards). The schema cascades rounds, votes, events, and solve ingresses.
- Restored Vercel Deployment Protection after automated browser validation.
- Left the four synthetic Preview auth/player accounts in place for independent review.
- Removed no unrelated Preview accounts or data.
- No production resources were touched.

## Explicitly not performed

- No commit was pushed; the candidate is a local commit in the isolated worktree.
- No merge.
- No production deployment or production configuration change.
- No shared/production database migration or RLS application.
- No production feature-flag enablement.

## Cleanup limitations

- The Preview deployment URL is ephemeral. If the frontend is redeployed, `ARENA_ALLOWED_ORIGINS` must be updated and the Fly app restarted.
- The synthetic account passwords are intentionally not in this package; they are held outside the repository.
